import logging
import os
import json
import requests
import azure.functions as func
from azure.functions.decorators import FunctionApp, route

app = FunctionApp()

# 환경변수
AZURE_SEARCH_ENDPOINT = os.environ["AZURE_SEARCH_ENDPOINT"]
AZURE_SEARCH_KEY = os.environ["AZURE_SEARCH_KEY"]
AZURE_SEARCH_INDEX = os.environ["AZURE_SEARCH_INDEX"]

OPENAI_ENDPOINT = os.environ["OPENAI_ENDPOINT"]
OPENAI_API_KEY = os.environ["OPENAI_API_KEY"]
OPENAI_DEPLOYMENT = os.environ["OPENAI_DEPLOYMENT"]

@app.route(route="ask")
def query_azure_ai_search(query_text):
    search_url = f"{AZURE_SEARCH_ENDPOINT}/ind1exes/{AZURE_SEARCH_INDEX}/docs/search?api-version=2023-07-01-preview"

    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_SEARCH_KEY
    }

    body = {
        "search": query_text,
        "top": 3,
        "queryType": "semantic",
        "semanticConfiguration": "default",
        "queryLanguage": "ko-kr"
    }

    response = requests.post(search_url, headers=headers, json=body)
    response.raise_for_status()
    results = response.json()

    docs = [doc["@search.document"] for doc in results["value"]]
    return docs

def call_openai_with_context(user_question, search_results):
    prompt = f"""사용자의 질문: "{user_question}"
다음은 검색된 정보입니다:
{json.dumps(search_results, ensure_ascii=False, indent=2)}

위 내용을 기반으로 자연어로 명확한 답변을 생성해주세요."""

    headers = {
        "Content-Type": "application/json",
        "api-key": OPENAI_API_KEY
    }

    openai_url = f"{OPENAI_ENDPOINT}/openai/deployments/{OPENAI_DEPLOYMENT}/chat/completions?api-version=2024-05-01"

    body = {
        "messages": [
            {"role": "system", "content": "당신은 데이터 기반으로 응답하는 AI 어시스턴트입니다."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.7,
        "max_tokens": 1000
    }

    response = requests.post(openai_url, headers=headers, json=body)
    response.raise_for_status()
    result = response.json()
    return result["choices"][0]["message"]["content"]

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        req_body = req.get_json()
        question = req_body.get("question")

        if not question:
            return func.HttpResponse("Missing question", status_code=400)

        search_results = query_azure_ai_search(question)
        ai_answer = call_openai_with_context(question, search_results)

        return func.HttpResponse(json.dumps({
            "question": question,
            "answer": ai_answer
        }, ensure_ascii=False), mimetype="application/json")

    except Exception as e:
        logging.exception("Error processing request")
        return func.HttpResponse(str(e), status_code=500)
