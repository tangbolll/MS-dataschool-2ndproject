# Databricks notebook source
# Azure Blob Storage에서 Databricks로 CSV 데이터 가져오기

# ==========================================
# 1. Azure Storage Account 연결 설정
# ==========================================
from pyspark.sql import SparkSession
from pyspark.sql import functions as F # 필요한 경우 추가 임포트
import os
from datetime import datetime

# Spark 세션 생성

from azure.storage.blob import BlobServiceClient, StorageErrorCode
import os

# Storage Account 정보
storage_account_name = "cosmo2csv"
container_name = "cosmo-to-csv"
storage_account_key = "jkUvA9iMfrJ8JHNSuuOs21uFYfM7g2Gu7D/CubSAEE6bknEtqp7x8woG3XGZSqviuth3t14oPvpk+AStKqz1qg=="
connection_string = "DefaultEndpointsProtocol=https;AccountName=cosmo2csv;AccountKey=jkUvA9iMfrJ8JHNSuuOs21uFYfM7g2Gu7D/CubSAEE6bknEtqp7x8woG3XGZSqviuth3t14oPvpk+AStKqz1qg==;EndpointSuffix=core.windows.net"

HADOOP_AZURE_JAR = "/home/azureuser/.ivy2.5.2/jars/org.apache.hadoop_hadoop-azure-3.3.6.jar"
AZURE_STORAGE_BLOB_JAR = "/home/azureuser/.ivy2.5.2/jars/com.microsoft.azure_azure-storage-7.0.1.jar"
AZURE_DATA_LAKE_JAR = "/home/azureuser/.ivy2.5.2/jars/azure-data-lake-store-sdk-2.3.10.jar"
all_jars = ",".join([HADOOP_AZURE_JAR, AZURE_STORAGE_BLOB_JAR, AZURE_DATA_LAKE_JAR])

spark = SparkSession.builder \
    .appName("LocalDatabricksProcessing") \
    .master("local[*]") \
    .config("spark.jars", all_jars) \
    .getOrCreate()

spark.sparkContext._jsc.hadoopConfiguration().set(f"fs.azure.account.key.{storage_account_name}.dfs.core.windows.net", storage_account_key)

print("Azure Storage 연결 설정 완료!")

print("Azure Storage 연결 설정 완료!") # 중복 출력 주석 처리

# SparkContext 가져오기 (SparkSession이 생성되면 자동으로 생성됨)
sc = spark.sparkContext

# ==========================================
# 2. Blob Storage 내 파일 목록 확인
# ==========================================

# Blob Storage 경로 설정
from pyspark.sql.functions import col # 필요 시 상단에 추가
from pyspark import SparkContext
from datetime import datetime # 날짜/시간 비교를 위해 추가


# Blob Storage 경로 설정
blob_path = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/"

print("=== 컨테이너 내 파일 목록 ===") # 출력 주석 처리

# Spark Hadoop FileSystem API를 사용하여 파일 목록 가져오기
# hadoop FileSystem 객체 생성
fs = sc._jvm.org.apache.hadoop.fs.FileSystem.get(sc._jvm.java.net.URI(blob_path), sc._jvm.org.apache.hadoop.conf.Configuration(spark.sparkContext._jsc.hadoopConfiguration()))

files_status = fs.listStatus(sc._jvm.org.apache.hadoop.fs.Path(blob_path))

files_info = []
for status in files_status:
    if status.isFile(): # 파일만 필터링 (디렉토리 제외)
        file_path = status.getPath().toString()
        file_name = status.getPath().getName()
        file_size = status.getLen() # bytes
        # modificationTime은 milliseconds로 반환되므로 변환 필요
        modification_time_millis = status.getModificationTime()
        # Python datetime 객체로 변환 (optional, for sorting clarity)
        modification_time = datetime.fromtimestamp(modification_time_millis / 1000)

        files_info.append({
            "name": file_name,
            "size": file_size,
            "path": file_path,
            "modificationTime": modification_time_millis # 정렬을 위해 밀리초 값 유지
        })
        print(f"파일명: {file_name}, 크기: {file_size} bytes, 경로: {file_path}") # 출력 주석 처리

# CSV 파일만 필터링
csv_files = [file for file in files_info if file["name"].endswith('.csv')]
print(f"\n총 {len(csv_files)}개의 CSV 파일 발견") # 출력 주석 처리

# 가장 최신 CSV 파일만 읽기
if csv_files:
    # 파일을 modificationTime 순으로 정렬 (가장 최신 파일 가져오기)
    latest_file = max(csv_files, key=lambda x: x["modificationTime"])
    print(f"가장 최신 파일: {latest_file['name']}") # 출력 주석 처리

    # df_latest = spark.read.option("header", "true").option("inferSchema", "true").csv(latest_file['path'])
    print("최신 CSV 파일 읽기 완료!") # 출력 주석 처리

# COMMAND ----------

# ==========================================
# 3. CSV 파일 읽기
# ==========================================


# 기존 코드 그대로 사용 가능
print("\n=== 모든 CSV 파일 읽기 ===") # 출력 주석 처리



df_all = spark.read \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .csv(blob_path)  # 와일드카드 제거



##########################df_all = spark.read.option("header", "true").option("inferSchema", "true").csv(blob_path + "*.csv")

# 가장 최신 CSV 파일만 읽기 (위에서 latest_file이 정의되었다고 가정)
if csv_files:
    # latest_file은 dict이므로 'path' 키로 접근
    df_latest = spark.read.option("header", "true").option("inferSchema", "true").csv(latest_file['path'])
    print("최신 CSV 파일 읽기 완료!") # 출력 주석 처리


# COMMAND ----------

print("\n=== 기본 데이터 정보 ===") # 출력 주석 처리

# 사용할 DataFrame 선택 (전체 데이터 또는 최신 데이터)
df = df_all # 또는 df_latest 사용

# 데이터 크기 확인
row_count = df.count()
col_count = len(df.columns)
print(f"데이터 shape: {row_count} rows × {col_count} columns") # 출력 주석 처리

# 스키마 정보
print("\n=== 데이터 스키마 ===") # 출력 주석 처리
# df.printSchema() # 출력 주석 처리

# 처음 5행 확인
print("\n=== 데이터 미리보기 ===") # 출력 주석 처리
print("✅ df: 상위 5개 행 출력은 생략됨. 데이터는 정상 로딩되었는지 확인 요망.") # 출력 주석 처리
# 컬럼명 확인
print(f"\n=== 컬럼명 목록 ===") # 출력 주석 처리
print(df.columns) # 출력 주석 처리


# COMMAND ----------

# 컬럼 개수와 행 개수 확인
print(f"컬럼 개수: {len(df.columns)}") # 출력 주석 처리
print(f"행 개수: {df.count()}") # 출력 주석 처리

# 기본 정보 컬럼들만 먼저 보기
basic_cols = ['poi_code', 'AREA_NM', 'AREA_CD', 'inserted_at']
#df.select(basic_cols).show(truncate=False) # 출력 주석 처리

# COMMAND ----------

# MAGIC %md
# MAGIC 중첩 컬럼 구분

# COMMAND ----------

from pyspark.sql.functions import col

json_cols = ['ACDNT_CNTRL_STTS','BUS_STN_STTS', 'CHARGER_STTS', 'EVENT_STTS', 'LIVE_CMRCL_STTS.CMRCL_RSB','LIVE_PPLTN_STTS','PRK_STTS', 'ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS', 'SBIKE_STTS', 'SUB_STTS', 'WEATHER_STTS']

# 빠른 체크 - 백틱 사용
for column in df.columns:
    if column not in json_cols:
        try:
            # 점이 포함된 컬럼명은 백틱으로 감싸기
            column_escaped = f"`{column}`"
            first_val = df.select(column_escaped).first()[0]

            if first_val and isinstance(first_val, str):
                if first_val.startswith('[') or first_val.startswith('{'):
                    print(f"JSON 의심: {column}") # 출력 주석 처리
                    pass
        except Exception as e:
            print(f"에러 발생 컬럼: {column} - {str(e)}") # 출력 주석 처리
            pass

# COMMAND ----------

# MAGIC %md
# MAGIC 중첩 없는 칼럼들만 main_csv로 만들기

# COMMAND ----------

json_cols = ['ACDNT_CNTRL_STTS','BUS_STN_STTS', 'CHARGER_STTS', 'EVENT_STTS',
             'LIVE_CMRCL_STTS.CMRCL_RSB','LIVE_PPLTN_STTS','PRK_STTS',
             'ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS', 'SBIKE_STTS', 'SUB_STTS', 'WEATHER_STTS']

# JSON 컬럼들을 제외한 main_df 생성
main_df = df.drop(*json_cols)

# 결과 확인
print("=== JSON 컬럼 제외 후 main_df ===") # 출력 주석 처리
# main_df.show(5, truncate=False) # 출력 주석 처리

print(f"원본 컬럼 수: {len(df.columns)}") # 출력 주석 처리
print(f"main_df 컬럼 수: {len(main_df.columns)}") # 출력 주석 처리
print(f"제거된 컬럼 수: {len(json_cols)}") # 출력 주석 처리

print("\n=== main_df 컬럼 목록 ===") # 출력 주석 처리
# for i, col_name in enumerate(main_df.columns): # 출력 주석 처리
#     print(f"{i+1}. {col_name}") # 출력 주석 처리

# COMMAND ----------

# MAGIC %md
# MAGIC 중첩 컬럼 내용 확인

# COMMAND ----------

# MAGIC %md
# MAGIC 사고통제현황 -> 필요없음

# COMMAND ----------

#df.select("`ACDNT_CNTRL_STTS`").show(truncate=False) # 출력 주석 처리

# COMMAND ----------
from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType

def flatten_ppltn_stts_auto(df):
    # 샘플 데이터로 스키마 추론
    sample_json = df.select("LIVE_PPLTN_STTS").first()[0]
    
    # 임시로 스키마 추론을 위한 DataFrame 생성
    temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
    inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    
    # JSON 파싱 및 explode
    df_parsed = df.withColumn("ppltn_parsed", from_json(col("LIVE_PPLTN_STTS"), ArrayType(inferred_schema)))
    
    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("ppltn_parsed")).alias("population")
    ).select("poi_code", "inserted_at", "AREA_NM", "AREA_CD", "population.*").drop("FCST_PPLTN")

# 실행
ppltn_df = flatten_ppltn_stts_auto(df)
ppltn_df.show(5, truncate=False)


# MAGIC %md
# MAGIC 버스정류소 현황

# COMMAND ----------

#df.select("BUS_STN_STTS").show(1, truncate=False) # 출력 주석 처리

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType, StructType, StringType

def flatten_bus_stn_stts_auto(df):
    # 샘플 데이터로 스키마 추론
    # 비어있는 배열일 경우를 대비하여 non-empty filter 추가
    sample_json_row = df.select("BUS_STN_STTS").filter(col("BUS_STN_STTS") != "[]").first()
    if sample_json_row:
        sample_json = sample_json_row[0]
        # 임시로 스키마 추론을 위한 DataFrame 생성
        temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
        inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    else:
        # 데이터가 없는 경우 기본 스키마 또는 빈 스키마 정의
        inferred_schema = StructType([]) # 빈 스키마
        
    # JSON 파싱 및 explode
    df_parsed = df.withColumn("bus_parsed", from_json(col("BUS_STN_STTS"), ArrayType(inferred_schema)))

    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("bus_parsed")).alias("bus_station")
    ).select("poi_code", "inserted_at", "AREA_NM", "AREA_CD", "bus_station.*").drop("BUS_DETAIL","BUS_RESULT_MSG")

# 실행
bus_df = flatten_bus_stn_stts_auto(df)
# bus_df.show(5) # 출력 주석 처리

# COMMAND ----------

# MAGIC %md
# MAGIC 전기차충전소 현황

# COMMAND ----------

#df.select("CHARGER_STTS").show(1, truncate=False) # 출력 주석 처리

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType, StructType, StringType

def flatten_charger_stts_main_only(df):
    sample_json_row = df.select("CHARGER_STTS").filter(col("CHARGER_STTS") != "[]").first()
    if sample_json_row:
        sample_json = sample_json_row[0]
        temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
        inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    else:
        inferred_schema = StructType([]) # 빈 스키마

    df_parsed = df.withColumn("charger_parsed", from_json(col("CHARGER_STTS"), ArrayType(inferred_schema)))

    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("charger_parsed")).alias("charger_station")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("charger_station.STAT_NM").alias("STAT_NM"),
        col("charger_station.STAT_ID").alias("STAT_ID"),
        col("charger_station.STAT_ADDR").alias("STAT_ADDR"),
        col("charger_station.STAT_X").alias("STAT_X"),
        col("charger_station.STAT_Y").alias("STAT_Y"),
        col("charger_station.STAT_USETIME").alias("STAT_USETIME"),
        col("charger_station.STAT_PARKPAY").alias("STAT_PARKPAY"),
        col("charger_station.STAT_LIMITYN").alias("STAT_LIMITYN"),
        col("charger_station.STAT_LIMITDETAIL").alias("STAT_LIMITDETAIL"),
        col("charger_station.STAT_KINDDETAIL").alias("STAT_KINDDETAIL")
        # CHARGER_DETAILS 제외 (모든 값이 null이므로)
    )

# 실행
charger_df = flatten_charger_stts_main_only(df)
# charger_df.show(5, truncate=False) # 출력 주석 처리

# COMMAND ----------

# MAGIC %md
# MAGIC 행사 정보 -> 필요없음, 다른 csv로 대체하면됨.

# COMMAND ----------

#df.select("EVENT_STTS").show(1, truncate=False) # 출력 주석 처리

# COMMAND ----------

# MAGIC %md
# MAGIC 실시간 상권 현황 -> 필요 없음

# COMMAND ----------

#df.select("LIVE_CMRCL_STTS").show(1, truncate=False) # 출력 주석 처리

# COMMAND ----------

# MAGIC %md
# MAGIC 업종별 상권 현황

# COMMAND ----------

#df.select("`LIVE_CMRCL_STTS.CMRCL_RSB`").show(1, truncate=False) # 출력 주석 처리

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType, StructType, StringType

# LIVE_CMRCL_STTS.CMRCL_RSB를 flatten
def flatten_cmrcl_rsb_auto(df):
    # 샘플 데이터로 스키마 추론
    sample_json_row = df.select("`LIVE_CMRCL_STTS.CMRCL_RSB`").filter(col("`LIVE_CMRCL_STTS.CMRCL_RSB`") != "[]").first()
    if sample_json_row:
        sample_json = sample_json_row[0]
        # 임시로 스키마 추론을 위한 DataFrame 생성
        temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
        inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    else:
        inferred_schema = StructType([]) # 빈 스키마

    # JSON 파싱 및 explode
    df_parsed = df.withColumn("cmrcl_parsed", from_json(col("`LIVE_CMRCL_STTS.CMRCL_RSB`"), ArrayType(inferred_schema)))

    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("cmrcl_parsed")).alias("cmrcl_item")
    ).select("poi_code", "inserted_at", "AREA_NM", "AREA_CD", "cmrcl_item.*")

# 실행
cmrcl_df = flatten_cmrcl_rsb_auto(df)
# cmrcl_df.show(5, truncate=False) # 출력 주석 처리

# COMMAND ----------

# MAGIC %md
# MAGIC 주차정보

# COMMAND ----------

# df.select("PRK_STTS").show(1, truncate=False) # 출력 주석 처리

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType, StructType, StringType

# PRK_STTS를 flatten
def flatten_prk_stts_auto(df):
    # 샘플 데이터로 스키마 추론
    sample_json_row = df.select("PRK_STTS").filter(col("PRK_STTS") != "[]").first()
    if sample_json_row:
        sample_json = sample_json_row[0]
        # 임시로 스키마 추론을 위한 DataFrame 생성
        temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
        inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    else:
        inferred_schema = StructType([]) # 빈 스키마

    # JSON 파싱 및 explode
    df_parsed = df.withColumn("parking_parsed", from_json(col("PRK_STTS"), ArrayType(inferred_schema)))

    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("parking_parsed")).alias("parking_station")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("parking_station.PRK_NM").alias("PRK_NM"),
        col("parking_station.PRK_CD").alias("PRK_CD"),
        col("parking_station.PRK_TYPE").alias("PRK_TYPE"),
        col("parking_station.CPCTY").alias("CPCTY"),
        col("parking_station.CUR_PRK_CNT").alias("CUR_PRK_CNT"),
        col("parking_station.CUR_PRK_TIME").alias("CUR_PRK_TIME"),
        col("parking_station.CUR_PRK_YN").alias("CUR_PRK_YN"),
        col("parking_station.PAY_YN").alias("PAY_YN"),
        col("parking_station.RATES").alias("RATES"),
        col("parking_station.TIME_RATES").alias("TIME_RATES"),
        col("parking_station.ADD_RATES").alias("ADD_RATES"),
        col("parking_station.ADD_TIME_RATES").alias("ADD_TIME_RATES"),
        col("parking_station.ADDRESS").alias("ADDRESS"),
        col("parking_station.ROAD_ADDR").alias("ROAD_ADDR"),
        col("parking_station.LNG").alias("LNG"),
        col("parking_station.LAT").alias("LAT")
    )

# 실행
parking_df = flatten_prk_stts_auto(df)
# parking_df.show(5, truncate=False) # 출력 주석 처리

# 개수 확인
print(f"총 주차장 개수: {parking_df.count()}") # 출력 주석 처리

# COMMAND ----------

# MAGIC %md
# MAGIC 도로소통현황
# MAGIC

# COMMAND ----------

# df.select("`ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS`").show(1, truncate=False) # 출력 주석 처리

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType, StructType, StringType

# ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS를 flatten
def flatten_road_traffic_stts_auto(df):
    # 샘플 데이터로 스키마 추론
    sample_json_row = df.select("`ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS`").filter(col("`ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS`") != "[]").first()
    if sample_json_row:
        sample_json = sample_json_row[0]
        # 임시로 스키마 추론을 위한 DataFrame 생성
        temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
        inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    else:
        inferred_schema = StructType([]) # 빈 스키마

    # JSON 파싱 및 explode
    df_parsed = df.withColumn("traffic_parsed", from_json(col("`ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS`"), ArrayType(inferred_schema)))

    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("traffic_parsed")).alias("traffic_info")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("traffic_info.LINK_ID").alias("LINK_ID"),
        col("traffic_info.ROAD_NM").alias("ROAD_NM"),
        col("traffic_info.START_ND_CD").alias("START_ND_CD"),
        col("traffic_info.START_ND_NM").alias("START_ND_NM"),
        col("traffic_info.START_ND_XY").alias("START_ND_XY"),
        col("traffic_info.END_ND_CD").alias("END_ND_CD"),
        col("traffic_info.END_ND_NM").alias("END_ND_NM"),
        col("traffic_info.END_ND_XY").alias("END_ND_XY"),
        col("traffic_info.DIST").alias("DIST"),
        col("traffic_info.SPD").alias("SPD"),
        col("traffic_info.IDX").alias("IDX"),
        col("traffic_info.XYLIST").alias("XYLIST")
    )

# 실행
traffic_df = flatten_road_traffic_stts_auto(df)
# traffic_df.show(5, truncate=False) # 출력 주석 처리

# 개수 확인
print(f"총 도로교통 정보 개수: {traffic_df.count()}") # 출력 주석 처리

# COMMAND ----------

# MAGIC %md
# MAGIC 따릉이

# COMMAND ----------

# df.select("SBIKE_STTS").show(2, truncate=False) # 출력 주석 처리

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType, StructType, StringType

# SBIKE_STTS를 flatten
def flatten_sbike_stts_auto(df):
    # 비어있지 않은 샘플 데이터로 스키마 추론
    sample_json_row = df.select("SBIKE_STTS").filter(col("SBIKE_STTS") != "[]").first()
    if sample_json_row:
        sample_json = sample_json_row[0]
        # 임시로 스키마 추론을 위한 DataFrame 생성
        temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
        inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    else:
        inferred_schema = StructType([]) # 빈 스키마

    # JSON 파싱 및 explode
    df_parsed = df.withColumn("sbike_parsed", from_json(col("SBIKE_STTS"), ArrayType(inferred_schema)))

    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("sbike_parsed")).alias("sbike_station")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("sbike_station.SBIKE_SPOT_NM").alias("SBIKE_SPOT_NM"),
        col("sbike_station.SBIKE_SPOT_ID").alias("SBIKE_SPOT_ID"),
        col("sbike_station.SBIKE_SHARED").alias("SBIKE_SHARED"),
        col("sbike_station.SBIKE_PARKING_CNT").alias("SBIKE_PARKING_CNT"),
        col("sbike_station.SBIKE_RACK_CNT").alias("SBIKE_RACK_CNT"),
        col("sbike_station.SBIKE_X").alias("SBIKE_X"),
        col("sbike_station.SBIKE_Y").alias("SBIKE_Y")
    )

# 실행
sbike_df = flatten_sbike_stts_auto(df)
# sbike_df.show(5, truncate=False) # 출력 주석 처리

# 개수 확인
print(f"총 공유자전거 정류장 개수: {sbike_df.count()}") # 출력 주석 처리

# COMMAND ----------

# MAGIC %md
# MAGIC 지하철 정보 -> 그냥 지하철 위치 정보여서 제외

# COMMAND ----------

# df.select("`SUB_STTS`").show(1, truncate=False) # 출력 주석 처리

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType, StructType, StringType

# SUB_FACIINFO와 SUB_DETAIL 제외하고 메인 정보만
def flatten_sub_stts_main_only(df):
    sample_json_row = df.select("SUB_STTS").filter(col("SUB_STTS") != "[]").first()
    if sample_json_row:
        sample_json = sample_json_row[0]
        temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
        inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    else:
        inferred_schema = StructType([]) # 빈 스키마

    df_parsed = df.withColumn("sub_parsed", from_json(col("SUB_STTS"), ArrayType(inferred_schema)))

    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("sub_parsed")).alias("sub_station")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("sub_station.SUB_STN_NM").alias("SUB_STN_NM"),
        col("sub_station.SUB_STN_LINE").alias("SUB_STN_LINE"),
        col("sub_station.SUB_STN_RADDR").alias("SUB_STN_RADDR"),
        col("sub_station.SUB_STN_JIBUN").alias("SUB_STN_JIBUN"),
        col("sub_station.SUB_STN_X").alias("SUB_STN_X"),
        col("sub_station.SUB_STN_Y").alias("SUB_STN_Y")
        # SUB_FACIINFO, SUB_DETAIL 제외
    )

# 메인 정보만 필요하다면:
sub_df = flatten_sub_stts_main_only(df)
# sub_df.show(5, truncate=False) # 출력 주석 처리

# COMMAND ----------

# MAGIC %md
# MAGIC 날씨

# COMMAND ----------

# df.select("`WEATHER_STTS`").show(1, truncate=False) # 출력 주석 처리

# COMMAND ----------

# MAGIC %md
# MAGIC - 현재 날씨 & 뉴스 정보

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType, StructType, StringType

def flatten_weather_stts_main_only(df):
    sample_json_row = df.select("WEATHER_STTS").filter(col("WEATHER_STTS") != "[]").first()
    if sample_json_row:
        sample_json = sample_json_row[0]
        temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
        inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    else:
        inferred_schema = StructType([]) # 빈 스키마

    df_parsed = df.withColumn("weather_parsed", from_json(col("WEATHER_STTS"), ArrayType(inferred_schema)))

    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("weather_parsed")).alias("weather_info")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("weather_info.WEATHER_TIME").alias("WEATHER_TIME"),
        col("weather_info.TEMP").alias("TEMP"),
        col("weather_info.SENSIBLE_TEMP").alias("SENSIBLE_TEMP"),
        col("weather_info.MAX_TEMP").alias("MAX_TEMP"),
        col("weather_info.MIN_TEMP").alias("MIN_TEMP"),
        col("weather_info.HUMIDITY").alias("HUMIDITY"),
        col("weather_info.WIND_DIRCT").alias("WIND_DIRCT"),
        col("weather_info.WIND_SPD").alias("WIND_SPD"),
        col("weather_info.PRECIPITATION").alias("PRECIPITATION"),
        col("weather_info.PRECPT_TYPE").alias("PRECPT_TYPE"),
        col("weather_info.PCP_MSG").alias("PCP_MSG"),
        col("weather_info.SUNRISE").alias("SUNRISE"),
        col("weather_info.SUNSET").alias("SUNSET"),
        col("weather_info.UV_INDEX_LVL").alias("UV_INDEX_LVL"),
        col("weather_info.UV_INDEX").alias("UV_INDEX"),
        col("weather_info.UV_MSG").alias("UV_MSG"),
        col("weather_info.PM25_INDEX").alias("PM25_INDEX"),
        col("weather_info.PM25").alias("PM25"),
        col("weather_info.PM10_INDEX").alias("PM10_INDEX"),
        col("weather_info.PM10").alias("PM10"),
        col("weather_info.AIR_IDX").alias("AIR_IDX"),
        col("weather_info.AIR_IDX_MVL").alias("AIR_IDX_MVL"),
        col("weather_info.AIR_IDX_MAIN").alias("AIR_IDX_MAIN"),
        col("weather_info.AIR_MSG").alias("AIR_MSG")
        # FCST24HOURS, NEWS_LIST 제외
    )

# 메인 날씨 정보만
weather_df = flatten_weather_stts_main_only(df)
# weather_df.show(5, truncate=False) # 출력 주석 처리

# CSV로 저장
# weather_df.coalesce(1).write.mode("overwrite").option("header", "true").csv("weather_main_data") # 출력 주석 처리

# COMMAND ----------

def flatten_weather_forecast(df):
    sample_json_row = df.select("WEATHER_STTS").filter(col("WEATHER_STTS") != "[]").first()
    if sample_json_row:
        sample_json = sample_json_row[0]
        temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
        inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    else:
        inferred_schema = StructType([]) # 빈 스키마

    df_parsed = df.withColumn("weather_parsed", from_json(col("WEATHER_STTS"), ArrayType(inferred_schema)))

    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("weather_parsed")).alias("weather_info")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("weather_info.FCST24HOURS")).alias("forecast")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("forecast.FCST_DT").alias("FCST_DT"),
        col("forecast.TEMP").alias("FCST_TEMP"),
        col("forecast.PRECIPITATION").alias("FCST_PRECIPITATION"),
        col("forecast.PRECPT_TYPE").alias("FCST_PRECPT_TYPE"),
        col("forecast.RAIN_CHANCE").alias("RAIN_CHANCE"),
        col("forecast.SKY_STTS").alias("SKY_STTS")
    )

# 24시간 예보 데이터
weather_forecast_df = flatten_weather_forecast(df)
# weather_forecast_df.show(10, truncate=False) # 출력 주석 처리

# CSV로 저장
# weather_forecast_df.coalesce(1).write.mode("overwrite").option("header", "true").csv("weather_forecast_data") # 출력 주석 처리

# COMMAND ----------

def flatten_weather_news(df):
    sample_json_row = df.select("WEATHER_STTS").filter(col("WEATHER_STTS") != "[]").first()
    if sample_json_row:
        sample_json = sample_json_row[0]
        temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
        inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    else:
        inferred_schema = StructType([]) # 빈 스키마

    df_parsed = df.withColumn("weather_parsed", from_json(col("WEATHER_STTS"), ArrayType(inferred_schema)))

    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("weather_parsed")).alias("weather_info")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("weather_info.NEWS_LIST")).alias("news")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("news.WARN_VAL").alias("WARN_VAL"),
        col("news.WARN_STRESS").alias("WARN_STRESS"),
        col("news.ANNOUNCE_TIME").alias("ANNOUNCE_TIME"),
        col("news.COMMAND").alias("COMMAND"),
        col("news.CANCEL_YN").alias("CANCEL_YN"),
        col("news.WARN_MSG").alias("WARN_MSG")
    )

# 경보/뉴스 데이터
weather_news_df = flatten_weather_news(df)
# weather_news_df.show(5, truncate=False) # 출력 주석 처리

# CSV로 저장
# weather_news_df.coalesce(1).write.mode("overwrite").option("header", "true").csv("weather_news_data") # 출력 주석 처리

# COMMAND ----------

# MAGIC %md
# MAGIC blob으로 다시 보내기

# COMMAND ----------


import time
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
import os # 로컬 파일 시스템 경로 관리를 위해 추가

# Blob Storage 인증 정보 (위에 설정된 storage_account_name, connection_string 사용)
connect_str = connection_string # 변경된 부분
blob_service_client = BlobServiceClient.from_connection_string(connect_str)
container_client = blob_service_client.get_container_client(container_name)


# 이 딕셔너리는 이제 로컬에서 의미가 없습니다.
# existing_files = {
#     "main": "part-00000-...",
#     ...
# }

# 처리된 DataFrame들을 모아놓은 딕셔너리 (예시, 실제 코드에서 정의되어야 함)
dataframes = {
    "main": main_df,
    "ppltn": ppltn_df,
    "bus": bus_df,
    "charger": charger_df,
    "cmrcl": cmrcl_df,
    "parking": parking_df,
    "traffic": traffic_df,
    "sbike": sbike_df,
    "sub": sub_df,
    "weather": weather_df,
    "weather_forecast": weather_forecast_df,
    "weather_news": weather_news_df
}

# Azure Blob Storage의 'clean-data' 폴더를 목표로 함
blob_output_prefix = "clean-data"

for name, df_to_save in dataframes.items(): # df_to_save로 변수명 변경 (df와 충돌 방지)
    if df_to_save.count() == 0:
        print(f"Skipping {name} as DataFrame is empty.") # 출력 주석 처리
        continue

    print(f"Updating {name} file...") # 출력 주석 처리

    # 1. Spark DataFrame을 Azure Blob Storage로 직접 저장
    # abfss:// 경로 사용 (Spark 3.x에서 지원)
    # Spark가 직접 Azure Blob Storage에 파일을 쓸 수 있도록 설정이 되어있어야 함 (위에 key 설정)
    target_blob_path = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/{blob_output_prefix}/{name}.csv"

    try:
        # coalesce(1)은 단일 파일로 저장하기 위함
        # mode("overwrite")는 기존 파일을 덮어씀
        df_to_save.coalesce(1).write.mode("overwrite").option("header", "true").csv(target_blob_path)
        print(f"✅ {name}: Azure Blob Storage에 직접 저장 완료!") # 출력 주석 처리
    except Exception as e:
        print(f"❌ Error saving {name} to Blob Storage: {e}") # 출력 주석 처리
        pass

    # 로컬 파일 시스템에 임시 저장 후 업로드하는 방식 (대안)
    # 이 방식은 Spark가 abfss:// 경로에 직접 쓰기 어려운 경우 사용
    # temp_local_folder = f"./temp_local_{name}_update"
    # df_to_save.coalesce(1).write.mode("overwrite").option("header", "true").csv(temp_local_folder)

    # new_part_file_path = None
    # for root, _, files in os.walk(temp_local_folder):
    #     for f in files:
    #             if f.startswith("part-") and f.endswith(".csv"):
    #                 new_part_file_path = os.path.join(root, f)
    #                 break
    #     if new_part_file_path:
    #             break

    # if new_part_file_path:
    #     blob_target_name = f"{blob_output_prefix}/{name}.csv"
    #     blob_client = container_client.get_blob_client(blob_target_name)

    #     print(f"Uploading {new_part_file_path} to {blob_target_name}...")
    #     with open(new_part_file_path, "rb") as data:
    #             blob_client.upload_blob(data, overwrite=True)
    #     print(f"✅ {name}: 로컬에서 Blob Storage로 업로드 완료!")

    #     # 임시 로컬 폴더 삭제
    #     import shutil
    #     shutil.rmtree(temp_local_folder)
    # else:
    #     print(f"❌ {name}: 로컬 임시 파일을 찾을 수 없습니다.")

print("데이터프레임 처리 및 Blob Storage 마이그레이션 작업 완료!")