# Databricks notebook source
cosmosEndpoint = "https://seoul-data-db.documents.azure.com:443/"  # 너 Cosmos DB URI
cosmosMasterKey = "gdgCLQrX8omjZKrDkLRCyo41URDljVi7K8rdHzTUcUpRLg2k1BR8th6CmyKtUG3XS0wLB2hwe49oACDbxniaXQ=="               # 너의 Cosmos DB key
cosmosDatabaseName = "seoul-data-db"
cosmosContainerName = "seouldatastorage"

cfg = {
  "spark.cosmos.accountEndpoint": cosmosEndpoint,
  "spark.cosmos.accountKey": cosmosMasterKey,
  "spark.cosmos.database": cosmosDatabaseName,
  "spark.cosmos.container": cosmosContainerName,
  "spark.cosmos.read.inferSchema.enabled": "true",       # 자동 스키마 추론
  "spark.cosmos.read.customQuery": "SELECT * FROM c"     # 명시적 쿼리
}

df = spark.read.format("cosmos.oltp").options(**cfg).load()
df.printSchema()
df.show(5, truncate=False)


# COMMAND ----------

