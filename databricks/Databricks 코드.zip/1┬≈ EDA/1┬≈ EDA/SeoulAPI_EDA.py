# Databricks notebook source
# MAGIC %md
# MAGIC # 0. 데이터 가져오기

# COMMAND ----------

import pandas as pd
import glob

# 1. DBFS → 로컬 임시 디렉토리로 복사
dbutils.fs.cp("dbfs:/user/hive/warehouse/", "file:/tmp/seoul_data/", recurse=True)

# 2. glob로 로컬 파일 읽기
files = glob.glob("/tmp/seoul_data/seoul_city_data_full_202507*.csv")

# 3. 읽고 concat
df_list = [pd.read_csv(file) for file in files]
df = pd.concat(df_list, ignore_index=True)

print(df.shape)
df.head()


# COMMAND ----------

# Azure 환경 버전

# 필요한 모듈 import
import pandas as pd
from pyspark.sql import SparkSession

# 1. Spark 세션은 Databricks에서는 이미 활성화되어 있음
# (Databricks 노트북에서는 spark라는 세션 객체가 기본 제공됨)

# 2. Cosmos DB 연결 설정
cosmos_endpoint = "https://seoul-data-db.documents.azure.com:443/"
cosmos_key = "gdgCLQrX8omjZKrDkLRCyo41URDljVi7K8rdHzTUcUpRLg2k1BR8th6CmyKtUG3XS0wLB2hwe49oACDbxniaXQ=="
cosmos_database_name = "seoul-data-db"
cosmos_container_name = "seouldatastorage"

# 3. Cosmos DB에서 데이터 읽어오기 (Spark DataFrame으로)
spark_df = spark.read \
    .format("cosmos.oltp") \
    .option("spark.cosmos.accountEndpoint", cosmos_endpoint) \
    .option("spark.cosmos.accountKey", cosmos_key) \
    .option("spark.cosmos.database", cosmos_database_name) \
    .option("spark.cosmos.container", cosmos_container_name) \
    .option("spark.cosmos.read.inferSchema.enabled", "true") \
    .load()

# 4. 필요 시 Spark DataFrame 확인
spark_df.printSchema()
spark_df.show(5)

# 5. (선택) 필터링 예시
# filtered_df = spark_df.filter("city = '서울' AND date >= '2025-07-01'")

# 6. Spark → Pandas DataFrame으로 변환 (주의: 데이터 크기 클 경우 메모리 초과 위험)
df = spark_df.toPandas()

# 7. Pandas DataFrame 확인
print(f"Shape: {df.shape}")
df.head()


# COMMAND ----------

# MAGIC %md
# MAGIC # **1.  기본 정보 확인**

# COMMAND ----------

# MAGIC %md
# MAGIC #### 목적   
# MAGIC #### 데이터의 크기, 범위, 변수 구조 등을 직관적으로 파악

# COMMAND ----------

# MAGIC %md
# MAGIC DF의 열이 너무 적어보인다. 컬럼을 확인해 봐야겠다.

# COMMAND ----------

df.columns

# COMMAND ----------

# MAGIC %md
# MAGIC 컬럼 자체는 문제가 없는 듯 하다

# COMMAND ----------

# MAGIC %md
# MAGIC 다음으로, 기본적인 모양을 먼저 확인해보자.

# COMMAND ----------

(df.count(), len(df.columns))

# COMMAND ----------

# MAGIC %md
# MAGIC **2400개 데이터에 대해서 73개 행이 쌓여있다. 데이터 양은 예상했던 수치(1만개) 보다는 작지만 큰 수의 법칙으로 이상치, 결측치 등 경향성을 파악하는 대에 큰 문제는 없다고 생각된다.**

# COMMAND ----------

# MAGIC %md
# MAGIC 다음으로 데이터 타입을 확인해보자

# COMMAND ----------

df.dtypes

# COMMAND ----------

# MAGIC %md
# MAGIC 모든 행에 대해 확인할 수 없으니 확장해보자
# MAGIC
# MAGIC

# COMMAND ----------

import pandas as pd

pd.set_option('display.max_columns', None)   # 모든 컬럼 출력
pd.set_option('display.max_rows', None)      # 모든 행 출력 (원할 경우)
pd.set_option('display.max_colwidth', None)  # 컬럼 너비 제한 해제

# COMMAND ----------

df.dtypes

# COMMAND ----------

# MAGIC %md
# MAGIC ## **Int 데이터** 2개
# MAGIC list_total_count
# MAGIC CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_SPD
# MAGIC
# MAGIC ## **float64 데이터** 50개
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTON_PPLTN_MIN
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTON_PPLTN_MAX
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTOFF_PPLTN_MIN
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTOFF_PPLTN_MAX
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_30WTHN_GTON_PPLTN_MIN
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_30WTHN_GTON_PPLTN_MAX
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_30WTHN_GTOFF_PPLTN_MIN
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_30WTHN_GTOFF_PPLTN_MAX
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTON_PPLTN_MIN
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTON_PPLTN_MAX
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTOFF_PPLTN_MIN
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTOFF_PPLTN_MAX
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_5WTHN_GTON_PPLTN_MIN
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_5WTHN_GTON_PPLTN_MAX
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_5WTHN_GTOFF_PPLTN_MIN
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_5WTHN_GTOFF_PPLTN_MAX
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_STN_CNT
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_STN_TIME
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTON_PPLTN_MIN
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTON_PPLTN_MAX
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTOFF_PPLTN_MIN
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTOFF_PPLTN_MAX
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTON_PPLTN_MIN
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTON_PPLTN_MAX
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTOFF_PPLTN_MIN
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTOFF_PPLTN_MAX
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTON_PPLTN_MIN
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTON_PPLTN_MAX
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTOFF_PPLTN_MIN
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTOFF_PPLTN_MAX
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTON_PPLTN_MIN
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTON_PPLTN_MAX
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTOFF_PPLTN_MIN
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTOFF_PPLTN_MAX
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_STN_CNT
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_STN_TIME
# MAGIC CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_CNT
# MAGIC CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MIN
# MAGIC CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MAX
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_MALE_RATE
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_FEMALE_RATE
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_10_RATE
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_20_RATE
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_30_RATE
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_40_RATE
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_50_RATE
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_60_RATE
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_PERSONAL_RATE
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_CORPORATION_RATE
# MAGIC CITYDATA.LIVE_CMRCL_STTS
# MAGIC
# MAGIC ## **Object 데이터** 6개
# MAGIC
# MAGIC RESULT.RESULT.CODE
# MAGIC RESULT.RESULT.MESSAGE
# MAGIC CITYDATA.AREA_NM
# MAGIC CITYDATA.AREA_CD
# MAGIC CITYDATA.LIVE_PPLTN_STTS
# MAGIC CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_MSG
# MAGIC CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_IDX
# MAGIC CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_TIME
# MAGIC CITYDATA.ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS
# MAGIC CITYDATA.PRK_STTS
# MAGIC CITYDATA.SUB_STTS
# MAGIC CITYDATA.BUS_STN_STTS
# MAGIC CITYDATA.ACDNT_CNTRL_STTS
# MAGIC CITYDATA.SBIKE_STTS
# MAGIC CITYDATA.WEATHER_STTS
# MAGIC CITYDATA.CHARGER_STTS
# MAGIC CITYDATA.EVENT_STTS
# MAGIC CITYDATA.LIVE_CMRCL_STTS.AREA_CMRCL_LVL
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_RSB
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_TIME
# MAGIC AREA_NAME_QUERY

# COMMAND ----------

# MAGIC %md
# MAGIC **★☆CITYDATA.BUS_STN_STTS과 같이, 어떤 데이터값을 저장하는게 아니라 카테고리의 이름까지 열로 지정되었다. 이는 JSON 파일의 구조를 평탄화 하는 과정에서 같이 열로 변환된거 같으니 이러한 JSON 구조상 항목은 추출후 삭제할 필요가 있음.★☆**

# COMMAND ----------

df = df.toPandas()

df.info()

# COMMAND ----------

# MAGIC %md
# MAGIC 각 칼럼들에 대해 결측치가 600~800개 정도 존재하는 행이 있다.
# MAGIC 아마도 지역, 시간대에 대해서 없는 행이 존재하는 것 같다. 낮은 비율이 아니기에 결측치 처리방법에 대해서도 궁리를 해야겠다.

# COMMAND ----------

df.describe()

# COMMAND ----------

# MAGIC %md
# MAGIC ### 전반적으로 대부분의 칼럼에 대하여 중위값에비해 평균이 매우 크다

# COMMAND ----------

# MAGIC %md
# MAGIC >> 이에 대해 (1) 이상치가 너무 커서 평균이 움직이는건지 (2) 전체적으로 오른쪽으로 치우쳐진 분포인지 확인하고 조치를 취해야겠다.

# COMMAND ----------

# MAGIC %md
# MAGIC # 2. 결측치 확인

# COMMAND ----------

# MAGIC %md
# MAGIC #### 목적
# MAGIC #### 결측치가 많은 변수나 패턴(특정 조건에서만 발생 등)을 파악하고 향후 처리 방향(제거, 대체, 예측 등)을 결정

# COMMAND ----------

# 결측치 확인

# 결측치 개수 확인
# df.isnull().sum()

# 결측치가 어느 칼럼에 있는지 확인
if (df.isnull().any() == True).any():
    print("결측치가 있는 칼럼:")
    print(df.columns[df.isnull().any()])


# 결측치가 있는 칼럼별 정상값과 결측치의 비율
if (df.isnull().any() == True).any():
    missing_ratios = df.isnull().any().sum() / len(df.columns)
print("\n결측치 비율:")
print(missing_ratios)


# 결측치가 있는 칼럼과 정상값의 비율
if (df.isnull().any() == True).any():
    missing_ratios = df.isnull().sum() / len(df)
print("\n결측치 비율:")
print(missing_ratios)


# 결측치가 있는 행의 CITYDATA.AREA_NM 값 출력
missing_rows = df[df.isnull().any(axis=1)]
missing_rows['CITYDATA.AREA_NM']

# 결측치가 없는 행의 CITYDATA.AREA_NM 값 출력
# 사실 결측치가 없는 행은 없다.
# 왜냐하면 CITYDATA.LIVE_CMRCL_STTS 칼럼의 모든 값이 결측치이기 때문이다.
# 따라서 결측치가 1개 이하인 행을 결측치가 없는 행이라고 가정한다
df['missing_count'] = df.isnull().sum(axis=1)
filtered_df = df[df['missing_count'] <= 1]
unique_areas = filtered_df['CITYDATA.AREA_NM'].unique()
print("결측치가 1개 이하인 행의 'CITYDATA.AREA_NM' 값 (중복 없음):")
for area in unique_areas:
    print(area)


### 각 지역별 결측치 항목 확인

missing_columns_by_area = {}
for area in df['CITYDATA.AREA_NM'].unique():
    # 해당 지역의 데이터만 필터링합니다.
    df_area = df[df['CITYDATA.AREA_NM'] == area]

    # 결측치가 있는 컬럼들을 찾습니다.
    missing_cols = df_area.columns[df_area.isnull().any()].tolist()

    # 중복 없이 저장하기 위해 set을 사용합니다.
    # 기존에 저장된 컬럼들이 있다면 합쳐줍니다.
    if area in missing_columns_by_area:
        missing_columns_by_area[area].update(missing_cols)
    else:
        missing_columns_by_area[area] = set(missing_cols)

# 결과 출력
for area, cols in missing_columns_by_area.items():
    print(f"'{area}' 지역의 결측치 컬럼: {', '.join(sorted(list(cols)))}")


# COMMAND ----------

# 결측치가 2개 이상인 행의 'CITYDATA.AREA_NM' 값과 결측치 개수 출력

rows_with_multiple_missing = df[df['missing_count'] >= 2]
# 필터링된 행과 해당 행의 결측치 값 출력
filtered_df = df[df['missing_count'] >= 2]

# 'CITYDATA.AREA_NM'과 'missing_count' 값을 중복 없이 추출
# 두 컬럼의 조합을 유니크하게 만들기 위해 튜플의 리스트로 만든 후 set으로 변환
unique_combinations = set(zip(filtered_df['CITYDATA.AREA_NM'], filtered_df['missing_count']))

# 결과 출력
print("결측치가 2개 이상인 행의 'CITYDATA.AREA_NM' 값과 결측치 개수 (중복 없음):")
for area, count in sorted(list(unique_combinations)):
    print(f"지역: {area}, 결측치 개수: {count}")

# COMMAND ----------

# 상권 정보 결측치가 있는 칼럼 정리

# 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_' 패턴을 포함하는 컬럼들만 선택
cmrcl_pattern_columns = [col for col in df.columns if col.startswith('CITYDATA.LIVE_CMRCL_STTS.CMRCL_')]

# 선택된 컬럼들 중 하나라도 결측치가 있는 행을 찾습니다.
# .any(axis=1)은 각 행에서 True가 하나라도 있으면 해당 행을 True로 반환합니다.
rows_with_any_cmrcl_missing = df[df[cmrcl_pattern_columns].isnull().any(axis=1)]

# 필터링된 행들의 'CITYDATA.AREA_NM' 값을 중복 없이 추출
unique_areas = rows_with_any_cmrcl_missing['CITYDATA.AREA_NM'].unique()

print("\n`CITYDATA.LIVE_CMRCL_STTS.CMRCL_` 패턴 컬럼 중 하나라도 결측치가 있는 행의 'CITYDATA.AREA_NM' (중복 없음):")
for area in unique_areas:
    print(area)

# COMMAND ----------

# 상권(결제) 정보 결측치가 있는 칼럼 정리 후 출력
target_areas = [
    '경복궁', '서울 암사동 유적', '창덕궁·종묘', '삼각지역', '강서한강공원', '고척돔',
    '광나루한강공원', '광화문광장', '국립중앙박물관·용산가족공원', '난지한강공원',
    '남산공원', '노들섬', '뚝섬한강공원', '망원한강공원', '반포한강공원',
    '북서울꿈의숲', '서리풀공원·몽마르뜨공원', '서울광장', '서울대공원', '서울숲공원',
    '아차산', '양화한강공원', '어린이대공원', '여의도한강공원', '월드컵공원',
    '응봉산', '이촌한강공원', '잠실종합운동장', '잠실한강공원', '잠원한강공원',
    '청계산', '청와대', '보라매공원', '서대문독립공원', '안양천', '여의서로',
    '올림픽공원', '홍제폭포'
]
# 1. 'CITYDATA.AREA_NM'이 주어진 목록에 있는 행만 필터링합니다.
filtered_by_area = df[df['CITYDATA.AREA_NM'].isin(target_areas)]

# 2. 'LIVE_CMRCL_STTS' 패턴을 가지는 컬럼들을 식별합니다.
# 정확히 'CITYDATA.LIVE_CMRCL_STTS.'로 시작하는 컬럼들을 찾습니다.
live_cmrcl_stts_columns = [col for col in filtered_by_area.columns if col.startswith('CITYDATA.LIVE_CMRCL_STTS.')]

# 3. 식별된 컬럼들 내에서 결측치 개수를 계산합니다.
# .isnull()로 결측치를 True로, 아니면 False로 변환
# .sum()으로 True(결측치)의 개수를 합산
missing_counts_in_pattern_cols = filtered_by_area[live_cmrcl_stts_columns].isnull().sum()

# 4. 결측치가 있는 컬럼들만 필터링하여 출력합니다.
# 0보다 큰 값 (즉, 결측치가 존재하는 컬럼)만 선택
missing_live_cmrcl_stts_columns_counts = missing_counts_in_pattern_cols[missing_counts_in_pattern_cols > 0]

print("주어진 'CITYDATA.AREA_NM' 값과 'LIVE_CMRCL_STTS' 패턴을 가지는 칼럼들의 결측치 개수:")
if not missing_live_cmrcl_stts_columns_counts.empty:
    for col, count in missing_live_cmrcl_stts_columns_counts.items():
        print(f"  - '{col}': {count} 개")
else:
    print("  해당 조건에 맞는 결측치가 없습니다.")


# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog `hive_metastore`; select * from `default`.`seoul_city_data_full_20250707_175748` limit 100;

# COMMAND ----------

# MAGIC %md
# MAGIC ### 결측치가 있는 칼럼은 다음과 같다
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTON_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTON_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTOFF_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTOFF_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_30WTHN_GTON_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_30WTHN_GTON_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_30WTHN_GTOFF_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_30WTHN_GTOFF_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTON_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTON_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTOFF_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTOFF_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_5WTHN_GTON_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_5WTHN_GTON_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_5WTHN_GTOFF_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_5WTHN_GTOFF_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_STN_CNT',\
# MAGIC 'CITYDATA.LIVE_SUB_PPLTN.SUB_STN_TIME',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTON_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTON_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTOFF_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTOFF_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTON_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTON_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTOFF_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTOFF_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTON_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTON_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTOFF_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTOFF_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTON_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTON_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTOFF_PPLTN_MIN',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTOFF_PPLTN_MAX',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_STN_CNT',\
# MAGIC 'CITYDATA.LIVE_BUS_PPLTN.BUS_STN_TIME',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.AREA_CMRCL_LVL',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_CNT',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MIN',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MAX',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_RSB',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_MALE_RATE',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_FEMALE_RATE',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_10_RATE',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_20_RATE',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_30_RATE',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_40_RATE',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_50_RATE',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_60_RATE',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_PERSONAL_RATE',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_CORPORATION_RATE',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_TIME',\
# MAGIC 'CITYDATA.LIVE_CMRCL_STTS'
# MAGIC \
# MAGIC \
# MAGIC \
# MAGIC
# MAGIC ###결측치 수치 비교
# MAGIC
# MAGIC **결측치와 정상 값의 수치는 다음과 같다**
# MAGIC
# MAGIC _(비율 설명:
# MAGIC 0 = 결측치 없음, 1 = 전부 결측치)_
# MAGIC
# MAGIC list_total_count                                              0.000000\
# MAGIC RESULT.RESULT.CODE                                            0.000000\
# MAGIC RESULT.RESULT.MESSAGE                                         0.000000\
# MAGIC CITYDATA.AREA_NM                                              0.000000\
# MAGIC CITYDATA.AREA_CD                                              0.000000\
# MAGIC CITYDATA.LIVE_PPLTN_STTS                                      0.000000\
# MAGIC CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_MSG             0.000000\
# MAGIC CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_IDX     0.000000\
# MAGIC CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_SPD     0.000000\
# MAGIC CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_TIME    0.000000\
# MAGIC CITYDATA.ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS                  0.000000\
# MAGIC CITYDATA.PRK_STTS                                             0.000000\
# MAGIC CITYDATA.SUB_STTS                                             0.000000\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTON_PPLTN_MIN               0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTON_PPLTN_MAX               0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTOFF_PPLTN_MIN              0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTOFF_PPLTN_MAX              0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_30WTHN_GTON_PPLTN_MIN             0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_30WTHN_GTON_PPLTN_MAX             0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_30WTHN_GTOFF_PPLTN_MIN            0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_30WTHN_GTOFF_PPLTN_MAX            0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTON_PPLTN_MIN             0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTON_PPLTN_MAX             0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTOFF_PPLTN_MIN            0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTOFF_PPLTN_MAX            0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_5WTHN_GTON_PPLTN_MIN              0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_5WTHN_GTON_PPLTN_MAX              0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_5WTHN_GTOFF_PPLTN_MIN             0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_5WTHN_GTOFF_PPLTN_MAX             0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_STN_CNT                           0.326667\
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_STN_TIME                          0.326667\
# MAGIC CITYDATA.BUS_STN_STTS                                         0.000000\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTON_PPLTN_MIN               0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTON_PPLTN_MAX               0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTOFF_PPLTN_MIN              0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTOFF_PPLTN_MAX              0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTON_PPLTN_MIN             0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTON_PPLTN_MAX             0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTOFF_PPLTN_MIN            0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTOFF_PPLTN_MAX            0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTON_PPLTN_MIN             0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTON_PPLTN_MAX             0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTOFF_PPLTN_MIN            0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTOFF_PPLTN_MAX            0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTON_PPLTN_MIN              0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTON_PPLTN_MAX              0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTOFF_PPLTN_MIN             0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTOFF_PPLTN_MAX             0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_STN_CNT                           0.233333\
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_STN_TIME                          0.233333\
# MAGIC CITYDATA.ACDNT_CNTRL_STTS                                     0.000000\
# MAGIC CITYDATA.SBIKE_STTS                                           0.000000\
# MAGIC CITYDATA.WEATHER_STTS                                         0.000000\
# MAGIC CITYDATA.CHARGER_STTS                                         0.000000\
# MAGIC CITYDATA.EVENT_STTS                                           0.000000\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.AREA_CMRCL_LVL                       0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_CNT                  0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MIN              0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MAX              0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_RSB                            0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_MALE_RATE                      0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_FEMALE_RATE                    0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_10_RATE                        0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_20_RATE                        0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_30_RATE                        0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_40_RATE                        0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_50_RATE                        0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_60_RATE                        0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_PERSONAL_RATE                  0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_CORPORATION_RATE               0.316667\
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_TIME                           0.316667\
# MAGIC AREA_NAME_QUERY                                               0.000000\
# MAGIC CITYDATA.LIVE_CMRCL_STTS                                      1.000000\
# MAGIC \
# MAGIC \
# MAGIC **`CITYDATA.LIVE_CMRCL_STTS.CMRCL_` 패턴 컬럼 중 하나라도 결측치가 있는 행의 'CITYDATA.AREA_NM'은 다음과 같다:**
# MAGIC \
# MAGIC 경복궁\
# MAGIC 서울 암사동 유적\
# MAGIC 창덕궁·종묘\
# MAGIC 삼각지역\
# MAGIC 강서한강공원\
# MAGIC 고척돔\
# MAGIC 광나루한강공원\
# MAGIC 광화문광장\
# MAGIC 국립중앙박물관·용산가족공원\
# MAGIC 난지한강공원\
# MAGIC 남산공원\
# MAGIC 노들섬\
# MAGIC 뚝섬한강공원\
# MAGIC 망원한강공원\
# MAGIC 반포한강공원\
# MAGIC 북서울꿈의숲\
# MAGIC 서리풀공원·몽마르뜨공원\
# MAGIC 서울광장\
# MAGIC 서울대공원\
# MAGIC 서울숲공원\
# MAGIC 아차산\
# MAGIC 양화한강공원\
# MAGIC 어린이대공원\
# MAGIC 여의도한강공원\
# MAGIC 월드컵공원\
# MAGIC 응봉산\
# MAGIC 이촌한강공원\
# MAGIC 잠실종합운동장\
# MAGIC 잠실한강공원\
# MAGIC 잠원한강공원\
# MAGIC 청계산\
# MAGIC 청와대\
# MAGIC 보라매공원\
# MAGIC 서대문독립공원\
# MAGIC 안양천\
# MAGIC 여의서로\
# MAGIC 올림픽공원\
# MAGIC 홍제폭포\
# MAGIC \
# MAGIC \
# MAGIC **위의 지역명과 'LIVE_CMRCL_STTS' 패턴을 가지는 칼럼들의 결측치 개수는 다음과 같다:**
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.AREA_CMRCL_LVL': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_CNT': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MIN': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MAX': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_RSB': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_MALE_RATE': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_FEMALE_RATE': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_10_RATE': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_20_RATE': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_30_RATE': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_40_RATE': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_50_RATE': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_60_RATE': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_PERSONAL_RATE': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_CORPORATION_RATE': 760 개
# MAGIC   - 'CITYDATA.LIVE_CMRCL_STTS.CMRCL_TIME': 760 개
# MAGIC \
# MAGIC \
# MAGIC \
# MAGIC \
# MAGIC ###결측치가 없는 행은 다음과 같다
# MAGIC 강남 MICE 관광특구\
# MAGIC 동대문 관광특구\
# MAGIC 명동 관광특구\
# MAGIC 이태원 관광특구\
# MAGIC 잠실 관광특구\
# MAGIC 종로·청계 관광특구\
# MAGIC 홍대 관광특구\
# MAGIC 광화문·덕수궁\
# MAGIC 보신각\
# MAGIC 가산디지털단지역\
# MAGIC 강남역\
# MAGIC 건대입구역\
# MAGIC 고덕역\
# MAGIC 고속터미널역\
# MAGIC 교대역\
# MAGIC 구로디지털단지역\
# MAGIC 구로역\
# MAGIC 군자역\
# MAGIC 대림역\
# MAGIC 동대문역\
# MAGIC 뚝섬역\
# MAGIC 미아사거리역\
# MAGIC 발산역\
# MAGIC 사당역\
# MAGIC 서울대입구역\
# MAGIC 서울식물원·마곡나루역\
# MAGIC 서울역\
# MAGIC 선릉역\
# MAGIC 성신여대입구역\
# MAGIC 수유역\
# MAGIC 신논현역·논현역\
# MAGIC 신도림역\
# MAGIC 신림역\
# MAGIC 신촌·이대역\
# MAGIC 양재역\
# MAGIC 역삼역\
# MAGIC 연신내역\
# MAGIC 오목교역·목동운동장\
# MAGIC 왕십리역\
# MAGIC 용산역\
# MAGIC 이태원역\
# MAGIC 장지역\
# MAGIC 장한평역\
# MAGIC 천호역\
# MAGIC 총신대입구(이수)역\
# MAGIC 충정로역\
# MAGIC 합정역\
# MAGIC 혜화역\
# MAGIC 홍대입구역(2호선)\
# MAGIC 회기역\
# MAGIC 가락시장\
# MAGIC 가로수길\
# MAGIC 광장(전통)시장\
# MAGIC 김포공항\
# MAGIC 노량진\
# MAGIC 덕수궁길·정동길\
# MAGIC 북촌한옥마을\
# MAGIC 서촌\
# MAGIC 성수카페거리\
# MAGIC 쌍문역\
# MAGIC 압구정로데오거리\
# MAGIC 여의도\
# MAGIC 영등포 타임스퀘어\
# MAGIC 용리단길\
# MAGIC 이태원 앤틱가구거리\
# MAGIC 인사동\
# MAGIC 창동 신경제 중심지\
# MAGIC 청담동 명품거리\
# MAGIC 청량리 제기동 일대 전통시장\
# MAGIC DDP(동대문디자인플라자)\
# MAGIC DMC(디지털미디어시티)\
# MAGIC 남대문시장\
# MAGIC 익선동\
# MAGIC 신정네거리역\
# MAGIC 잠실새내역\
# MAGIC 잠실역\
# MAGIC 잠실롯데타워 일대\
# MAGIC 송리단길·호수단길\
# MAGIC 신촌 스타광장\
# MAGIC \
# MAGIC \
# MAGIC **결측치가 있는 행과 결측치의 갯수는 다음과 같다**\
# MAGIC \
# MAGIC 지역: DDP(동대문디자인플라자), 결측치 개수: 37\
# MAGIC 지역: DMC(디지털미디어시티), 결측치 개수: 37\
# MAGIC 지역: 가락시장, 결측치 개수: 37\
# MAGIC 지역: 가로수길, 결측치 개수: 37\
# MAGIC 지역: 가산디지털단지역, 결측치 개수: 37\
# MAGIC 지역: 강남 MICE 관광특구, 결측치 개수: 37\
# MAGIC 지역: 강남역, 결측치 개수: 37\
# MAGIC 지역: 강서한강공원, 결측치 개수: 35\
# MAGIC 지역: 강서한강공원, 결측치 개수: 53\
# MAGIC 지역: 건대입구역, 결측치 개수: 37\
# MAGIC 지역: 경복궁, 결측치 개수: 17\
# MAGIC 지역: 경복궁, 결측치 개수: 53\
# MAGIC 지역: 고덕역, 결측치 개수: 37\
# MAGIC 지역: 고속터미널역, 결측치 개수: 37\
# MAGIC 지역: 고척돔, 결측치 개수: 17\
# MAGIC 지역: 고척돔, 결측치 개수: 53\
# MAGIC 지역: 광나루한강공원, 결측치 개수: 53\
# MAGIC 지역: 광장(전통)시장, 결측치 개수: 37\
# MAGIC 지역: 광화문·덕수궁, 결측치 개수: 37\
# MAGIC 지역: 광화문광장, 결측치 개수: 17\
# MAGIC 지역: 광화문광장, 결측치 개수: 53\
# MAGIC 지역: 교대역, 결측치 개수: 37\
# MAGIC 지역: 구로디지털단지역, 결측치 개수: 37\
# MAGIC 지역: 구로역, 결측치 개수: 37\
# MAGIC 지역: 국립중앙박물관·용산가족공원, 결측치 개수: 17\
# MAGIC 지역: 국립중앙박물관·용산가족공원, 결측치 개수: 53\
# MAGIC 지역: 군자역, 결측치 개수: 37\
# MAGIC 지역: 김포공항, 결측치 개수: 37\
# MAGIC 지역: 난지한강공원, 결측치 개수: 35\
# MAGIC 지역: 난지한강공원, 결측치 개수: 53\
# MAGIC 지역: 남대문시장, 결측치 개수: 37\
# MAGIC 지역: 남산공원, 결측치 개수: 17\
# MAGIC 지역: 남산공원, 결측치 개수: 53\
# MAGIC 지역: 노들섬, 결측치 개수: 35\
# MAGIC 지역: 노들섬, 결측치 개수: 53\
# MAGIC 지역: 노량진, 결측치 개수: 37\
# MAGIC 지역: 대림역, 결측치 개수: 37\
# MAGIC 지역: 덕수궁길·정동길, 결측치 개수: 37\
# MAGIC 지역: 동대문 관광특구, 결측치 개수: 37\
# MAGIC 지역: 동대문역, 결측치 개수: 37\
# MAGIC 지역: 뚝섬역, 결측치 개수: 37\
# MAGIC 지역: 뚝섬한강공원, 결측치 개수: 17\
# MAGIC 지역: 뚝섬한강공원, 결측치 개수: 53\
# MAGIC 지역: 망원한강공원, 결측치 개수: 17\
# MAGIC 지역: 망원한강공원, 결측치 개수: 53\
# MAGIC 지역: 명동 관광특구, 결측치 개수: 37\
# MAGIC 지역: 미아사거리역, 결측치 개수: 37\
# MAGIC 지역: 반포한강공원, 결측치 개수: 35\
# MAGIC 지역: 반포한강공원, 결측치 개수: 53\
# MAGIC 지역: 발산역, 결측치 개수: 37\
# MAGIC 지역: 보라매공원, 결측치 개수: 17\
# MAGIC 지역: 보라매공원, 결측치 개수: 53\
# MAGIC 지역: 보신각, 결측치 개수: 37\
# MAGIC 지역: 북서울꿈의숲, 결측치 개수: 35\
# MAGIC 지역: 북서울꿈의숲, 결측치 개수: 53\
# MAGIC 지역: 북창동 먹자골목, 결측치 개수: 19\
# MAGIC 지역: 북창동 먹자골목, 결측치 개수: 37\
# MAGIC 지역: 북촌한옥마을, 결측치 개수: 37\
# MAGIC 지역: 사당역, 결측치 개수: 37\
# MAGIC 지역: 삼각지역, 결측치 개수: 17\
# MAGIC 지역: 삼각지역, 결측치 개수: 53\
# MAGIC 지역: 서대문독립공원, 결측치 개수: 17\
# MAGIC 지역: 서대문독립공원, 결측치 개수: 53\
# MAGIC 지역: 서리풀공원·몽마르뜨공원, 결측치 개수: 17\
# MAGIC 지역: 서리풀공원·몽마르뜨공원, 결측치 개수: 53\
# MAGIC 지역: 서울 암사동 유적, 결측치 개수: 35\
# MAGIC 지역: 서울 암사동 유적, 결측치 개수: 53\
# MAGIC 지역: 서울광장, 결측치 개수: 17\
# MAGIC 지역: 서울광장, 결측치 개수: 53\
# MAGIC 지역: 서울대공원, 결측치 개수: 35\
# MAGIC 지역: 서울대공원, 결측치 개수: 53\
# MAGIC 지역: 서울대입구역, 결측치 개수: 37\
# MAGIC 지역: 서울숲공원, 결측치 개수: 17\
# MAGIC 지역: 서울숲공원, 결측치 개수: 53\
# MAGIC 지역: 서울식물원·마곡나루역, 결측치 개수: 37\
# MAGIC 지역: 서울역, 결측치 개수: 37\
# MAGIC 지역: 서촌, 결측치 개수: 37\
# MAGIC 지역: 선릉역, 결측치 개수: 37\
# MAGIC 지역: 성수카페거리, 결측치 개수: 37\
# MAGIC 지역: 성신여대입구역, 결측치 개수: 37\
# MAGIC 지역: 송리단길·호수단길, 결측치 개수: 37\
# MAGIC 지역: 수유역, 결측치 개수: 37\
# MAGIC 지역: 신논현역·논현역, 결측치 개수: 37\
# MAGIC 지역: 신도림역, 결측치 개수: 37\
# MAGIC 지역: 신림역, 결측치 개수: 37\
# MAGIC 지역: 신정네거리역, 결측치 개수: 37\
# MAGIC 지역: 신촌 스타광장, 결측치 개수: 37\
# MAGIC 지역: 신촌·이대역, 결측치 개수: 37\
# MAGIC 지역: 쌍문역, 결측치 개수: 37\
# MAGIC 지역: 아차산, 결측치 개수: 35\
# MAGIC 지역: 아차산, 결측치 개수: 53\
# MAGIC 지역: 안양천, 결측치 개수: 35\
# MAGIC 지역: 안양천, 결측치 개수: 53\
# MAGIC 지역: 압구정로데오거리, 결측치 개수: 37\
# MAGIC 지역: 양재역, 결측치 개수: 37\
# MAGIC 지역: 양화한강공원, 결측치 개수: 35\
# MAGIC 지역: 양화한강공원, 결측치 개수: 53\
# MAGIC 지역: 어린이대공원, 결측치 개수: 17\
# MAGIC 지역: 어린이대공원, 결측치 개수: 53\
# MAGIC 지역: 여의도, 결측치 개수: 37\
# MAGIC 지역: 여의도한강공원, 결측치 개수: 17\
# MAGIC 지역: 여의도한강공원, 결측치 개수: 53\
# MAGIC 지역: 여의서로, 결측치 개수: 53\
# MAGIC 지역: 역삼역, 결측치 개수: 37\
# MAGIC 지역: 연남동, 결측치 개수: 19\
# MAGIC 지역: 연남동, 결측치 개수: 37\
# MAGIC 지역: 연신내역, 결측치 개수: 37\
# MAGIC 지역: 영등포 타임스퀘어, 결측치 개수: 37\
# MAGIC 지역: 오목교역·목동운동장, 결측치 개수: 37\
# MAGIC 지역: 올림픽공원, 결측치 개수: 17\
# MAGIC 지역: 올림픽공원, 결측치 개수: 53\
# MAGIC 지역: 왕십리역, 결측치 개수: 37\
# MAGIC 지역: 용리단길, 결측치 개수: 37\
# MAGIC 지역: 용산역, 결측치 개수: 37\
# MAGIC 지역: 월드컵공원, 결측치 개수: 17\
# MAGIC 지역: 월드컵공원, 결측치 개수: 53\
# MAGIC 지역: 응봉산, 결측치 개수: 17\
# MAGIC 지역: 응봉산, 결측치 개수: 53\
# MAGIC 지역: 이촌한강공원, 결측치 개수: 35\
# MAGIC 지역: 이촌한강공원, 결측치 개수: 53\
# MAGIC 지역: 이태원 관광특구, 결측치 개수: 37\
# MAGIC 지역: 이태원 앤틱가구거리, 결측치 개수: 37\
# MAGIC 지역: 이태원역, 결측치 개수: 37\
# MAGIC 지역: 익선동, 결측치 개수: 37\
# MAGIC 지역: 인사동, 결측치 개수: 37\
# MAGIC 지역: 잠실 관광특구, 결측치 개수: 37\
# MAGIC 지역: 잠실롯데타워 일대, 결측치 개수: 37\
# MAGIC 지역: 잠실새내역, 결측치 개수: 37\
# MAGIC 지역: 잠실역, 결측치 개수: 37\
# MAGIC 지역: 잠실종합운동장, 결측치 개수: 17\
# MAGIC 지역: 잠실종합운동장, 결측치 개수: 53\
# MAGIC 지역: 잠실한강공원, 결측치 개수: 17\
# MAGIC 지역: 잠실한강공원, 결측치 개수: 53\
# MAGIC 지역: 잠원한강공원, 결측치 개수: 35\
# MAGIC 지역: 잠원한강공원, 결측치 개수: 53\
# MAGIC 지역: 장지역, 결측치 개수: 37\
# MAGIC 지역: 장한평역, 결측치 개수: 37\
# MAGIC 지역: 종로·청계 관광특구, 결측치 개수: 37\
# MAGIC 지역: 창덕궁·종묘, 결측치 개수: 17\
# MAGIC 지역: 창덕궁·종묘, 결측치 개수: 53\
# MAGIC 지역: 창동 신경제 중심지, 결측치 개수: 37\
# MAGIC 지역: 천호역, 결측치 개수: 37\
# MAGIC 지역: 청계산, 결측치 개수: 35\
# MAGIC 지역: 청계산, 결측치 개수: 53\
# MAGIC 지역: 청담동 명품거리, 결측치 개수: 37\
# MAGIC 지역: 청량리 제기동 일대 전통시장, 결측치 개수: 37\
# MAGIC 지역: 청와대, 결측치 개수: 53\
# MAGIC 지역: 총신대입구(이수)역, 결측치 개수: 37\
# MAGIC 지역: 충정로역, 결측치 개수: 37\
# MAGIC 지역: 합정역, 결측치 개수: 37\
# MAGIC 지역: 해방촌·경리단길, 결측치 개수: 19\
# MAGIC 지역: 해방촌·경리단길, 결측치 개수: 37\
# MAGIC 지역: 혜화역, 결측치 개수: 37\
# MAGIC 지역: 홍대 관광특구, 결측치 개수: 37\
# MAGIC 지역: 홍대입구역(2호선), 결측치 개수: 37\
# MAGIC 지역: 홍제폭포, 결측치 개수: 53\
# MAGIC 지역: 회기역, 결측치 개수: 37\
# MAGIC \
# MAGIC **실시간 지하철 승하차인원 (LIVE_SUB_PPLTN),\
# MAGIC 실시간 버스의 승하차인원 (LIVE_BUS_PPLTN),\
# MAGIC 실시간 상권 현황 (LIVE_CMRCL_STTS) 에 결측치가 발생하는 것을 볼 수 있다.**

# COMMAND ----------

# MAGIC %md
# MAGIC ###결측치 분석
# MAGIC 위의 결과로 미루어 보았을 때\
# MAGIC **버스 승하차 정보**를 제공하지 않는 지역과,\
# MAGIC **지하철 승하차 정보**를 제공하지 않는 지역과,\
# MAGIC **실시간 상권 현황**을 제공하지 않는 지역과,\
# MAGIC **결제데이터**를 제공하지 않는 지역이 있다고 생각했지만\
# MAGIC \
# MAGIC 결측치가 있는 행과 결측치가 없는 행의 AREA_NM 을 출력해 본 결과\
# MAGIC **새벽에 버스/지하철 데이터를 제공하지 않아** 없다고 나온 것으로 파악되었다.\
# MAGIC 대중교통 시스템의 에러라고 생각할 수도 있었지만, BUS_STN 항목과 SUB_STTS 항목의 결측치가 관측되지 않아 에러는 아니라고 판단하였다.\
# MAGIC 이 점을 응용하여 BUS_STN, 또는 SUB_STTS 항목의 결측치가 관측되면 대중교통 정보 제공시스템의 오작동이 발생했다고 판단하는 것이 가능해 진다.\
# MAGIC \
# MAGIC \
# MAGIC **다음은 실시간 상권 / 결제 데이터의 결측치에 대한 분석이다**.\
# MAGIC 상권, 결제 횟수 또한 결측치가 확인되었다.
# MAGIC 이 결측치도 대중교통 데이터처럼 새벽에 제공하지 않는 것이라고 생각했지만,\
# MAGIC 결측치의 CITYDATA.AREA_NM 값에 대한 결측치의 갯수를 출력해 본 후\
# MAGIC 단순히 결제 데이터를 제공하지 않는 것으로 파악되었다.
# MAGIC
# MAGIC \
# MAGIC 또한 ``CITYDATA.LIVE_CMRCL_STTS`` \
# MAGIC 라는 칼럼은 더 이상 사용되지 않는 것인지 모든 **행이 결측치**인 것을 볼 수 있다.

# COMMAND ----------

# MAGIC %md
# MAGIC # 3. 이상치 확인

# COMMAND ----------

# MAGIC %md
# MAGIC #### 목적
# MAGIC #### 이상치가 데이터에 미치는 영향(평균, 분산 왜곡 등) 고려
# MAGIC
# MAGIC #### 제거 또는 변환(Log, Capping 등) 전략 수립

# COMMAND ----------

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 수치형 데이터만 추출
numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
df_numeric = df[numeric_cols]

# 1. 박스플롯 시각화
plt.figure(figsize=(15, 6))
sns.boxplot(data=pdf_numeric, orient='h')
plt.title("Boxplot of Numeric Columns")
plt.tight_layout()
plt.show()

# 2. IQR 기준 이상치 비율 계산
outlier_ratio = {}
for col in numeric_cols:
    Q1 = df_numeric[col].quantile(0.25)
    Q3 = df_numeric[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    outliers = ((pdf_numeric[col] < lower) | (pdf_numeric[col] > upper)).sum()
    ratio = outliers / len(pdf_numeric[col])
    outlier_ratio[col] = round(ratio * 100, 2)

# 결과를 DataFrame으로 정리
outlier_df = pd.DataFrame({
    "Column": list(outlier_ratio.keys()),
    "Outlier Ratio (%)": list(outlier_ratio.values())
}).sort_values(by="Outlier Ratio (%)", ascending=False)

# 이상치 비율 출력
print(outlier_df.to_string(index=False))


# COMMAND ----------

# MAGIC %md
# MAGIC 칼럼의 수가 너무 많고 각 칼럼당 단위가 맞지 않는 경우가 있으므로 이상치 비율이 높은 컬럼에 대해서만 필터링하여 수행하자.

# COMMAND ----------

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 2. 수치형 컬럼만 추출
numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
df_numeric = df[numeric_cols]

# 3. 이상치 비율 계산 (IQR 기준)
outlier_ratio = {}
for col in numeric_cols:
    Q1 = df_numeric[col].quantile(0.25)
    Q3 = df_numeric[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    outliers = ((df_numeric[col] < lower) | (df_numeric[col] > upper)).sum()
    ratio = outliers / len(df_numeric[col])
    outlier_ratio[col] = round(ratio * 100, 2)

# 4. 이상치 비율이 5% 이상인 컬럼 필터링
threshold = 5.0
filtered_cols = [col for col, ratio in outlier_ratio.items() if ratio >= threshold]

# 5. 이상치 비율 표 생성
filtered_outlier_df = pd.DataFrame({
    "Column": filtered_cols,
    "Outlier Ratio (%)": [outlier_ratio[col] for col in filtered_cols]
}).sort_values(by="Outlier Ratio (%)", ascending=False)

# 6. 박스플롯 시각화
if filtered_cols:
    plt.figure(figsize=(15, len(filtered_cols) * 0.6))
    sns.boxplot(data=df_numeric[filtered_cols], orient='h')
    plt.title(f"Boxplot of Columns with Outlier Ratio ≥ {threshold}%")
    plt.tight_layout()
    plt.show()
else:
    print(f"이상치 비율이 {threshold}% 이상인 수치형 컬럼이 없습니다.")

# 7. 이상치 비율 출력
if not filtered_outlier_df.empty:
    print(filtered_outlier_df.to_string(index=False))


# COMMAND ----------

# MAGIC %md
# MAGIC 단위가 너무 큰 CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MIN ,CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MAX 를 제외하고 다시 박스플롯을 내보자

# COMMAND ----------

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 2. 수치형 컬럼만 추출
numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns

# 3. 제외할 컬럼 정의
excluded_cols = [
    "CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MIN",
    "CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MAX"
]

# 4. 이상치 비율 계산 (IQR 기준)
outlier_ratio = {}
for col in numeric_cols:
    if col in excluded_cols:
        continue
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    outliers = ((df[col] < lower) | (df[col] > upper)).sum()
    ratio = outliers / len(df[col])
    outlier_ratio[col] = round(ratio * 100, 2)

# 5. 이상치 비율 5% 이상인 컬럼만 필터링
threshold = 5.0
filtered_cols = [col for col, ratio in outlier_ratio.items() if ratio >= threshold]

# 6. 박스플롯 시각화 (제외한 컬럼은 반영 안됨)
if filtered_cols:
    plt.figure(figsize=(15, len(filtered_cols) * 0.6))
    sns.boxplot(data=df[filtered_cols], orient='h')
    plt.title(f"Boxplot of Columns with Outlier Ratio ≥ {threshold}%, Excluding Specified Columns")
    plt.tight_layout()
    plt.show()
else:
    print(f"이상치 비율이 {threshold}% 이상이면서 제외 대상이 아닌 수치형 컬럼이 없습니다.")

# 7. 이상치 비율 표 출력
filtered_outlier_df = pd.DataFrame({
    "Column": filtered_cols,
    "Outlier Ratio (%)": [outlier_ratio[col] for col in filtered_cols]
}).sort_values(by="Outlier Ratio (%)", ascending=False)

if not filtered_outlier_df.empty:
    print(filtered_outlier_df.to_string(index=False))


# COMMAND ----------

# MAGIC %md
# MAGIC ## ( ? ) 대시보드를 구축함에 있어 이상치를 어떻게 봐야할까? 알람의 근거일까 ?

# COMMAND ----------

# MAGIC %md
# MAGIC 해당 데이터를 기준으로 ML을 할 경우에는 이상치 처리를 해야되지만, 저희는 대시보드를 구축하는게 목표이므로 해당 수치를 어떻게 처리하여 대시보드를 구축할지 생각해야할 것 같습니다.   
# MAGIC (1) 이상치가 많은 칼럼은 어떤 특성이 있는가   
# MAGIC (2) 이상치 자체를 어떻게 대해야 하는가 ( 알람? 경고? 비즈니스적 기회? 특정 시간대에 대한 니즈 ? )    

# COMMAND ----------

# MAGIC %md
# MAGIC ### 가설) 이상치가 높은 (5%이상) 칼럼들이 나타내는 것은 "비즈니스적 신호"가 아닌가? 예) 10대 소비율 이상치가 기록된 곳은 18~20시(하교시간, 학원 등교시간)대의 대치동(고학군)이다 라던가
# MAGIC
# MAGIC #### 따라서, 각 이상치들이 기록하는 시간대와 지역을 확인해봐야겠다
# MAGIC CMRCL_TIME -> 시간   
# MAGIC CITYDATA.AREA_NM  -> 지역

# COMMAND ----------

# MAGIC %sh
# MAGIC sudo apt-get update
# MAGIC sudo apt-get install -y fonts-nanum
# MAGIC

# COMMAND ----------

import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# 폰트 경로 직접 지정
font_path = '/usr/share/fonts/truetype/nanum/NanumGothic.ttf'
font_prop = fm.FontProperties(fname=font_path)

# 전역 설정
plt.rcParams['font.family'] = font_prop.get_name()
plt.rcParams['axes.unicode_minus'] = False


# COMMAND ----------

import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import os

# 1. 폰트 경로 확인
font_path = "/usr/share/fonts/truetype/nanum/NanumGothic.ttf"

# 2. 폰트 존재 여부 확인 및 설정
if os.path.exists(font_path):
    font_prop = fm.FontProperties(fname=font_path)
    font_name = font_prop.get_name()

    # 3. matplotlib에 등록
    plt.rcParams["font.family"] = font_name
    plt.rcParams["axes.unicode_minus"] = False

    print(f"✅ 한글 폰트 설정 완료: {font_name}")
else:
    print("❌ NanumGothic.ttf 경로에 폰트가 없습니다. 설치가 안 된 것 같습니다.")


# COMMAND ----------

import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import os

# NanumGothic 경로 (설치 후 경로 그대로 사용)
font_path = "/usr/share/fonts/truetype/nanum/NanumGothic.ttf"

# 1. 직접 matplotlib에 등록
fm.fontManager.addfont(font_path)

# 2. 등록한 폰트의 정확한 이름 얻기
font_name = fm.FontProperties(fname=font_path).get_name()
print(f"✅ 등록된 폰트 이름: {font_name}")

# 3. 전역 설정으로 기본 폰트 지정
plt.rcParams["font.family"] = font_name
plt.rcParams["axes.unicode_minus"] = False


# COMMAND ----------

import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# 폰트 경로 지정
font_path = "/usr/share/fonts/truetype/nanum/NanumGothic.ttf"
font_prop = fm.FontProperties(fname=font_path)

plt.figure(figsize=(6, 4))
plt.title("한글 테스트: 서울 상권", fontproperties=font_prop)
plt.plot([1, 2, 3], [1, 4, 9])
plt.xlabel("시간대", fontproperties=font_prop)
plt.ylabel("매출액", fontproperties=font_prop)
plt.grid(True)
plt.show()


# COMMAND ----------

# Step 1. 이상치 비율이 5% 초과하는 컬럼들 

outlier_ratio = {}
for col in numeric_cols:
    if col in excluded_cols:
        continue
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    outliers = ((df[col] < lower) | (df[col] > upper)).sum()
    ratio = outliers / len(df[col])
    outlier_ratio[col] = round(ratio * 100, 2)

# 이상치 비율 5% 초과 컬럼들
cols_over_5pct = [col for col, ratio in outlier_ratio.items() if ratio > 5]

# Step 2. 이상치 데이터 필터링 및 산점도 그리기 코드
import matplotlib.pyplot as plt
import seaborn as sns

for col in cols_over_5pct:
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    
    # 이상치 데이터 필터링
    outlier_df = df[(df[col] < lower) | (df[col] > upper)]
    
    plt.figure(figsize=(10, 6))
    sns.scatterplot(
        data=outlier_df,
        x='CITYDATA.LIVE_CMRCL_STTS.CMRCL_TIME',
        y='CITYDATA.AREA_NM',
        hue=col,
        palette='viridis',
        legend='brief'
    )
    plt.title(f'Outliers Distribution for {col}')
    plt.xlabel('CITYDATA.LIVE_CMRCL_STTS.CMRCL_TIME')
    plt.ylabel('CITYDATA.AREA_NM')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()


# COMMAND ----------

import matplotlib.pyplot as plt
import seaborn as sns

for col in cols_over_5pct:
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR

    # 이상치 데이터 필터링
    outlier_df = df[(df[col] < lower) | (df[col] > upper)]

    # 고유 지역 개수에 따라 동적으로 figure 크기 조정
    num_areas = outlier_df['CITYDATA.AREA_NM'].nunique()
    fig_height = max(6, num_areas * 0.3)  # 최소 6, 지역 1개당 0.3 높이

    plt.figure(figsize=(12, fig_height))
    sns.scatterplot(
        data=outlier_df,
        x='CITYDATA.LIVE_CMRCL_STTS.CMRCL_TIME',
        y='CITYDATA.AREA_NM',
        hue=col,
        palette='viridis',
        legend='brief'
    )
    plt.title(f'Outliers Distribution for {col}')
    plt.xlabel('CITYDATA.LIVE_CMRCL_STTS.CMRCL_TIME')
    plt.ylabel('CITYDATA.AREA_NM')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()


# COMMAND ----------

# MAGIC %md
# MAGIC #### 확실히 시간 및 공간(지역)으로 분류하니 경향성이 보이는 항목이 있었다.    
# MAGIC #### 다만 시간(가로선) 이나 지역(세로선)에서 경향이 보이지 않는 경우는 해당 축에 대해서 독립되었을 수도 있으므로 다른 변인을 고려하거나 나머지 축 하나에 대해서 경향성이 있으면 그 경향성이 강한것으로 판단하자.

# COMMAND ----------

# MAGIC %md
# MAGIC # [4] 변수 분포 확인

# COMMAND ----------

# MAGIC %md
# MAGIC  목적   
# MAGIC 변수 분포 비대칭성 확인 → 스케일링, 정규화 여부 판단
# MAGIC
# MAGIC 범주형 변수의 불균형 확인

# COMMAND ----------

import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

font_path = "/usr/share/fonts/truetype/nanum/NanumGothic.ttf"
fm.fontManager.addfont(font_path)
font_name = fm.FontProperties(fname=font_path).get_name()
print(f"✅ 폰트 이름: {font_name}")

plt.rcParams["font.family"] = font_name
plt.rcParams["axes.unicode_minus"] = False


# COMMAND ----------

import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import seaborn as sns
import pandas as pd
import numpy as np
import math
import os

# ✅ 1. 한글 폰트 설정 (NanumGothic 또는 대체 폰트)
font_path = "/usr/share/fonts/truetype/nanum/NanumGothic.ttf"
if os.path.exists(font_path):
    font_prop = fm.FontProperties(fname=font_path)
    plt.rcParams["font.family"] = font_prop.get_name()
    plt.rcParams["axes.unicode_minus"] = False
    print(f"✅ 한글 폰트 설정 완료: {font_prop.get_name()}")
else:
    print("⚠️ NanumGothic.ttf 파일이 없습니다. 한글이 깨질 수 있습니다.")

# ✅ 2. 샘플링 (속도 개선)
sample_df = df.sample(n=min(10000, len(df)), random_state=42)

# ✅ 3. 수치형/범주형 컬럼 자동 분리
numeric_cols = sample_df.select_dtypes(include=np.number).columns.tolist()
categorical_cols = sample_df.select_dtypes(exclude=np.number).columns.tolist()

# ✅ 4. 수치형 subplot 시각화
n_num = len(numeric_cols)
rows_num = math.ceil(n_num / 2)
fig, axes = plt.subplots(rows_num, 2, figsize=(14, 3.5 * rows_num))
axes = axes.flatten()

for i, col in enumerate(numeric_cols):
    sns.histplot(data=sample_df, x=col, kde=True, ax=axes[i], bins=30, color='skyblue')
    axes[i].set_title(f"[수치형] {col}", fontproperties=font_prop)
    axes[i].set_xlabel(col, fontproperties=font_prop)

# 불필요 subplot 제거
for j in range(i+1, len(axes)):
    fig.delaxes(axes[j])

plt.tight_layout()
plt.show()

# ✅ 5. 범주형 subplot 시각화
n_cat = len(categorical_cols)
rows_cat = math.ceil(n_cat / 2)
fig, axes = plt.subplots(rows_cat, 2, figsize=(14, 4 * rows_cat))
axes = axes.flatten()

for i, col in enumerate(categorical_cols):
    top_categories = sample_df[col].value_counts().index[:10]
    sns.countplot(data=sample_df, x=col, order=top_categories, ax=axes[i], palette='Set2')
    axes[i].set_title(f"[범주형] {col} 상위 10개", fontproperties=font_prop)
    axes[i].tick_params(axis='x', rotation=45)
    axes[i].set_xlabel(col, fontproperties=font_prop)

# 불필요 subplot 제거
for j in range(i+1, len(axes)):
    fig.delaxes(axes[j])

plt.tight_layout()
plt.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### 특정 값(0? 원점)에 비중이 높아서 대칭이 깨진 그래프가많이보인다.
# MAGIC
# MAGIC 해당 지역/시간대에 대해서 히스토그램 상 비율이 일정 이상인 경우 "이상 없음" 모드로 하고, 그게 아닐 경우 알람을 내놓을까? 각 비율이 높은 경우의 비율은 어느정도로 하고 판단 기준은 어떻게 설정하지 ? 

# COMMAND ----------

import pandas as pd
import numpy as np

# 결과 저장용 리스트
hist_summary = []

# 사용할 샘플 데이터프레임
sample_df = df.sample(n=min(10000, len(df)), random_state=42)
numeric_cols = sample_df.select_dtypes(include=np.number).columns.tolist()

# 각 수치형 컬럼에 대해 히스토그램 빈도수 계산
for col in numeric_cols:
    # NaN 제거
    data = sample_df[col].dropna()
    
    # 히스토그램 계산 (30개의 구간으로)
    counts, bin_edges = np.histogram(data, bins=30)

    # 가장 높은 bin의 빈도수와 전체 대비 비율
    max_count = counts.max()
    total_count = counts.sum()
    dominant_ratio = round(max_count / total_count * 100, 2)
    
    # 지배 여부 판단
    is_dominant = "✅ 지배적" if dominant_ratio >= 40 else "❌ 분산됨"

    # 구간 정보 (최빈 구간)
    max_idx = np.argmax(counts)
    bin_range = f"{bin_edges[max_idx]:.2f} ~ {bin_edges[max_idx+1]:.2f}"

    # 결과 추가
    hist_summary.append({
        "컬럼명": col,
        "최빈 구간": bin_range,
        "최빈 구간 빈도수": max_count,
        "전체 샘플 수": total_count,
        "최빈 구간 비율(%)": dominant_ratio,
        "지배적 여부": is_dominant
    })

# 결과를 DataFrame으로 정리
hist_summary_df = pd.DataFrame(hist_summary)
hist_summary_df = hist_summary_df.sort_values(by="최빈 구간 비율(%)", ascending=False)

# 결과 출력
display(hist_summary_df)


# COMMAND ----------

# MAGIC %md
# MAGIC # 상관관계(Correlation) 분석

# COMMAND ----------

# MAGIC %md
# MAGIC ####목적
# MAGIC ####예측 모델링 시 중요한 Feature 추출 가능
# MAGIC
# MAGIC ####다중공선성 유발 변수 사전 탐색

# COMMAND ----------

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# 샘플링 (속도 개선)
sample_df = df.sample(n=min(10000, len(df)), random_state=42)

# 수치형 컬럼만 추출
numeric_df = sample_df.select_dtypes(include=np.number)

# ✅ 1. 상관계수 행렬 계산
corr_matrix = numeric_df.corr()

# ✅ 2. 전체 히트맵 시각화
plt.figure(figsize=(12, 10))
sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap='coolwarm', linewidths=0.5, square=True)
plt.title("수치형 변수 간 상관계수 히트맵")
plt.xticks(rotation=45)
plt.yticks(rotation=0)
plt.tight_layout()
plt.show()

# ✅ 3. 특정 target 변수 기준 상관계수 상위 변수 추출
target = "YOUR_TARGET_COLUMN"  # 🎯 여기에 타겟 변수명 입력
if target in corr_matrix.columns:
    top_corr = corr_matrix[target].drop(labels=[target])  # 자기 자신 제외
    top_corr = top_corr.abs().sort_values(ascending=False)  # 절댓값 기준 정렬

    # 원하는 개수만 추출 (예: 상위 5개)
    top_n = 5
    top_corr_vars = top_corr.head(top_n)
    
    # 출력
    print(f"\n🎯 타겟 변수 '{target}'과의 상관관계 상위 {top_n} 변수:")
    display(top_corr_vars)

    # ✅ 4. 해당 변수들만 heatmap으로 따로 시각화
    selected_cols = [target] + top_corr_vars.index.tolist()
    plt.figure(figsize=(8, 6))
    sns.heatmap(numeric_df[selected_cols].corr(), annot=True, cmap='coolwarm', fmt=".2f", square=True)
    plt.title(f"'{target}' 기준 상관계수 Top {top_n} 변수 히트맵")
    plt.tight_layout()
    plt.show()
else:
    print(f"❌ '{target}'은(는) 수치형 컬럼이 아니거나 존재하지 않습니다.")


# COMMAND ----------

# MAGIC %md
# MAGIC 끔찍한 악마의 테이블이 완성되었다, 우리가 관심 있는 것은 높은 상관관계니까 그것만 처리하자

# COMMAND ----------

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# ✅ 수치형 데이터 선택
numeric_df = df.select_dtypes(include=np.number)

# ✅ 상관계수 계산
corr_matrix = numeric_df.corr()

# ✅ 상삼각 행렬 기준으로 상관계수 0.7 이상 필터링
high_corr_pairs = (
    corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
    .stack()
    .reset_index()
)
high_corr_pairs.columns = ['변수1', '변수2', '상관계수']
high_corr_pairs = high_corr_pairs[high_corr_pairs['상관계수'].abs() >= 0.7]

# ✅ 관련 변수 목록 추출
high_corr_vars = pd.unique(high_corr_pairs[['변수1', '변수2']].values.ravel())

# ✅ 변수명 간소화 (선택사항): 컬럼명이 너무 길 경우 아래 코드 활성화
# short_names = {col: col.split('.')[-1] for col in high_corr_vars}
# corr_subset = numeric_df[high_corr_vars].rename(columns=short_names).corr()
# labels = list(short_names.values())

# ✅ 상관관계 부분 행렬 생성
corr_subset = numeric_df[high_corr_vars].corr()
labels = high_corr_vars

# ✅ 히트맵 시각화
plt.figure(figsize=(1.2 * len(labels), 1.2 * len(labels)))  # 크기 자동 조정
sns.heatmap(
    corr_subset,
    annot=True,
    fmt=".2f",
    cmap='coolwarm',
    square=True,
    linewidths=0.5,
    cbar_kws={'shrink': 0.5}
)

plt.title("상관계수 ≥ 0.7 변수들 간 히트맵", fontsize=16)
plt.xticks(rotation=45, ha='right', fontsize=9)
plt.yticks(rotation=0, fontsize=9)
plt.tight_layout()
plt.show()


# COMMAND ----------

# MAGIC %md
# MAGIC 20개~ 정도 칼럼을 줄일 수 있을 것 같다. 

# COMMAND ----------

import pandas as pd
import numpy as np

# 1. 수치형 데이터만 선택
numeric_df = df.select_dtypes(include=np.number)

# 2. 상관계수 행렬 계산
corr_matrix = numeric_df.corr()

# 3. 상삼각만 추출하여 변수쌍 정리
high_corr_pairs = (
    corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
    .stack()
    .reset_index()
)
high_corr_pairs.columns = ['변수 A', '변수 B', '상관계수']

# 4. 상관계수 ≥ 0.7 필터
high_corr_filtered = high_corr_pairs[high_corr_pairs['상관계수'].abs() >= 0.7].sort_values(by='상관계수', ascending=False)

# 5. 시각적으로 스타일링
styled = high_corr_filtered.style.background_gradient(
    cmap='Reds',
    subset=['상관계수'],
    vmin=0.7,
    vmax=1
).format({'상관계수': '{:.2f}'})

styled


# COMMAND ----------

# MAGIC %md
# MAGIC 상기 칼럼들은 2번쨰열을 삭제함으로써 간소화를 진행하자.

# COMMAND ----------

import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
from collections import defaultdict, Counter

# 1. 수치형 변수만 추출
numeric_df = df.select_dtypes(include=np.number)
corr_matrix = numeric_df.corr().abs()

# 2. 자기 자신 제외하고 상관계수 0.7 이상인 항목만 추출
upper_tri = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
high_corr_pairs = upper_tri.stack()
high_corr_pairs = high_corr_pairs[high_corr_pairs >= 0.7].sort_values(ascending=False)

# 3. 연결 관계 딕셔너리 생성
connections = defaultdict(set)
for var1, var2 in high_corr_pairs.index:
    connections[var1].add(var2)
    connections[var2].add(var1)

# 4. 각 변수별 연결 수 표
connection_counts = {var: len(neighbors) for var, neighbors in connections.items()}
connection_df = pd.DataFrame({
    '변수명': list(connection_counts.keys()),
    '연결된 변수 수': list(connection_counts.values()),
    '연결된 변수들': [list(connections[var]) for var in connection_counts.keys()]
}).sort_values(by='연결된 변수 수', ascending=False)

display(connection_df)

# 5. 개선된 변수명 축약 함수 (앞 글자 삭제 후 뒤쪽 max_len 글자 취함, 중복시 번호 추가)
def shorten_name_uniq(names, max_len=15):
    short_names = []
    counts = Counter()
    for name in names:
        # 변수명이 max_len보다 길면 뒤쪽 끝에서 max_len 글자만큼 자름
        if len(name) > max_len:
            short = name[-max_len:]
        else:
            short = name
        counts[short] += 1
        if counts[short] > 1:
            short += f"_{counts[short]}"
        short_names.append(short)
    return dict(zip(names, short_names))

short_names = shorten_name_uniq(list(connections.keys()), max_len=15)

# 6. 그래프 그리기
G = nx.Graph()

for var in connections:
    G.add_node(var)
for (var1, var2), corr_val in high_corr_pairs.items():
    G.add_edge(var1, var2, weight=corr_val)

plt.figure(figsize=(16, 12))

# 노드 크기 축소: 최소 50, 최대 200
min_size = 50
max_size = 200
counts = np.array([connection_counts.get(node, 0) for node in G.nodes()])
if len(counts) > 0:
    norm_counts = (counts - counts.min()) / (counts.max() - counts.min() + 1e-6)
    node_sizes = min_size + norm_counts * (max_size - min_size)
else:
    node_sizes = [min_size for _ in G.nodes()]

# 엣지 두께: 0.5 ~ 2
edges = G.edges(data=True)
weights = np.array([d['weight'] for (u,v,d) in edges])
if len(weights) > 0:
    norm_weights = (weights - weights.min()) / (weights.max() - weights.min() + 1e-6)
    edge_widths = 0.5 + norm_weights * 1.5
else:
    edge_widths = [1 for _ in edges]

# 레이아웃 변경: kamada_kawai_layout (노드 간격 넓음)
pos = nx.kamada_kawai_layout(G)

# 노드 그리기
nx.draw_networkx_nodes(G, pos, node_size=node_sizes, node_color='skyblue', alpha=0.8)

# 엣지 그리기
nx.draw_networkx_edges(G, pos, width=edge_widths, alpha=0.6, edge_color='gray')

# 라벨 폰트 크기 줄이고 배경 박스 추가
nx.draw_networkx_labels(G, pos, labels=short_names, font_size=8,
                        bbox=dict(facecolor='white', edgecolor='none', alpha=0.7, pad=1))

plt.title("상관계수 0.7 이상 변수 간 연결 그래프 (개선된 변수명 및 레이아웃)", fontsize=16)
plt.axis('off')
plt.show()


# COMMAND ----------

# MAGIC %md
# MAGIC # 6. 다중공선성(Multicollinearity) 확인

# COMMAND ----------

# MAGIC %md
# MAGIC #### 목적
# MAGIC #### 독립변수 간 중복 정보 제거 → 과적합 방지, 모델 안정성 향상

# COMMAND ----------

import pandas as pd
import numpy as np
from collections import defaultdict, Counter
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor

# 1. 수치형 변수만 추출
numeric_df = df.select_dtypes(include=np.number)

# 2. 상관관계 행렬 절댓값 계산
corr_matrix = numeric_df.corr().abs()

# 3. 자기 자신 제외, 상관계수 0.7 이상인 변수쌍 추출
upper_tri = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
high_corr_pairs = upper_tri.stack()
high_corr_pairs = high_corr_pairs[high_corr_pairs >= 0.7].sort_values(ascending=False)

# 4. 연결 관계 딕셔너리 생성
connections = defaultdict(set)
for var1, var2 in high_corr_pairs.index:
    connections[var1].add(var2)
    connections[var2].add(var1)

# 5. 연결 수 계산 (0.7 이상 상관 변수 개수)
connection_counts = {var: len(neighbors) for var, neighbors in connections.items()}

# 6. 다중공선성 의심 변수 목록 (상관관계 기준)
multicol_vars = list(connection_counts.keys())

# 7. VIF 계산 함수 정의 (NaN, inf 제거 포함)
def calculate_vif(df_input):
    # inf 값을 NaN으로 대체
    df_clean = df_input.replace([np.inf, -np.inf], np.nan)
    # NaN 포함 행 제거
    df_clean = df_clean.dropna(axis=0)
    
    vif_data = pd.DataFrame()
    vif_data["feature"] = df_clean.columns
    vif_data["VIF"] = [variance_inflation_factor(df_clean.values, i) for i in range(df_clean.shape[1])]
    return vif_data

# 8. VIF 계산 (다중공선성 의심 변수만 대상으로 수행)
vif_df = calculate_vif(numeric_df[multicol_vars])

# 9. 연결 수 데이터프레임 생성
connection_df = pd.DataFrame({
    '변수명': list(connection_counts.keys()),
    '연결된 변수 수': list(connection_counts.values())
})

# 10. 연결 수와 VIF 데이터 병합
result_df = pd.merge(connection_df, vif_df, left_on='변수명', right_on='feature', how='left').drop(columns=['feature'])

# 11. VIF 임계값 초과 여부 컬럼 추가 (예: 5)
vif_threshold = 5
result_df['VIF 초과 여부'] = result_df['VIF'] > vif_threshold

# 12. 변수명 기준 정렬 (연결 수 내림차순)
result_df = result_df.sort_values(by='연결된 변수 수', ascending=False).reset_index(drop=True)

# 13. 결과 출력
print("다중공선성 관련 변수 정보:")
display(result_df)

# 추가적으로 변수 제거 권고 등 로직 구현 가능


# COMMAND ----------

# MAGIC %md
# MAGIC ## 다중공선성(Multicollinearity)이란?
# MAGIC 다중공선성은 여러 독립변수(또는 설명변수) 간에 높은 상관관계가 존재하는 상태를 의미합니다. 즉, 하나 이상의 변수가 다른 변수들과 매우 비슷한 정보를 가지고 있을 때 발생합니다.
# MAGIC
# MAGIC ### 왜 중요한가?
# MAGIC 1. 정보 중복: 변수들이 중복된 정보를 포함해 모델의 입력 데이터가 불필요하게 복잡해짐
# MAGIC
# MAGIC 2. 분석 신뢰도 저하: 변수 간 중복 때문에 특정 변수의 영향력을 정확히 파악하기 어려워짐
# MAGIC
# MAGIC 3. 모델 불안정성: 회귀계수 추정값이 불안정해지고, 작은 데이터 변화에도 크게 변할 수 있음
# MAGIC
# MAGIC 4. 과적합 위험 증가: 불필요한 변수들이 모델에 포함되면서 과적합 가능성이 커짐
# MAGIC
# MAGIC ### VIF(분산팽창계수)란?
# MAGIC VIF는 다중공선성 정도를 수치로 나타내는 지표입니다.
# MAGIC
# MAGIC VIF 값이 높을수록 해당 변수가 다른 변수들과 높은 상관성을 가짐을 의미
# MAGIC
# MAGIC 일반적으로 VIF 값이 5 또는 10을 초과하면 심각한 다중공선성으로 판단합니다.
# MAGIC
# MAGIC ### VIF 초과 여부가 미치는 영향과 대처 방법
# MAGIC 1. 분석 정확성 저하: VIF가 높은 변수는 다른 변수들과 중복된 정보를 가지므로, 이 변수를 포함하면 해석과 분석의 정확성이 떨어질 수 있습니다.
# MAGIC
# MAGIC ### 대처 방법
# MAGIC
# MAGIC 높은 VIF 값을 가진 변수 중 하나를 제거하거나,
# MAGIC
# MAGIC 변수를 합치거나 차원 축소 기법을 활용해 중복된 정보를 줄이는 방법이 있습니다.
# MAGIC
# MAGIC ### Power BI 기반 대시보드 작성 시 발생할 수 있는 문제
# MAGIC 1. 시각화 왜곡
# MAGIC 다중공선성 변수들이 중복된 정보를 표시할 경우, 대시보드 사용자에게 혼란을 줄 수 있으며 데이터 인사이트가 모호해질 수 있습니다.
# MAGIC
# MAGIC 2. 성능 저하
# MAGIC 불필요하게 많은 변수로 대시보드를 구성하면 데이터 처리 속도가 느려지고, 리포트 반응성이 떨어질 수 있습니다.
# MAGIC
# MAGIC 3. 해석 어려움
# MAGIC 변수들 간의 중복 정보로 인해 주요 지표의 변동 원인을 명확히 파악하기 어려워집니다.
# MAGIC
# MAGIC ### 대시보드 작성 시 권장 사항
# MAGIC 1. 다중공선성이 높은 변수 중 대표 변수를 선별해 활용합니다.
# MAGIC
# MAGIC 2. 변수 간 중복성을 줄이기 위해 사전에 다중공선성 분석 및 변수 정제를 수행합니다.
# MAGIC
# MAGIC 3. 필요하다면 변수 통합, 요인 분석 등 차원 축소 기법을 활용해 정보의 중복을 최소화합니다.
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # ☆ 상관계수 & 다중공선성을 참고로한 변수 처리 방향성

# COMMAND ----------

# MAGIC %md
# MAGIC ####✅ Step 1. 다중공선성 기준 삭제 대상 필터링
# MAGIC 일반적으로 VIF 값이 10 이상이면 다중공선성 문제가 있다고 판단하고, 100 이상이면 심각한 수준입니다.
# MAGIC
# MAGIC 아래는 VIF 기준으로 심각한 변수 Top 10입니다:
# MAGIC
# MAGIC 변수명	VIF	연결된 변수 수
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_CORPORATION_RATE	1.2e+14	1
# MAGIC CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTOFF_PPLTN_MAX	1.7e+7	7
# MAGIC CITYDATA.LIVE_CMRCL_STTS.CMRCL_FEMALE_RATE	1.2e+7	1
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTOFF_PPLTN_MAX	1.5e+6	9
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTOFF_PPLTN_MIN	1.4e+6	9
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTON_PPLTN_MAX	1723.6	12
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTON_PPLTN_MIN	1675.7	12
# MAGIC CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MIN	1108.4	2
# MAGIC CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MAX	1092.7	2
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTOFF_PPLTN_MAX	1177.3	11
# MAGIC
# MAGIC ####✅ Step 2. 상관계수 기반 연결 수가 많은 변수 파악
# MAGIC 상관계수 0.7 이상으로 연결된 변수 수가 많은 것부터 우선 고려합니다.
# MAGIC
# MAGIC 연결 수가 많은 변수는 보통 대표적인 중복 정보 보유자입니다.
# MAGIC
# MAGIC 아래는 상위 변수들:
# MAGIC
# MAGIC 변수명	연결된 변수 수	VIF
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTON_PPLTN_MIN	12	1675.8
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTON_PPLTN_MAX	12	1723.7
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTOFF_PPLTN_MAX	11	100.9
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTOFF_PPLTN_MAX	11	177.8
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTON_PPLTN_MAX	11	215.3
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTON_PPLTN_MIN	11	200.9
# MAGIC CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTON_PPLTN_MAX	11	91.7
# MAGIC
# MAGIC #### ✅ Step 3. 대표성을 기준으로 삭제 변수 선정
# MAGIC 비슷한 지표 중 하나만 남기고 나머지 제거하는 방식.
# MAGIC
# MAGIC 예: "버스 승차인구 5분/10분/30분 거리" → 30분 하나만 남기고 나머지 제거 가능.
# MAGIC
# MAGIC #### ✅ Step 4. 최종 삭제 추천 리스트
# MAGIC 다음 기준으로 선택:
# MAGIC
# MAGIC 상관관계 연결 수가 많고,
# MAGIC
# MAGIC VIF가 높으며,
# MAGIC
# MAGIC 다른 변수로 설명 가능한 경우
# MAGIC
# MAGIC plaintext
# MAGIC 복사
# MAGIC 편집
# MAGIC (★ 매우 강력 추천 / ○ 보통 추천)
# MAGIC
# MAGIC ★ CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTON_PPLTN_MAX
# MAGIC ★ CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTON_PPLTN_MIN
# MAGIC ★ CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTOFF_PPLTN_MAX
# MAGIC ★ CITYDATA.LIVE_BUS_PPLTN.BUS_30WTHN_GTOFF_PPLTN_MIN
# MAGIC ○ CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTON_PPLTN_MAX
# MAGIC ○ CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTOFF_PPLTN_MAX
# MAGIC ○ CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTON_PPLTN_MAX
# MAGIC ○ CITYDATA.LIVE_BUS_PPLTN.BUS_5WTHN_GTOFF_PPLTN_MAX
# MAGIC ★ CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTOFF_PPLTN_MAX
# MAGIC ★ CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTOFF_PPLTN_MIN
# MAGIC ○ CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTON_PPLTN_MIN
# MAGIC ★ CITYDATA.LIVE_CMRCL_STTS.CMRCL_CORPORATION_RATE
# MAGIC ★ CITYDATA.LIVE_CMRCL_STTS.CMRCL_FEMALE_RATE
# MAGIC ○ CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MAX
# MAGIC ○ CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MIN
# MAGIC #### ✅ Step 5. 대체 가능한 대표 변수 예시
# MAGIC 제거 대상	대체 가능 변수
# MAGIC BUS_10WTHN_GTON_PPLTN_MAX	BUS_30WTHN_GTON_PPLTN_MAX
# MAGIC BUS_5WTHN_GTOFF_PPLTN_MIN	BUS_30WTHN_GTOFF_PPLTN_MIN
# MAGIC SUB_10WTHN_GTON_PPLTN_MIN	SUB_30WTHN_GTON_PPLTN_MIN
# MAGIC CMRCL_CORPORATION_RATE	CMRCL_PERSONAL_RATE
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # 8. 변수 간 관계 시각화 (Feature Interaction)

# COMMAND ----------

# MAGIC %md
# MAGIC #### ✅ 수행할 작업
# MAGIC #### pairplot, scatterplot, groupby().mean()
# MAGIC
# MAGIC #### 범주형 × 수치형, 수치형 × 수치형 간 상호작용 시각화
# MAGIC
# MAGIC #### 🔧 목적
# MAGIC #### 상호작용 Feature를 생성할 힌트 제공

# COMMAND ----------

# MAGIC %md
# MAGIC ### 전제 정의 (자동 분리)

# COMMAND ----------

import pandas as pd

# 수치형 / 범주형 변수 분리
numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
categorical_cols = df.select_dtypes(exclude=['number']).columns.tolist()

print(f"🔍 수치형 변수 ({len(numeric_cols)}개): {numeric_cols}")
print(f"🔍 범주형 변수 ({len(categorical_cols)}개): {categorical_cols}")


# COMMAND ----------

# MAGIC %md
# MAGIC ### 1. 수치형 × 수치형: pairplot & scatterplot

# COMMAND ----------

import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

# 변수명을 간단히 보여주기 위한 함수
def shorten(name, maxlen=30):
    return name if len(name) <= maxlen else name.split('.')[-1]

# -----------------------------
# 1. pairplot (변수 & 행 샘플링)
# -----------------------------
sampled_numeric = numeric_cols[:15]  # 변수 5개 선택
df_sampled = df[sampled_numeric].sample(n=800, random_state=42)  # 800행 샘플링

# 컬럼명 축약
df_sampled.columns = [shorten(col) for col in df_sampled.columns]

sns.pairplot(df_sampled)
plt.suptitle("📌 수치형 변수 간 pairplot (샘플 800행)", y=1.02, fontsize=13)
plt.tight_layout()
plt.show()

# ------------------------------------------
# 2. scatterplot (상관계수 높은 변수 조합만)
# ------------------------------------------
corr_matrix = df[numeric_cols].corr().abs()
upper_triangle = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))

# 상관계수 0.6 이상인 변수쌍
high_corr_pairs = [
    (col, row) for col in upper_triangle.columns
    for row in upper_triangle.index
    if upper_triangle.loc[row, col] > 0.6
]

# 최대 6쌍만 시각화
for (x, y) in high_corr_pairs[:15]:
    corr_value = corr_matrix.loc[x, y]
    plt.figure(figsize=(6, 4))
    sns.scatterplot(data=df, x=x, y=y, alpha=0.4)
    plt.xlabel(shorten(x), fontsize=11)
    plt.ylabel(shorten(y), fontsize=11)
    plt.title(f"{shorten(x)} vs {shorten(y)}\n상관계수: {corr_value:.2f}", fontsize=12)
    plt.tight_layout()
    plt.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ### 2. 범주형 × 수치형: 평균 차이 시각화

# COMMAND ----------

import seaborn as sns
import matplotlib.pyplot as plt

# 긴 변수명 축약 함수
def shorten(name, maxlen=30):
    return name if len(name) <= maxlen else name.split('.')[-1]

# 고유값이 10개 이하인 범주형 변수만 선택
filtered_cats = [col for col in categorical_cols if df[col].nunique() <= 10]

# 최대 20쌍만 시각화
pair_count = 0
max_pairs = 20

for cat in filtered_cats:
    for num in numeric_cols:
        plt.figure(figsize=(6, 4))
        sns.boxplot(data=df, x=cat, y=num)

        # 제목 간결하게
        short_cat = shorten(cat)
        short_num = shorten(num)
        plt.title(f"{short_num} by {short_cat}", fontsize=12)
        plt.xlabel(short_cat, fontsize=10)
        plt.ylabel(short_num, fontsize=10)
        plt.xticks(rotation=15)
        plt.tight_layout()
        plt.show()

        pair_count += 1
        if pair_count >= max_pairs:
            break
    if pair_count >= max_pairs:
        break
