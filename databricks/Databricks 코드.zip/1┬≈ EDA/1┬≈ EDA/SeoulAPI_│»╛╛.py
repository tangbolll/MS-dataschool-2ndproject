# Databricks notebook source
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import seaborn as sns

# 1. 폰트 경로 지정
font_path = "/usr/share/fonts/truetype/nanum/NanumGothic.ttf"
font_prop = fm.FontProperties(fname=font_path)
font_name = font_prop.get_name()

# 2. 전체 전역 설정
plt.rcParams['font.family'] = font_name
plt.rcParams['axes.unicode_minus'] = False
sns.set(font=font_name)  # 중요!! seaborn에도 설정해줘야 함


# COMMAND ----------

from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

# 각 테이블을 Delta 형식으로 읽기
df1 = spark.read.format("delta").load("dbfs:/user/hive/warehouse/seoul_city_data_full_20250707_175748")
df2 = spark.read.format("delta").load("dbfs:/user/hive/warehouse/seoul_city_data_full_20250708_040103")

# 두 데이터프레임을 병합 (스키마가 같다는 전제)
df = df1.unionByName(df2)

# 확인
df.printSchema()
df.limit(20).show()  # 상위 20개 행을 출력

# COMMAND ----------

df.head(1)

# COMMAND ----------

df.columns

# COMMAND ----------

weather_cols = [col for col in df.columns if 'WEATHER' in col]
print(weather_cols)

# COMMAND ----------

df.select("`CITYDATA.WEATHER_STTS`").head(5)

# COMMAND ----------

from pyspark.sql.functions import col, from_json
from pyspark.sql.types import *

# 날씨 스키마 정의 (간단화 버전)
weather_schema = ArrayType(StructType([
    StructField("WEATHER_TIME", StringType()),
    StructField("TEMP", StringType()),
    StructField("HUMIDITY", StringType()),
    StructField("WIND_SPD", StringType()),
    # 필요한 컬럼만 추가
]))

# JSON 파싱
df_parsed = df.withColumn("weather_array", from_json(col("`CITYDATA.WEATHER_STTS`"), weather_schema))

# 첫 번째 날씨 정보만 추출
df_flat = df_parsed.withColumn("weather", col("weather_array")[0]) \
    .select(
        col("weather.WEATHER_TIME").alias("weather_time"),
        col("weather.TEMP").cast("float"),
        col("weather.HUMIDITY").cast("float"),
        col("weather.WIND_SPD").cast("float"),
        col("`CITYDATA.LIVE_CMRCL_STTS.AREA_CMRCL_LVL`").alias("cmrcl_lvl"),
        col("`CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_CNT`").cast("int").alias("pay_cnt"),
        col("`CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MIN`").cast("float").alias("pay_min"),
        col("`CITYDATA.LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MAX`").cast("float").alias("pay_max")
    )


# COMMAND ----------

pdf = df_flat.toPandas()

# COMMAND ----------

pdf

# COMMAND ----------

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# 기온을 5도 단위로 그룹핑
pdf['temp_group'] = (pdf["CAST(weather.TEMP AS FLOAT)"] // 2) *2

# 바플롯 생성
sns.barplot(data=pdf, x="temp_group", y="pay_cnt")
plt.title("Temperature Group (2°C intervals) vs Payment Count")
plt.xlabel("Temperature Group (°C)")
plt.ylabel("Payment Count")
plt.show()

# COMMAND ----------

!apt-get update -qq
!apt-get install -y fonts-nanum

# COMMAND ----------

import matplotlib.pyplot as plt
import seaborn as sns

# 한글 폰트 설정 (예시)
plt.rcParams['font.family'] = 'NanumGothic'  # 또는 다른 한글 폰트

# 플롯 생성
ax = sns.countplot(data=pdf, x="temp_bin", hue="cmrcl_lvl")

# 범례 폰트 설정
legend = ax.legend()
for text in legend.get_texts():
    text.set_fontfamily('NanumGothic')  # 또는 원하는 폰트
    text.set_fontsize(12)  # 폰트 크기도 설정 가능

plt.show()

# COMMAND ----------

ax = sns.countplot(data=pdf, x="temp_bin", hue="cmrcl_lvl")

plt.title("기온 vs 상권 분류", fontproperties=font_prop)
plt.xlabel("기온 구간", fontproperties=font_prop)
plt.ylabel("등장 수", fontproperties=font_prop)
plt.xticks(rotation=45)

# 범례에 한글 폰트 적용
for text in ax.legend().get_texts():
    text.set_fontproperties(font_prop)

plt.show()