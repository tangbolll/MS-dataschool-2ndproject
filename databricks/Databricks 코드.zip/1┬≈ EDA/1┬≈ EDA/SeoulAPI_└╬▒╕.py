# Databricks notebook source
df1 = spark.table("default.seoul_city_data_full_20250707_175748")
df2 = spark.table("default.seoul_city_data_full_20250708_040103")

df1.printSchema()
df2.printSchema()


# COMMAND ----------

for col_name in df1.columns:
    print(col_name)


# COMMAND ----------

[col for col in df1.columns if "PPLTN" in col]


# COMMAND ----------

for col_name in df2.columns:
    print(col_name)

# COMMAND ----------

#데이터 수 / 샘플 확인
print("▶ df1 row 수:", df1.count())
print("▶ df2 row 수:", df2.count())

df1.limit(5).display()
df2.limit(5).display()


# COMMAND ----------

#인구 주요 컬럼 확인
df1.select(
    "`CITYDATA.AREA_NM`",
    "`CITYDATA.AREA_CD`",
    "`CITYDATA.LIVE_PPLTN_STTS`",
    "`CITYDATA.LIVE_CMRCL_STTS.CMRCL_20_RATE`",
    "`CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTON_PPLTN_MAX`"
).display()



# COMMAND ----------

from pyspark.sql.functions import col, when, count

def check_missing(df, df_name):
    print(f"▶ {df_name} 결측치 수:")
    df.select([
        count(when(col(f"`{c}`").isNull(), c)).alias(c)
        for c in df.columns
    ]).display()


# df1에 적용
check_missing(df1, "df1")

# df2도 동일하게
check_missing(df2, "df2")


# COMMAND ----------

from pyspark.sql.functions import col

df1_alias = df1.select(
    col("`CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTON_PPLTN_MAX`").alias("subway_ppltn"),
    col("`CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTON_PPLTN_MAX`").alias("bus_ppltn"),
    col("`CITYDATA.LIVE_CMRCL_STTS.CMRCL_20_RATE`").alias("rate_20s"),
    col("`CITYDATA.LIVE_CMRCL_STTS.CMRCL_MALE_RATE`").alias("male_rate"),
    col("`CITYDATA.LIVE_CMRCL_STTS.CMRCL_FEMALE_RATE`").alias("female_rate")
)


# COMMAND ----------

df1_alias.describe("subway_ppltn", "bus_ppltn", "rate_20s", "male_rate", "female_rate").display()


# COMMAND ----------

from pyspark.sql.functions import col

df_dist = df1.select(
    col("`CITYDATA.LIVE_CMRCL_STTS.CMRCL_20_RATE`").alias("rate_20s"),
    col("`CITYDATA.LIVE_CMRCL_STTS.CMRCL_MALE_RATE`").alias("male_rate"),
    col("`CITYDATA.LIVE_CMRCL_STTS.CMRCL_FEMALE_RATE`").alias("female_rate"),
    col("`CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTON_PPLTN_MAX`").alias("subway_ppltn")
)
# 예: 20대 비율 분포
df_dist.select("rate_20s").display()

# 예: 지하철 유동인구 분포
df_dist.select("subway_ppltn").display()


# COMMAND ----------

from pyspark.ml.feature import VectorAssembler
from pyspark.ml.stat import Correlation

cols = ["rate_20s", "male_rate", "female_rate", "subway_ppltn"]

assembler = VectorAssembler(inputCols=cols, outputCol="features")
df_vec = assembler.transform(df_dist).select("features")


# COMMAND ----------

df_clean = df_dist.dropna()  # 모든 컬럼에서 null이 있는 행 제거

from pyspark.ml.feature import VectorAssembler
from pyspark.ml.stat import Correlation

cols = ["rate_20s", "male_rate", "female_rate", "subway_ppltn"]

assembler = VectorAssembler(inputCols=cols, outputCol="features")
df_vec = assembler.transform(df_clean).select("features")

correlation_matrix = Correlation.corr(df_vec, "features").head()[0].toArray()

# 시각화
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

corr_df = pd.DataFrame(correlation_matrix, columns=cols, index=cols)
sns.heatmap(corr_df, annot=True, cmap="coolwarm")
plt.title("상관관계 히트맵")
plt.show()


# COMMAND ----------

pdf = df_dist.dropna().toPandas()

import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor

X = sm.add_constant(pdf)  # 상수항 추가
vif = pd.DataFrame()
vif["feature"] = X.columns
vif["VIF"] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]

vif


# COMMAND ----------

from pyspark.sql.functions import col

cols = [
    "CITYDATA.AREA_NM",
    "CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_IDX",
    "CITYDATA.LIVE_SUB_PPLTN.SUB_10WTHN_GTON_PPLTN_MAX",
    "CITYDATA.LIVE_BUS_PPLTN.BUS_10WTHN_GTON_PPLTN_MAX"
]

df_comp = df1.select([col(f"`{c}`").alias(c.split(".")[-1]) for c in cols])
df_comp.display()


# COMMAND ----------

from pyspark.sql.functions import col

# 숫자형으로 캐스팅
df_cast = df_clean.select(
    col("ROAD_TRAFFIC_IDX").cast("double"),
    col("SUB_10WTHN_GTON_PPLTN_MAX").cast("double"),
    col("BUS_10WTHN_GTON_PPLTN_MAX").cast("double")
)

from pyspark.ml.feature import VectorAssembler
from pyspark.ml.stat import Correlation

assembler = VectorAssembler(
    inputCols=["ROAD_TRAFFIC_IDX", "SUB_10WTHN_GTON_PPLTN_MAX", "BUS_10WTHN_GTON_PPLTN_MAX"],
    outputCol="features",
    handleInvalid="skip"
)

df_vector = assembler.transform(df_cast)

# 상관계수 계산
correlation_matrix = Correlation.corr(df_vector, "features").head()[0].toArray()

import pandas as pd
cols = ["도로혼잡도", "지하철유입", "버스유입"]
corr_df = pd.DataFrame(correlation_matrix, columns=cols, index=cols)
corr_df



# COMMAND ----------

# MAGIC %md
# MAGIC **-----------------------------------------**

# COMMAND ----------

from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

df1 = spark.read.format("delta").load("dbfs:/user/hive/warehouse/seoul_city_data_full_20250707_175748")
df2 = spark.read.format("delta").load("dbfs:/user/hive/warehouse/seoul_city_data_full_20250708_040103")

df = df1.unionByName(df2)

df.printSchema()
df.limit(20).show()  

# COMMAND ----------

from pyspark.sql.functions import col

df.select(col("`CITYDATA.LIVE_PPLTN_STTS`")).show(truncate=False)


# COMMAND ----------

df.selectExpr("`CITYDATA.LIVE_PPLTN_STTS`").show(truncate=False)


# COMMAND ----------

from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, ArrayType

# 예측 인구 스키마 정의
fcst_schema = ArrayType(
    StructType([
        StructField("FCST_TIME", StringType()),
        StructField("FCST_CONGEST_LVL", StringType()),
        StructField("FCST_PPLTN_MIN", IntegerType()),
        StructField("FCST_PPLTN_MAX", IntegerType()),
    ])
)

# 전체 인구 데이터 스키마
ppltn_schema = StructType([
    StructField("AREA_NM", StringType()),
    StructField("AREA_CD", StringType()),
    StructField("AREA_CONGEST_LVL", StringType()),
    StructField("AREA_CONGEST_MSG", StringType()),
    StructField("AREA_PPLTN_MIN", IntegerType()),
    StructField("AREA_PPLTN_MAX", IntegerType()),
    StructField("MALE_PPLTN_RATE", DoubleType()),
    StructField("FEMALE_PPLTN_RATE", DoubleType()),
    StructField("PPLTN_RATE_20", DoubleType()),
    StructField("PPLTN_RATE_30", DoubleType()),
    StructField("RESNT_PPLTN_RATE", DoubleType()),
    StructField("NON_RESNT_PPLTN_RATE", DoubleType()),
    StructField("PPLTN_TIME", StringType()),
    StructField("REPLACE_YN", StringType()),
    StructField("FCST_YN", StringType()),
    StructField("FCST_PPLTN", fcst_schema)
])

# 파싱
df_parsed = df.withColumn(
    "LIVE_PPLTN_PARSED",
    from_json(col("`CITYDATA.LIVE_PPLTN_STTS`"), ArrayType(ppltn_schema))
)
df_parsed.select("LIVE_PPLTN_PARSED").show(truncate=False)


# COMMAND ----------

from pyspark.sql.functions import from_json, col, explode
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, ArrayType

# 예측 인구 스키마 정의
fcst_schema = ArrayType(
    StructType([
        StructField("FCST_TIME", StringType()),
        StructField("FCST_CONGEST_LVL", StringType()),
        StructField("FCST_PPLTN_MIN", IntegerType()),
        StructField("FCST_PPLTN_MAX", IntegerType()),
    ])
)

# 전체 인구 데이터 스키마
ppltn_schema = StructType([
    StructField("AREA_NM", StringType()),
    StructField("AREA_CD", StringType()),
    StructField("AREA_CONGEST_LVL", StringType()),
    StructField("AREA_CONGEST_MSG", StringType()),
    StructField("AREA_PPLTN_MIN", IntegerType()),
    StructField("AREA_PPLTN_MAX", IntegerType()),
    StructField("MALE_PPLTN_RATE", DoubleType()),
    StructField("FEMALE_PPLTN_RATE", DoubleType()),
    StructField("PPLTN_RATE_20", DoubleType()),
    StructField("PPLTN_RATE_30", DoubleType()),
    StructField("RESNT_PPLTN_RATE", DoubleType()),
    StructField("NON_RESNT_PPLTN_RATE", DoubleType()),
    StructField("PPLTN_TIME", StringType()),
    StructField("REPLACE_YN", StringType()),
    StructField("FCST_YN", StringType()),
    StructField("FCST_PPLTN", fcst_schema)
])

# JSON 파싱
df_parsed = df.withColumn(
    "LIVE_PPLTN_PARSED",
    from_json(col("`CITYDATA.LIVE_PPLTN_STTS`"), ArrayType(ppltn_schema))
)

# 장소별로 행 분해
df_exploded = df_parsed.selectExpr("base_dt", "base_tm", "explode(LIVE_PPLTN_PARSED) as ppltn")

# 필요한 필드 추출
df_flat = df_exploded.select(
    col("base_dt"),
    col("base_tm"),
    col("ppltn.AREA_NM").alias("장소명"),
    col("ppltn.AREA_CD").alias("장소코드"),
    col("ppltn.AREA_CONGEST_LVL").alias("현재혼잡도"),
    col("ppltn.AREA_CONGEST_MSG").alias("혼잡도메시지"),
    col("ppltn.PPLTN_TIME").alias("기준시각"),
    col("ppltn.FCST_YN").alias("예측여부"),
    col("ppltn.FCST_PPLTN").alias("예측정보")
)

df_flat.show(truncate=False)
