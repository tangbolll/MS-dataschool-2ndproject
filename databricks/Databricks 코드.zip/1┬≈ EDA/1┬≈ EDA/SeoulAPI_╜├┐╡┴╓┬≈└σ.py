# Databricks notebook source
import pandas as pd
import os

# 1. DBFS에 있는 파일을 클러스터의 로컬 임시 디렉토리로 복사
# 이전에 파일을 저장한 새롭고 깨끗한 경로를 사용합니다.
source_dbfs_path = "dbfs:/FileStore/seoul_data/seoul_parking_info.csv"
local_tmp_path = "file:/tmp/seoul_parking_info.csv"

try:
    # dbutils.fs.rm(local_tmp_path) # 만약 파일이 이미 존재한다는 에러가 나면 이 줄의 주석을 푸세요.
    dbutils.fs.cp(source_dbfs_path, local_tmp_path)
    print(f"Successfully copied '{source_dbfs_path}' to '{local_tmp_path}'")
except Exception as e:
    print(f"File copy might have failed, but proceeding anyway. Error: {e}")

# 2. Pandas가 인식할 수 있는 로컬 파일 경로로 지정
# (dbutils의 'file:' 접두사를 제거한 경로)
pandas_local_path = "/tmp/seoul_parking_info.csv"

# 3. Pandas로 로컬 CSV 파일 읽기
if os.path.exists(pandas_local_path):
    try:
        df = pd.read_csv(pandas_local_path)
        
        # 4. 결과 확인
        print("\nSuccessfully loaded the file into a Pandas DataFrame.")
        print("DataFrame Shape:", df.shape)
        
        # Databricks에서는 display() 함수를 Pandas DataFrame에도 사용할 수 있습니다.
        display(df.head())

    except Exception as e:
        print(f"An error occurred while reading the CSV with Pandas: {e}")
else:
    print(f"Error: The file was not found at the local path '{pandas_local_path}'. The copy from DBFS may have failed.")



# COMMAND ----------

# MAGIC %pip install koreanize-matplotlib
# MAGIC
# MAGIC import matplotlib.pyplot as plt
# MAGIC import koreanize_matplotlib # 이 줄만 추가하면 됩니다.
# MAGIC
# MAGIC # 시각화 테스트
# MAGIC plt.figure(figsize=(8, 6))
# MAGIC plt.title('한글 테스트 제목')
# MAGIC plt.xlabel('한글 X축')
# MAGIC plt.ylabel('한글 Y축')
# MAGIC plt.plot([1, 2, 3], [10, 20, 15])
# MAGIC plt.text(1.5, 17, '한글 텍스트', fontsize=14, color='red')
# MAGIC plt.show()

# COMMAND ----------

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import folium

# 이 코드는 이전 셀에서 'df'라는 Pandas DataFrame이 성공적으로 로드되었다고 가정합니다.

# --- 데이터 정제 (EDA 전 확인) ---
# 이전에 PySpark에서 하려던 작업을 Pandas로 수행합니다.
# 숫자형으로 변환, errors='coerce'는 변환 실패 시 NaN으로 만듭니다.
df['총주차면수'] = pd.to_numeric(df['총주차면수'], errors='coerce')
df['일일최대요금'] = pd.to_numeric(df['일일최대요금'], errors='coerce')
df['위도'] = pd.to_numeric(df['위도'], errors='coerce')
df['경도'] = pd.to_numeric(df['경도'], errors='coerce')

# 주소에서 '구' 정보 추출
df['구'] = df['주소'].str.split().str[0]
print("데이터 정제 및 '구' 컬럼 생성 완료.")


# --- 1. 요금과 주차면수의 관계 분석 ---
print("\n--- 요금과 주차면수 관계 분석 ---")

# 유료 주차장 데이터만 필터링 (일일최대요금이 0보다 큰 경우)
paid_parking_df = df[df['일일최대요금'] > 0].copy()

# 이상치 때문에 그래프가 제대로 보이지 않을 수 있으므로, 상위 1% 데이터는 제외하고 시각화
quantile_99_spaces = paid_parking_df['총주차면수'].quantile(0.99)
quantile_99_fee = paid_parking_df['일일최대요금'].quantile(0.99)

filtered_paid_df = paid_parking_df[
    (paid_parking_df['총주차면수'] <= quantile_99_spaces) &
    (paid_parking_df['일일최대요금'] <= quantile_99_fee)
]

print(f"유료 주차장 {len(paid_parking_df):,}개 중, 상위 1% 이상치를 제외한 {len(filtered_paid_df):,}개 데이터로 관계 분석")

plt.figure(figsize=(12, 8))
sns.scatterplot(data=filtered_paid_df, x='총주차면수', y='일일최대요금', alpha=0.5)
plt.title('주차면수와 일일 최대요금의 관계 (유료 주차장)')
plt.xlabel('총주차면수')
plt.ylabel('일일 최대요금 (원)')
plt.grid(True)
# display(plt.show()) # Databricks에서 plot을 명시적으로 보여주려면 display()로 감쌀 수 있습니다.
plt.show()


# --- 2. 특정 구(Gu)의 주차장 상세 분석 ---
print("\n--- 특정 구(Gu) 주차장 상세 분석 ---")

# 분석하고 싶은 '구'를 설정하세요.
target_gu = '강남구'

gu_df = df[df['구'] == target_gu].copy()

if gu_df.empty:
    print(f"'{target_gu}'에 대한 데이터가 없습니다. 다른 구를 선택해주세요.")
else:
    print(f"{target_gu}에는 총 {len(gu_df)}개의 주차장 정보가 있습니다.")

    # 2-1. 해당 구의 주차장 종류 분석
    plt.figure(figsize=(10, 6))
    sns.countplot(data=gu_df, x='주차장종류', order=gu_df['주차장종류'].value_counts().index)
    plt.title(f'{target_gu} 주차장 종류별 개수')
    plt.xlabel('주차장 종류')
    plt.ylabel('개수')
    plt.show()

    # 2-2. 해당 구의 지도 시각화
    gu_map_df = gu_df.dropna(subset=['위도', '경도'])

    if gu_map_df.empty:
        print(f"'{target_gu}'에는 위치 정보가 있는 주차장이 없습니다.")
    else:
        gu_center_lat = gu_map_df['위도'].mean()
        gu_center_lon = gu_map_df['경도'].mean()

        gu_map = folium.Map(location=[gu_center_lat, gu_center_lon], zoom_start=13)

        for idx, row in gu_map_df.iterrows():
            popup_html = f"<b>{row['주차장명']}</b><br>총주차면수: {int(row['총주차면수'] if pd.notnull(row['총주차면수']) else 0)}"
            popup = folium.Popup(popup_html, max_width=300)
            color = 'red' if row['유료/무료'] == '유료' else 'blue'
            
            folium.Marker(
                location=[row['위도'], row['경도']],
                popup=popup,
                icon=folium.Icon(color=color, icon='car', prefix='fa')
            ).add_to(gu_map)
        
        print(f"\n{target_gu} 지도 시각화가 'gu_map' 변수에 저장되었습니다. 노트북에서 'gu_map'을 실행하여 확인하세요.")
        # gu_map 변수를 마지막 줄에 두거나 display(gu_map)을 실행하면 지도가 보입니다.
        # display(gu_map)


# COMMAND ----------

# 1. 라이브러리 임포트
from pyspark.sql.functions import col, split, count, when, isnan, desc
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType
import matplotlib.pyplot as plt
import seaborn as sns
import folium
import pandas as pd

# 2. 한글 폰트 설정 (Databricks Init Script로 폰트 설치 후)
plt.rc('font', family='NanumGothic')
plt.rcParams['axes.unicode_minus'] = False
print("라이브러리 및 폰트 설정 완료.")

# 3. 데이터 불러오기 (스키마 직접 정의)
# 가장 안정적인 방법인 스키마 정의를 사용하여 데이터를 로드합니다.
custom_schema = StructType([
    StructField("주차장명", StringType(), True),
    StructField("주소", StringType(), True),
    StructField("주차장코드", StringType(), True),
    StructField("주차장종류", StringType(), True),
    StructField("운영방식", StringType(), True),
    StructField("총주차면수", IntegerType(), True),
    StructField("유료/무료", StringType(), True),
    StructField("일일최대요금", IntegerType(), True),
    StructField("위도", DoubleType(), True),
    StructField("경도", DoubleType(), True),
    StructField("데이터동기화시간", StringType(), True)
])

file_path = "dbfs:/FileStore/seoul_data/seoul_parking_info.csv"
df_spark = spark.read.csv(file_path, header=True, schema=custom_schema)

# 4. 데이터 정제 및 전처리
# 일일최대요금 결측치(null)를 0으로 채웁니다.
df_spark = df_spark.na.fill(0, subset=['일일최대요금'])

# 주소에서 '구' 정보 추출
df_spark = df_spark.withColumn('구', split(col('주소'), ' ').getItem(0))

# 빠른 재사용을 위해 데이터프레임을 캐시에 저장
df_spark.cache()
print("데이터 로드 및 정제 완료.")

# 5. 데이터 기본 정보 확인
print("\n[DataFrame 스키마]")
df_spark.printSchema()

print("\n[컬럼별 결측치(null) 개수]")
df_spark.select([count(when(col(c).isNull(), c)).alias(c) for c in df_spark.columns]).show()


# --- EDA 및 시각화 ---
# PySpark에서는 시각화 전에 데이터를 집계/요약하여 Pandas DataFrame으로 변환하는 것이 일반적입니다.

# 6. 주차장 종류 분석
print("\n--- 주차장 종류 분석 ---")
# Spark로 그룹별 카운트 집계
parking_type_counts = df_spark.groupBy("주차장종류").count().orderBy(desc("count"))
# 시각화를 위해 Pandas로 변환
pd_parking_type_counts = parking_type_counts.toPandas()

plt.figure(figsize=(10, 6))
sns.barplot(data=pd_parking_type_counts, x='주차장종류', y='count')
plt.title('주차장 종류별 개수')
plt.xlabel('주차장 종류')
plt.ylabel('개수')
plt.show()

# 7. 유료/무료 주차장 분석
print("\n--- 유료/무료 주차장 분석 ---")
fee_type_counts = df_spark.groupBy("유료/무료").count().orderBy(desc("count"))
pd_fee_type_counts = fee_type_counts.toPandas()

plt.figure(figsize=(10, 6))
sns.barplot(data=pd_fee_type_counts, x='유료/무료', y='count')
plt.title('유료/무료 주차장 개수')
plt.xlabel('유료/무료')
plt.ylabel('개수')
plt.show()

# 8. 서울시 구별 주차장 분포
print("\n--- 서울시 구별 주차장 분포 ---")
gu_counts = df_spark.groupBy("구").count().orderBy(desc("count"))
pd_gu_counts = gu_counts.toPandas()

plt.figure(figsize=(15, 8))
sns.barplot(data=pd_gu_counts, y='구', x='count', orient='h')
plt.title('서울시 구별 주차장 개수')
plt.xlabel('개수')
plt.ylabel('구')
plt.show()

# 9. 총주차면수 분포 확인 (샘플링 후 시각화)
print("\n--- 총주차면수 분포 ---")
# 데이터가 클 수 있으므로, 10%를 샘플링하여 분포를 확인합니다.
sampled_df = df_spark.select("총주차면수").sample(fraction=0.1).toPandas()

plt.figure(figsize=(12, 6))
sns.histplot(sampled_df['총주차면수'], bins=50, kde=True)
plt.title('총주차면수 분포 (10% 샘플링)')
plt.xlabel('총주차면수')
# x축 범위를 제한하여 더 자세히 확인
plt.xlim(0, sampled_df['총주차면수'].quantile(0.99))
plt.show()

# 10. Folium을 이용한 지도 시각화
print("\n[지도 시각화 생성 중...]")
# 위치 정보가 없는 행은 제외하고, 시각화를 위해 500개만 샘플링하여 Pandas로 변환
map_pd = df_spark.dropna(subset=['위도', '경도']).limit(500).toPandas()

seoul_center = [37.5665, 126.9780]
m = folium.Map(location=seoul_center, zoom_start=11)

for idx, row in map_pd.iterrows():
    popup_html = f"<b>{row['주차장명']}</b><br>총주차면수: {int(row['총주차면수'])}"
    popup = folium.Popup(popup_html, max_width=300)
    color = 'red' if row['유료/무료'] == '유료' else 'blue'
    
    folium.Marker(
        location=[row['위도'], row['경도']],
        popup=popup,
        icon=folium.Icon(color=color, icon='car', prefix='fa')
    ).add_to(m)

print("지도 시각화가 'm' 변수에 저장되었습니다. 노트북에서 'm'을 실행하여 확인하세요.")
# m

# 작업 완료 후 캐시 해제
df_spark.unpersist()


# COMMAND ----------

from pyspark.sql.functions import col, when, lit

# 이 코드는 이전 단계에서 'df_spark' DataFrame이 준비되었다고 가정합니다.
# df_spark.cache() # 재사용을 위해 캐시하는 것을 권장

# --- 1. 이상치 탐지 (IQR 기반) ---
# '총주차면수' 컬럼을 기준으로 이상치를 탐지합니다.

# 1-1. 1사분위수(Q1)와 3사분위수(Q3) 계산
# approxQuantile(컬럼, [사분위수 리스트], 상대 오차)
try:
    quantiles = df_spark.approxQuantile("총주차면수", [0.25, 0.75], 0.01)
    q1 = quantiles[0]
    q3 = quantiles[1]
    iqr = q3 - q1

    # 1-2. 이상치 경계값 정의 (일반적으로 IQR의 1.5배 사용)
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr

    print(f"'총주차면수' 컬럼의 IQR: {iqr}")
    print(f"정상 범위 (Lower Bound): {lower_bound}")
    print(f"정상 범위 (Upper Bound): {upper_bound}")

    # 1-3. 이상치 개수 확인
    outlier_count = df_spark.filter(
        (col("총주차면수") < lower_bound) | (col("총주차면수") > upper_bound)
    ).count()
    
    print(f"탐지된 이상치 개수: {outlier_count:,}")

except Exception as e:
    print(f"이상치 탐지 중 오류 발생: {e}")
    print("데이터에 null 또는 숫자 아닌 값이 포함되어 있을 수 있습니다.")


# --- 2. 이상치 처리 방법 (아래 3가지 옵션 중 하나를 선택하여 사용) ---

# --- 옵션 A: 이상치 제거 (Trimming) ---
print("\n--- 옵션 A: 이상치 제거 (Trimming) ---")
# 정상 범위 내의 데이터만 필터링하여 새로운 DataFrame 생성
df_trimmed = df_spark.filter(
    (col("총주차면수") >= lower_bound) & (col("총주차면수") <= upper_bound)
)
print(f"이상치 제거 후 데이터 개수: {df_trimmed.count():,}")
# display(df_trimmed.describe("총주차면수"))


# --- 옵션 B: 이상치 대치 (Capping) ---
print("\n--- 옵션 B: 이상치 대치 (Capping) ---")
# 경계값을 벗어나는 데이터를 상한/하한 경계값으로 변경
df_capped = df_spark.withColumn(
    "총주차면수_capped",
    when(col("총주차면수") > upper_bound, upper_bound)
    .when(col("총주차면수") < lower_bound, lower_bound)
    .otherwise(col("총주차면수"))
)
print("'총주차면수_capped' 컬럼에 대치된 값이 저장되었습니다.")
# display(df_capped.select("총주차면수", "총주차면수_capped").filter(col("총주차면수") > upper_bound))


# --- 옵션 C: 이상치에 플래그 추가 (Flagging) ---
print("\n--- 옵션 C: 이상치에 플래그 추가 (Flagging) ---")
# 이상치 여부를 boolean 값으로 나타내는 새로운 컬럼 추가
df_flagged = df_spark.withColumn(
    "is_outlier",
    when((col("총주차면수") < lower_bound) | (col("총주차면수") > upper_bound), lit(True))
    .otherwise(lit(False))
)
print("'is_outlier' 컬럼에 이상치 여부가 표시되었습니다.")
# display(df_flagged.filter(col("is_outlier") == True))


# --- 사용 예시 ---
# 예를 들어, '옵션 A'를 선택하여 이상치가 제거된 데이터를 사용하고 싶다면,
# 이후의 모든 분석은 'df_trimmed' DataFrame을 사용하면 됩니다.
#
# print("\n이상치가 제거된 데이터로 '구'별 평균 주차면수 계산:")
# display(df_trimmed.groupBy("구").avg("총주차면수").orderBy(desc("avg(총주차면수)")))

# 작업 완료 후 캐시 해제
# df_spark.unpersist()


# COMMAND ----------

from pyspark.sql.functions import col, desc

# 이 코드는 이전 단계에서 'df_spark' DataFrame과 
# 이상치 경계값(lower_bound, upper_bound)이 계산되었다고 가정합니다.

# 만약 이전 셀을 실행하지 않았다면, 아래 코드로 경계값을 다시 계산해야 합니다.
# --- 경계값 재계산 (필요시 주석 해제) ---
# try:
#     quantiles = df_spark.approxQuantile("총주차면수", [0.25, 0.75], 0.01)
#     q1 = quantiles[0]
#     q3 = quantiles[1]
#     iqr = q3 - q1
#     lower_bound = q1 - 1.5 * iqr
#     upper_bound = q3 + 1.5 * iqr
#     print(f"이상치 경계값 (Upper Bound): {upper_bound}")
# except Exception as e:
#     print(f"경계값 계산 중 오류: {e}")
# -----------------------------------------


# --- 이상치 데이터만 필터링하여 새로운 DataFrame 생성 ---

print(f"'총주차면수'가 {upper_bound:.2f} 보다 크거나 {lower_bound:.2f} 보다 작은 이상치 데이터를 추출합니다.")

# 상한 경계(upper_bound)를 초과하거나 하한 경계(lower_bound) 미만인 데이터만 선택
outliers_df = df_spark.filter(
    (col("총주차면수") > upper_bound) | (col("총주차면수") < lower_bound)
)

# 보기 쉽게 주차면수가 많은 순서대로 정렬
outliers_df_sorted = outliers_df.orderBy(desc("총주차면수"))


# --- 결과 출력 ---
print(f"\n총 {outliers_df_sorted.count()}개의 이상치 데이터가 발견되었습니다.")
print("상위 20개 이상치 데이터 목록:")

# display() 함수를 사용하여 결과를 표 형태로 확인
display(outliers_df_sorted.limit(20))

# 만약 전체 이상치 데이터를 보고 싶다면 아래 코드의 주석을 푸세요.
# display(outliers_df_sorted)


# COMMAND ----------

from pyspark.sql.functions import col, avg, count, desc

# 이 코드는 이전 단계에서 'df_spark' DataFrame이 준비되었다고 가정합니다.
# df_spark.cache() # 재사용을 위해 캐시하는 것을 권장

print("--- 주차장 운영방식 심층 분석 ---")

# --- 1. 운영방식별 분포 확인 ---
print("\n[1. 운영방식별 주차장 개수]")
op_counts = df_spark.groupBy("운영방식").count().orderBy(desc("count"))
display(op_counts)


# --- 2. 운영방식에 따른 평균 주차면수 분석 ---
print("\n[2. 운영방식별 평균 주차면수]")
avg_spaces_by_op = df_spark.groupBy("운영방식") \
    .agg(
        avg("총주차면수").alias("평균_주차면수"),
        count("*").alias("주차장_수")
    ) \
    .orderBy(desc("평균_주차면수"))

display(avg_spaces_by_op)


# --- 3. 운영방식에 따른 평균 요금 분석 (유료 주차장 대상) ---
print("\n[3. 운영방식별 평균 일일최대요금 (유료 주차장만)]")

# 유료이면서 요금 정보가 있는 데이터만 필터링
paid_fee_df = df_spark.filter((col("유료/무료") == "유료") & (col("일일최대요금") > 0))

avg_fee_by_op = paid_fee_df.groupBy("운영방식") \
    .agg(
        avg("일일최대요금").alias("평균_일일최대요금"),
        count("*").alias("주차장_수")
    ) \
    .orderBy(desc("평균_일일최대요금"))

display(avg_fee_by_op)


# --- 4. Box Plot을 이용한 분포 비교 시각화 ---
# 각 운영방식별 '총주차면수'의 전체적인 분포(중앙값, 사분위수, 이상치)를 비교합니다.
print("\n[4. Box Plot: 운영방식별 총주차면수 분포 비교]")

# 분석할 상위 5개 운영방식만 선택 (너무 많으면 그래프가 복잡해짐)
top_5_ops = [row.운영방식 for row in op_counts.head(5)]
df_for_boxplot = df_spark.filter(col("운영방식").isin(top_5_ops))

# 시각화를 위해 Pandas DataFrame으로 변환 (샘플링 권장)
pd_for_boxplot = df_for_boxplot.sample(fraction=0.1).toPandas()

plt.figure(figsize=(15, 8))
sns.boxplot(data=pd_for_boxplot, x="운영방식", y="총주차면수")
plt.title("운영방식별 총주차면수 분포")
plt.xlabel("운영방식")
plt.ylabel("총주차면수")
plt.yscale('log') # 데이터 값의 편차가 크므로 log 스케일로 변경하여 관찰
plt.xticks(rotation=45)
plt.show()


# --- 5. 지역(구)별 운영방식 분포 분석 (관광지/상업지구 특징 유추) ---
print("\n[5. 지역(구)별 주요 운영방식 분포]")
# 각 '구'를 ��으로, '운영방식'을 열로 하여 주차장 개수를 보여주는 피벗 테이블 생성
gu_op_pivot = df_spark.groupBy("구").pivot("운영방식").count().na.fill(0)

# 주차장 총 개수가 많은 순으로 정렬
# 먼저 구별 총합을 계산
gu_total_counts = df_spark.groupBy("구").count().withColumnRenamed("count", "총합")
# 피벗 테이블과 조인 후 정렬
gu_op_pivot_sorted = gu_op_pivot.join(gu_total_counts, "구").orderBy(desc("총합"))

display(gu_op_pivot_sorted)

# 작업 완료 후 캐시 해제
# df_spark.unpersist()


# COMMAND ----------

# MAGIC %md
# MAGIC #### 분석
# MAGIC * 예를 들어, 종로구, 중구(전통적인 도심/관광지)나 
# MAGIC 강남구, 서초구(대표적인 상업지구)에서 
# MAGIC '시간제 주차장'의 비율이 다른 구에 비해 월등히 높게 나타나는지 확인할 수 있다.
# MAGIC * 반면, 주거 지역이 밀집된 구에서는
# MAGIC '거주자 우선 주차장'의 비율이 높게 나타날 것.
# MAGIC * 이 표를 통해 "유명 관광지나 상업지구는
# MAGIC 시간제 유료 주차장이 지배적이다" 와 같은 가설을
# MAGIC 데이터로 검증할 수 있다.

# COMMAND ----------

from pyspark.sql.functions import col, count, when, lit

# 이 코드는 이전 단계에서 'df_spark' DataFrame이 준비되었다고 가정합니다.
# df_spark.cache() # 반복적인 작업 전 캐시를 권장합니다.

print("--- 결측치(Null) 확인 ---")

# --- 방법 1: 각 컬럼별 결측치 개수 계산 (가장 일반적인 방법) ---
print("\n[1. 각 컬럼별 결측치(null) 개수]")

# 각 컬럼에 대해 isNull()이 참인 경우를 카운트합니다.
missing_counts = df_spark.select([count(when(col(c).isNull(), c)).alias(c) for c in df_spark.columns])

# 결과를 보기 쉽게 표 형태로 출력
display(missing_counts)


# --- 방법 2: 각 컬럼별 결측치 비율(%) 계산 ---
print("\n[2. 각 컬럼별 결측치(null) 비율(%)]")

# 전체 행의 개수를 먼저 계산
total_rows = df_spark.count()

# 각 컬럼의 결측치 개수를 전체 행 개수로 나누어 비율을 계산하고 보기 좋게 포맷팅합니다.
missing_percentages = df_spark.select([
    ( (count(when(col(c).isNull(), c)) / lit(total_rows)) * 100 ).alias(c) for c in df_spark.columns
])

display(missing_percentages)


# --- 방법 3: 시각화를 통한 결측치 패턴 확인 (missingno 라이브러리) ---
# Spark의 대용량 데이터를 직접 시각화하기 어려우므로, 일부를 샘플링하여 Pandas로 변환 후 사용합니다.
print("\n[3. 시각화를 통한 결측치 패턴 확인 (샘플링 데이터)]")

try:
    # missingno 라이브러리가 설치되어 있지 않다면 설치
    import missingno as msno
    import matplotlib.pyplot as plt

    # 데이터가 클 경우를 대비해 10000개 행만 샘플링하여 Pandas로 변환
    pd_sample = df_spark.limit(10000).toPandas()

    print("결측치 매트릭스 (흰색 부분이 결측치):")
    msno.matrix(pd_sample)
    plt.show()

    print("\n결측치 막대 그래프:")
    msno.bar(pd_sample)
    plt.show()

except ImportError:
    print("\n'missingno' 라이브러리가 설치되어 있지 않습니다.")
    print("새로운 셀에서 '%pip install missingno'를 실행하여 설치 후 다시 시도해주세요.")
except Exception as e:
    print(f"\n시각화 중 오류 발생: {e}")

# 작업 완료 후 캐시 해제
# df_spark.unpersist()


# COMMAND ----------

# MAGIC %md
# MAGIC ### 결측치 처리
# MAGIC * 위도 경도 데이터가 null인 데이터 행이 상당수 있음.
# MAGIC * 이 부분을 고려해서 처리해야 할 필요성이 있음.
# MAGIC

# COMMAND ----------

# MAGIC %pip install folium
# MAGIC %pip install geopy
# MAGIC
# MAGIC
# MAGIC # Databricks: Pandas DataFrame을 이용한 지도 시각화
# MAGIC # 이 코드는 이전에 로드한 'df' DataFrame을 사용합니다.
# MAGIC # 실행 전, 클러스터 라이브러리에 'folium', 'geopy'가 설치되어 있어야 합니다.
# MAGIC
# MAGIC import pandas as pd
# MAGIC import folium
# MAGIC from geopy.geocoders import Nominatim
# MAGIC import time
# MAGIC
# MAGIC # ==============================================================================
# MAGIC # 1. 데이터 준비 및 위도/경도 컬럼 확인
# MAGIC # ==============================================================================
# MAGIC # 컬럼명이 원본 데이터에 따라 다를 수 있으므로, 일반적인 이름들을 확인합니다.
# MAGIC # (예: '위도', '경도', 'lat', 'lon', 'ADDR', '주소')
# MAGIC
# MAGIC # 원본 DataFrame의 복사본을 만들어 작업을 진행합니다.
# MAGIC df_map = df.copy()
# MAGIC
# MAGIC # 위도/경도 컬럼이 있는지 확인
# MAGIC has_lat_lon = ('위도' in df_map.columns and '경도' in df_map.columns) or \
# MAGIC               ('lat' in df_map.columns and 'lon' in df_map.columns)
# MAGIC
# MAGIC # 주소 컬럼 이름 확인
# MAGIC addr_col = None
# MAGIC if '주소' in df_map.columns:
# MAGIC     addr_col = '주소'
# MAGIC elif 'ADDR' in df_map.columns:
# MAGIC     addr_col = 'ADDR'
# MAGIC
# MAGIC # ==============================================================================
# MAGIC # 2. [시나리오 2] 위도/경도가 없을 경우, 샘플 데이터 지오코딩
# MAGIC # ==============================================================================
# MAGIC if not has_lat_lon and addr_col:
# MAGIC     print("위도/경도 컬럼이 없습니다. 주소 컬럼을 사용하여 샘플 데이터 지오코딩을 시도합니다.")
# MAGIC     print("주의: 이 작업은 외부 API를 사용하므로 시간이 걸릴 수 있으며, 20개 샘플만 변환합니다.")
# MAGIC     
# MAGIC     # Nominatim은 OpenStreetMap 기반의 무료 서비스입니다. (사용량 제한 주의)
# MAGIC     geolocator = Nominatim(user_agent="databricks-eda-notebook")
# MAGIC     
# MAGIC     # 샘플 데이터 추출 (상위 20개)
# MAGIC     df_sample = df_map.head(20).copy()
# MAGIC     
# MAGIC     latitudes, longitudes = [], []
# MAGIC     
# MAGIC     for index, row in df_sample.iterrows():
# MAGIC         address = row[addr_col]
# MAGIC         try:
# MAGIC             location = geolocator.geocode(address)
# MAGIC             if location:
# MAGIC                 latitudes.append(location.latitude)
# MAGIC                 longitudes.append(location.longitude)
# MAGIC             else:
# MAGIC                 latitudes.append(None)
# MAGIC                 longitudes.append(None)
# MAGIC             time.sleep(1) # API 과부하 방지를 위한 1초 대기
# MAGIC         except Exception as e:
# MAGIC             print(f"주소 변환 오류: {address} -> {e}")
# MAGIC             latitudes.append(None)
# MAGIC             longitudes.append(None)
# MAGIC             
# MAGIC     df_sample['위도'] = latitudes
# MAGIC     df_sample['경도'] = longitudes
# MAGIC     
# MAGIC     # 지도 시각화에는 지오코딩이 성공한 데이터만 사용
# MAGIC     df_for_map = df_sample.dropna(subset=['위도', '경도'])
# MAGIC     
# MAGIC elif has_lat_lon:
# MAGIC     print("위도/경도 컬럼이 존재합니다. 바로 시각화를 시작합니다.")
# MAGIC     # 컬럼 이름 통일
# MAGIC     if 'lat' in df_map.columns:
# MAGIC         df_map.rename(columns={'lat': '위도', 'lon': '경도'}, inplace=True)
# MAGIC     df_for_map = df_map.dropna(subset=['위도', '경도'])
# MAGIC else:
# MAGIC     raise ValueError("지도 시각화를 위한 위도/경도 또는 주소 컬럼을 찾을 수 없습니다.")
# MAGIC
# MAGIC # ==============================================================================
# MAGIC # 3. Folium을 이용한 지도 시각화
# MAGIC # ==============================================================================
# MAGIC if not df_for_map.empty:
# MAGIC     print(f"\n{len(df_for_map)}개의 주차장 위치를 지도에 표시합니다.")
# MAGIC     
# MAGIC     # 지도의 중심점을 계산합니다.
# MAGIC     map_center = [df_for_map['위도'].mean(), df_for_map['경도'].mean()]
# MAGIC     
# MAGIC     # 지도 객체 생성
# MAGIC     m = folium.Map(location=map_center, zoom_start=12)
# MAGIC     
# MAGIC     # 주차장 위치에 마커 추가
# MAGIC     for idx, row in df_for_map.iterrows():
# MAGIC         # 팝업에 표시할 정보 (주차장명 컬럼이 없다면 주소로 대체)
# MAGIC         popup_name = row.get('주차장명', row.get(addr_col, '정보 없음'))
# MAGIC         
# MAGIC         folium.Marker(
# MAGIC             location=[row['위도'], row['경도']],
# MAGIC             popup=f"<b>{popup_name}</b><br>{row[addr_col]}",
# MAGIC             tooltip=popup_name
# MAGIC         ).add_to(m)
# MAGIC         
# MAGIC     # Databricks에서 folium 지도를 표시
# MAGIC     map_html = m._repr_html_()
# MAGIC     displayHTML(map_html)
# MAGIC else:
# MAGIC     print("\n지도에 표시할 데이터가 없습니다. (지오코딩 실패 또는 데이터 부족)")
# MAGIC