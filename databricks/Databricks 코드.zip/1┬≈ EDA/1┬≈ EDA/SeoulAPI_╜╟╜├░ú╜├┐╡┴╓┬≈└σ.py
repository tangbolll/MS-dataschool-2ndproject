# Databricks notebook source
# Databricks Notebook용 코드 (연결 정보 직접 입력 방식)

# 1. Cosmos DB 연결 정보 직접 입력
# !!! 경고: 이 방법은 실습 및 테스트용으로만 사용하세요. !!!
# 실제 운영 환경에서는 보안을 위해 절대 코드에 키를 직접 작성하지 말고,
# Databricks Secrets와 Key Vault를 연동하여 사용해야 합니다.

cosmos_endpoint = "https://seoul-data-db.documents.azure.com:443/"  # 예: "https://your-account.documents.azure.com:443/"
cosmos_key = "gdgCLQrX8omjZKrDkLRCyo41URDljVi7K8rdHzTUcUpRLg2k1BR8th6CmyKtUG3XS0wLB2hwe49oACDbxniaXQ=="      # 예: "aBcDeFg...=="

# 2. Cosmos DB 연결을 위한 설정 구성
cosmos_config = {
  "spark.cosmos.accountEndpoint" : cosmos_endpoint,
  "spark.cosmos.accountKey" : cosmos_key,
  "spark.cosmos.database" : "seoul-data-db",
  "spark.cosmos.container" : "seoul-data-container",
  "spark.cosmos.read.inferSchema.enabled" : "true" # 스키마를 자동으로 추론
}

# 3. Spark DataFrame으로 데이터 읽기
# 이 단계에서 클러스터에 설치된 Spark-CosmosDB 커넥터가 사용됩니다.
try:
    spark_df = spark.read.format("cosmos.oltp").options(**cosmos_config).load()
    
    # 4. 데이터 확인
    print("데이터 로딩 성공!")
    print("Spark DataFrame 스키마:")
    spark_df.printSchema()

    # Databricks의 display() 함수로 테이블 형태 미리보기
    display(spark_df)

except Exception as e:
    print("데이터 로딩 중 오류가 발생했습니다.")
    print("오류 메시지:", e)


# COMMAND ----------

# Databricks EDA 데이터 전처리 및 시간대별 분석

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# --- 1. Spark DataFrame을 Pandas DataFrame으로 변환 ---
print("Spark DataFrame을 Pandas DataFrame으로 변환 중...")
# 'spark_df'는 이전 단계에서 Cosmos DB로부터 로드한 Spark DataFrame입니다.
df = spark_df.toPandas()
print(f"변환 완료. 총 {len(df)}개의 데이터.")

# --- !!! [디버깅 단계] !!! ---
# KeyError를 해결하기 위해, 먼저 실제 컬럼 이름을 확인합니다.
# 아래 print문의 결과를 보고 코드의 컬럼 이름('TPKCT', 'NOW_PRK_VHCL_CNT' 등)이 정확한지 확인하세요.
print("\n--- DataFrame에 있는 실제 컬럼 목록 ---")
print(list(df.columns))
print("------------------------------------\n")


# --- 2. 데이터 전처리 및 정제 ---
# 아래 코드의 컬럼 이름은 위에서 출력된 실제 컬럼 이름과 일치해야 합니다.
# 만약 컬럼 이름이 다르다면 (예: 'tpkct' 대신 'TPKCT'), 아래 코드의 이름을 수정해주세요.

try:
    # 불필요한 시스템 컬럼 제거
    df = df.drop(columns=[col for col in df.columns if col.startswith('_')], errors='ignore')

    # 'TPKCT'(총 주차면수)와 'NOW_PRK_VHCL_CNT'(현재 주차대수)를 숫자형으로 변환
    # 변환 중 오류가 발생하는 값(예: 빈 문자열)은 숫자가 아닌 값(NaN)으로 처리
    df['TPKCT'] = pd.to_numeric(df['TPKCT'], errors='coerce')
    df['NOW_PRK_VHCL_CNT'] = pd.to_numeric(df['NOW_PRK_VHCL_CNT'], errors='coerce')

    # 'NOW_PRK_VHCL_UPDT_TM'(업데이트 시간)을 datetime 객체로 변환
    df['UPDT_TM'] = pd.to_datetime(df['NOW_PRK_VHCL_UPDT_TM'], errors='coerce')

    # 전처리 과정에서 문제가 생긴 데이터(NaN) 제거
    df.dropna(subset=['TPKCT', 'NOW_PRK_VHCL_CNT', 'UPDT_TM'], inplace=True)

    # 총 주차면수가 0인 경우는 점유율 계산 시 오류가 발생하므로 제외
    df = df[df['TPKCT'] > 0]

    print("데이터 전처리 완료.")

    # --- 3. 파생 변수 생성 (Feature Engineering) ---

    # 점유율 (Occupancy Rate) 계산
    df['OCCUPANCY_RATE'] = df['NOW_PRK_VHCL_CNT'] / df['TPKCT']
    # 점유율이 1을 초과하는 경우(데이터 오류) 1로 보정
    df.loc[df['OCCUPANCY_RATE'] > 1, 'OCCUPANCY_RATE'] = 1

    # 시간 관련 변수 추출
    df['HOUR'] = df['UPDT_TM'].dt.hour
    df['DAY_OF_WEEK'] = df['UPDT_TM'].dt.day_name() # 요일 이름 (Monday, Tuesday...)
    df['IS_WEEKEND'] = df['UPDT_TM'].dt.weekday >= 5 # 주말 여부 (True/False)

    print("파생 변수 생성 완료: 'OCCUPANCY_RATE', 'HOUR', 'DAY_OF_WEEK', 'IS_WEEKEND'")
    print("\n--- 전처리 및 파생 변수 생성이 완료된 데이터 샘플 ---")
    display(df[['PKLT_NM', 'UPDT_TM', 'TPKCT', 'NOW_PRK_VHCL_CNT', 'OCCUPANCY_RATE', 'HOUR', 'DAY_OF_WEEK', 'IS_WEEKEND']].head())

    # --- 4. 첫 번째 분석: 시간대별 평균 점유율 시각화 ---
    plt.style.use('seaborn-v0_8-whitegrid')
    plt.figure(figsize=(15, 7))
    hourly_occupancy = df.groupby('HOUR')['OCCUPANCY_RATE'].mean()
    sns.barplot(x=hourly_occupancy.index, y=hourly_occupancy.values, palette='viridis')
    plt.title('서울시 주차장 시간대별 평균 점유율', fontsize=18)
    plt.xlabel('시간 (Hour)', fontsize=12)
    plt.ylabel('평균 점유율 (Average Occupancy Rate)', fontsize=12)
    plt.ylim(0, 1)
    plt.xticks(rotation=0)
    print("\n--- 분석 결과: 시간대별 평균 점유율 ---")
    display(plt.gcf())

except KeyError as e:
    print(f"\n!!! KeyError 발생: '{e.args[0]}' 컬럼을 찾을 수 없습니다.")
    print("위의 'DataFrame에 있는 실제 컬럼 목록'을 확인하고 코드의 컬럼 이름을 수정해주세요.")
    print("예시: 만약 실제 컬럼이 'tpkct'라면, 코드의 'TPKCT'를 'tpkct'로 변경해야 합니다.")

# COMMAND ----------

# 1. 스키마 확인 (즉시 실행됨)
print("--- Spark DataFrame 스키마 ---")
spark_df.printSchema()

# 2. 컬럼 목록 확인 (즉시 실행됨)
print("\n--- 실제 컬럼 목록 ---")
print(spark_df.columns)

# 3. 데이터 샘플 확인 (즉시 실행됨)
print("\n--- 데이터 샘플 (상위 5개) ---")
display(spark_df.limit(5))

# COMMAND ----------

from pyspark.sql.functions import col, to_timestamp, hour, mean
from pyspark.sql.types import StructType, StructField, StringType, BooleanType

# ==============================================================================
# 1단계: 전체 데이터에 대한 통합 스키마 직접 정의
# ==============================================================================
# '지역/관광 정보'와 '주차장 정보'의 모든 컬럼을 포함하는 스키마를 만듭니다.
# 모든 컬럼을 nullable=True로 설정하여, 특정 문서에 해당 필드가 없어도 오류가 나지 않도록 합니다.

comprehensive_schema = StructType([
    # --- 주차장 정보 컬럼 ---
    StructField("PKLT_CD", StringType(), True),
    StructField("PKLT_NM", StringType(), True),
    StructField("ADDR", StringType(), True),
    StructField("PKLT_TYPE", StringType(), True),
    StructField("PRK_TYPE_NM", StringType(), True),
    StructField("OPER_SE", StringType(), True),
    StructField("OPER_SE_NM", StringType(), True),
    StructField("TELNO", StringType(), True),
    StructField("PRK_STTS_YN", StringType(), True),
    StructField("PRK_STTS_NM", StringType(), True),
    StructField("TPKCT", StringType(), True),
    StructField("NOW_PRK_VHCL_CNT", StringType(), True),
    StructField("NOW_PRK_VHCL_UPDT_TM", StringType(), True),
    StructField("PAY_YN", StringType(), True),
    StructField("PAY_YN_NM", StringType(), True),
    StructField("id", StringType(), True)
    # ... (다른 모든 주차장 관련 컬럼들도 여기에 추가) ...
])

print("데이터를 읽기 위한 통합 스키마를 정의했습니다.")

# ==============================================================================
# 2단계: 정의된 스키마를 사용하여 데이터 다시 읽기
# ==============================================================================

# Cosmos DB 연결 설정 (이전과 동일)
cosmos_config = {
  "spark.cosmos.accountEndpoint" : cosmos_endpoint,
  "spark.cosmos.accountKey" : cosmos_key,
  "spark.cosmos.database" : "seoul-data-db",
  "spark.cosmos.container" : "seoul-data-container"
}

# --- 'schema' 옵션을 사용하여 정의된 스키마로 데이터를 강제 로딩 ---
# 'inferSchema' 옵션은 더 이상 사용하지 않습니다.
try:
    spark_df_with_schema = spark.read.format("cosmos.oltp") \
                                .options(**cosmos_config) \
                                .schema(comprehensive_schema) \
                                .load()
    print("정의된 스키마를 사용하여 데이터 로딩을 완료했습니다.")
except Exception as e:
    print("스키마를 적용하여 로딩하는 중 오류 발생:", e)
    raise e

# ==============================================================================
# 3단계: 주차장 데이터 필터링 및 분석 (이제 정상 동작해야 함)
# ==============================================================================

try:
    # --- 'PKLT_CD' 컬럼이 null이 아닌 행만 선택 ---
    # 이제 spark_df_with_schema에는 'PKLT_CD' 컬럼이 반드시 존재합니다.
    df_parking_only = spark_df_with_schema.filter(col("PKLT_CD").isNotNull())
    
    count = df_parking_only.count()
    if count == 0:
        raise ValueError("주차장 데이터를 찾을 수 없습니다. ('PKLT_CD' 컬럼이 null이 아닌 행이 없습니다.)")
        
    print(f"실제 주차장 데이터 {count}개를 성공적으로 필터링했습니다.")
    
    print("\n--- 필터링된 실제 주차장 데이터 샘플 ---")
    df_parking_only.select("PKLT_CD", "PKLT_NM", "TPKCT", "NOW_PRK_VHCL_CNT").show(5)

    # --- 데이터 타입 변환 ---
    df_processed = df_parking_only.withColumn("TPKCT_NUM", col("TPKCT").cast("integer")) \
                                  .withColumn("NOW_PRK_VHCL_CNT_NUM", col("NOW_PRK_VHCL_CNT").cast("integer")) \
                                  .withColumn("UPDT_TM", to_timestamp(col("NOW_PRK_VHCL_UPDT_TM")))
    print("\n데이터 타입 변환 완료.")

    # --- 분석에 필요한 데이터만 필터링 ---
    df_clean = df_processed.filter(
        col("UPDT_TM").isNotNull() & \
        col("TPKCT_NUM").isNotNull() & \
        (col("TPKCT_NUM") > 0) & \
        col("NOW_PRK_VHCL_CNT_NUM").isNotNull()
    )
    print("결측치 및 오류 데이터 제거 완료.")

    # --- 점유율 및 시간 관련 파생 변수 추가 ---
    df_features = df_clean.withColumn("OCCUPANCY_RATE", col("NOW_PRK_VHCL_CNT_NUM") / col("TPKCT_NUM")) \
                          .withColumn("HOUR", hour(col("UPDT_TM")))
    print("파생 변수 생성 완료.")

    # --- ��간대별 평균 점유율 계산 ---
    hourly_occupancy_df = df_features.groupBy("HOUR") \
                                     .agg(mean("OCCUPANCY_RATE").alias("avg_occupancy_rate")) \
                                     .orderBy("HOUR")

    print("\n--- 분석 완료: 시간대별 평균 점유율 (Spark DataFrame) ---")
    display(hourly_occupancy_df)

except Exception as e:
    print("\n!!! 오류가 발생했습니다 !!!")
    print("오류 메시지:", e)


# COMMAND ----------

# Databricks EDA: 필터링된 주차장 데이터의 모든 컬럼 상세 보기
# 이 코드는 이전 단계에서 생성된 'df_parking_only' DataFrame을 사용합니다.

from pyspark.sql.functions import col

# ==============================================================================
# 1. 컬럼 설명 정의 (서울시 열린데이터 광장 기준)
# ==============================================================================
# 자주 사용하거나 중요한 컬럼들의 설명을 미리 정의합니다.
column_descriptions = {
    "PKLT_CD": "주차장 코드",
    "PKLT_NM": "주차장명",
    "ADDR": "주소",
    "PKLT_TYPE": "주차장 유형",
    "PRK_TYPE_NM": "주차장 종류명",
    "OPER_SE": "운영 구분",
    "OPER_SE_NM": "운영 구분명",
    "TELNO": "전화번호",
    "TPKCT": "총 주차면수",
    "NOW_PRK_VHCL_CNT": "현재 주차 차량 수",
    "NOW_PRK_VHCL_UPDT_TM": "정보 갱신 시간",
    "PAY_YN": "유무료 구분",
    "PAY_YN_NM": "유무료 구분명",
    "NGHT_PAY_YN": "야간 개방 여부",
    "NGHT_PAY_YN_NM": "야간 개방 여부",
    "WD_OPER_BGNG_TM": "평일 운영 시작 시각",
    "WD_OPER_END_TM": "평일 운영 종료 시각",
    "WE_OPER_BGNG_TM": "주말 운영 시작 시각",
    "WE_OPER_END_TM": "주말 운영 종료 시각",
    "LHLDY_OPER_BGNG_TM": "공휴일 운영 시작 시각",
    "LHLDY_OPER_END_TM": "공휴일 운영 종료 시각",
    "BSC_PRK_CRG": "기본 주차 요금",
    "BSC_PRK_HR": "기본 주차 시간(분)",
    "ADD_PRK_CRG": "추가 단위 요금",
    "ADD_PRK_HR": "추가 단위 시간(분)",
    "DAY_MAX_CRG": "일 최대 요금",
    "id": "ID"
}

print("컬럼 설명을 정의했습니다.")

# ==============================================================================
# 2. 상위 5개 샘플 데이터 가져오기
# ==============================================================================
# .limit(5)로 5개만 선택하고, .collect()로 드라이버 노드로 가져옵니다.
# 데이터 양이 적으므로(5개) 안전하고 빠릅니다.
try:
    samples = df_parking_only.limit(5).collect()
    print(f"\n상세 정보를 출력할 {len(samples)}개의 샘플 데이터를 가져왔습니다.\n")

    # ==============================================================================
    # 3. 각 샘플의 모든 컬럼 정보 상세 출력
    # ==============================================================================
    
    # DataFrame에 실제로 존재하는 컬럼 목록을 가져옵니다.
    available_columns = df_parking_only.columns

    for i, row in enumerate(samples):
        parking_name = row["PKLT_NM"]
        print("="*60)
        print(f"--- [샘플 {i+1}] {parking_name} ---")
        print("="*60)
        
        for col_name in available_columns:
            # 정의된 설명이 있으면 사용하고, 없으면 '기타 정보'로 표시
            description = column_descriptions.get(col_name, "기타 정보")
            
            # row에서 실제 값을 가져옵니다. 값이 없으면(None) 'N/A'로 표시
            value = row[col_name] if row[col_name] is not None else "N/A"
            
            # 보기 좋게 출력
            print(f"- {description} ({col_name}): {value}")
        
        print("\n")

except Exception as e:
    print("\n!!! 오류가 발생했습니다 !!!")
    print("오류 메시지:", e)
    print("이전 단계의 'df_parking_only' DataFrame이 정상적으로 생성되었는지 확인해주세요.")


# COMMAND ----------

# Databricks EDA: 필터링된 Spark DataFrame을 Pandas DataFrame으로 변환

# ==============================================================================
# 1. 필터링된 Spark DataFrame을 Pandas DataFrame으로 변환
# ==============================================================================
# 'df_parking_only'는 177개의 실제 주차장 데이터만 포함하고 있으므로,
# .toPandas()를 사용해도 매우 빠르게 실행됩니다.

print("필터링된 Spark DataFrame (177개 행)을 Pandas DataFrame으로 변환합니다...")

try:
    # 핵심 변환 작업
    pandas_df = df_parking_only.toPandas()

    print("\n변환 성공!")
    print("아래에 Pandas DataFrame 형태로 데이터를 출력합니다.")

    # ==============================================================================
    # 2. Pandas DataFrame 출력
    # ==============================================================================
    # Databricks의 display() 함수에 Pandas DataFrame도 매우 깔끔한 표 형태로 보여줍니다.
    # 표의 헤더를 클릭하여 정렬하는 등 상호작용이 가능합니다.
    
    display(pandas_df)

except Exception as e:
    print("\n!!! 오류가 발생했습니다 !!!")
    print("오류 메시지:", e)
    print("이전 단계의 'df_parking_only' DataFrame이 정상적으로 생성되었는지 확인해주세요.")



# COMMAND ----------

# Databricks EDA: DataFrame 컬럼명을 한글 정의로 변경
# 이 코드는 이전 단계에서 전처리된 'pandas_df' DataFrame을 사용합니다.

# 분석에 사용하지 않을 'AREA_CD', 'AREA_NM', 'PRK_STTS' 컬럼을 삭제합니다.
try:
    columns_to_drop = ['AREA_CD', 'AREA_NM', 'PRK_STTS']
    
    # errors='ignore'는 혹시 컬럼이 존재하지 않더라도 오류를 발생시키지 않는 안전 장치입니다.
    df_cleaned = pandas_df.drop(columns=columns_to_drop, errors='ignore')
    
    print(f"'{', '.join(columns_to_drop)}' 컬럼을 성공적으로 삭제했습니다.")

except Exception as e:
    print(f"컬럼 삭제 중 오류 발생: {e}")
    # 오류가 발생해도 원본 'pandas_df'로 계속 진행하도록 설정
    df_cleaned = pandas_df 

# ==============================================================================
# 1. 한글 컬럼명 매핑 사전 정의
# ==============================================================================
# Key: 기존 컬럼명, Value: 새로운 한글 컬럼명
# (프로그래밍 편의를 위해 띄어쓰기는 '_'로 대체합니다)
korean_column_map = {
    'PKLT_CD': '주차장_코드',
    'PKLT_NM': '주차장명',
    'ADDR': '주소',
    'PKLT_TYPE': '주차장_유형_코드',
    'PRK_TYPE_NM': '주차장_종류명',
    'OPER_SE': '운영_구분_코드',
    'OPER_SE_NM': '운영_구분명',
    'TELNO': '전화번호',
    'PRK_STTS_YN': '실시간_정보_제공_여부',
    'PRK_STTS_NM': '실시간_정보_제공_여부명',
    'TPKCT': '총_주차면수',
    'NOW_PRK_VHCL_CNT': '현재_주차_차량_수',
    'NOW_PRK_VHCL_UPDT_TM': '정보_갱신_시간',
    'PAY_YN': '유무료_구분',
    'PAY_YN_NM': '유무료_구분명',
    'NGHT_PAY_YN': '야간_개방_여부_코드',
    'NGHT_PAY_YN_NM': '야간_개방_여부명',
    'WD_OPER_BGNG_TM': '평일_운영_시작_시각',
    'WD_OPER_END_TM': '평일_운영_종료_시각',
    'WE_OPER_BGNG_TM': '주말_운영_시작_시각',
    'WE_OPER_END_TM': '주말_운영_종료_시각',
    'LHLDY_OPER_BGNG_TM': '공휴일_운영_시작_시각',
    'LHLDY_OPER_END_TM': '공휴일_운영_종료_시각',
    'BSC_PRK_CRG': '기본_주차_요금',
    'BSC_PRK_HR': '기본_주차_시간(분)',
    'ADD_PRK_CRG': '추가_단위_요금',
    'ADD_PRK_HR': '추가_단위_시간(분)',
    'DAY_MAX_CRG': '일_최대_요금',
    'id': 'ID',
    'OCCUPANCY_RATE': '점유율',
    'HOUR': '시간',
    'WEEKDAY_NAME': '요일',
    'IS_WEEKEND': '주말_여부'
}

print("한글 컬럼명 매핑 사전을 정의했습니다.")

# ==============================================================================
# 2. DataFrame 컬럼명 변경
# ==============================================================================
# 원본 DataFrame은 그대로 두고, 컬럼명이 변경된 새로운 DataFrame을 생성합니다.
try:
    pandas_df_korean = df_cleaned.rename(columns=korean_column_map)
    print("정리된 DataFrame의 컬럼명을 한글로 성공적으로 변경했습니다.")

    # ==============================================================================
    # 3. 결과 확인
    # ==============================================================================
    # display() 함수로 보기 좋게 출력합니다.
    print("\n--- 칼럼명이 한글로 정리된 DataFrame ---")
    display(pandas_df_korean)

except Exception as e:
    print("\n!!! 컬럼명 변경 중 오류가 발생했습니다 !!!")
    print("오류 메시지:", e)
    print("이전 단계의 'pandas_df' DataFrame이 정상적으로 생성되었는지 확인해주세요.")


# COMMAND ----------

# MAGIC %pip install koreanize-matplotlib
# MAGIC
# MAGIC import matplotlib.pyplot as plt
# MAGIC import koreanize_matplotlib # 한글 폰트 관련.
# MAGIC
# MAGIC # 시각화 테스트
# MAGIC plt.figure(figsize=(8, 6))
# MAGIC plt.title('한글 테스트 제목')
# MAGIC plt.xlabel('한글 X축')
# MAGIC plt.ylabel('한글 Y축')
# MAGIC plt.plot([1, 2, 3], [10, 20, 15])
# MAGIC plt.text(1.5, 17, '한글 텍스트', fontsize=14, color='red')
# MAGIC plt.show()

# COMMAND ----------

# Databricks Pandas EDA 2단계: 기술 통계 및 단변량 분석
# 이 코드는 이전 단계에서 생성된 'pandas_df_korean' DataFrame을 사용합니다.

import matplotlib.pyplot as plt
import seaborn as sns

# ==============================================================================
# 0. 시각화를 위한 기본 설정 (한글 폰트)
# ==============================================================================
# Databricks 클러스터에 나눔고딕 폰트가 설치되어 있어야 합니다.
# (만약 설치하지 않았다면, 이전에 안내드린 'Init Script' 방법을 사용해주세요.)
try:
    plt.rc('font', family='NanumGothic') 
    plt.rcParams['axes.unicode_minus'] = False # 마이너스 부호 깨짐 방지
    print("한글 폰트 설정을 적용했습니다.")
except Exception as e:
    print(f"폰트 설정 중 경고 발생: {e}")
    print("그래프의 한글이 깨질 수 있습니다. 클러스터에 'fonts-nanum' 패키지 설치를 권장합니다.")

# ==============================================================================
# 분석 1: 총 주차면수 기준 상위 10개 주차장
# ==============================================================================
print("\n--- 분석 1: 가장 주차 공간이 많은 주차장 Top 10 ---")

# '총_주차면수'를 기준으로 내림차순 정렬하여 상위 10개를 선택합니다.
top_10_lots = pandas_df_korean.sort_values(by='총_주차면수', ascending=False).head(10); top_10_lots['총_주차면수'] = pd.to_numeric(top_10_lots['총_주차면수'], errors='coerce')

plt.figure(figsize=(12, 8))
sns.barplot(x='총_주차면수', y='주차장명', data=top_10_lots, palette='viridis')
plt.title('총 주차면수 기준 상위 10개 주차장', fontsize=16, fontweight='bold')
plt.xlabel('총 주차면수', fontsize=12)
plt.ylabel('주차장명', fontsize=12)
display(plt.gcf()) # Databricks에서 그래프를 명확하게 표시
plt.clf() # 이전 그래프 초기화

# ==============================================================================
# 분석 2: 유료 vs 무료 주차장 비율
# ==============================================================================
print("\n--- 분석 2: 유료 vs 무료 주차장 비율 ---")

# '유무료_구분명' 컬럼의 값들을 카운트합니다.
paid_free_counts = pandas_df_korean['유무료_구분명'].value_counts()

plt.figure(figsize=(8, 8))
plt.pie(
    paid_free_counts, 
    labels=paid_free_counts.index, 
    autopct='%1.1f%%', # 소수점 첫째 자리까지 비율 표시
    startangle=140, 
    colors=['#66b3ff','#99ff99', '#ffcc99'],
    textprops={'fontsize': 12}
)
plt.title('유료 vs 무료 주차장 비율', fontsize=16, fontweight='bold')
plt.ylabel('') # 불필요한 y-label 제거
display(plt.gcf())
plt.clf()

# ==============================================================================
# 분석 3: 주차장 종류별 분포
# ==============================================================================
print("\n--- 분석 3: 주차장 종류별 분포 ---")

plt.figure(figsize=(10, 6))
sns.countplot(
    y='주차장_종류명', 
    data=pandas_df_korean, 
    palette='pastel',
    order=pandas_df_korean['주차장_종류명'].value_counts().index # 많은 순서대로 정렬
)
plt.title('주차장 종류별 분포', fontsize=16, fontweight='bold')
plt.xlabel('주차장 개수', fontsize=12)
plt.ylabel('주차장 종류', fontsize=12)
plt.grid(axis='x')
display(plt.gcf())
plt.clf()


# COMMAND ----------

# Databricks 최종 통합 스크립트: Cosmos DB 로딩부터 점유율 분석까지
# 새로운 데이터가 추가되어도 안정적으로 실행되도록 모든 과정을 통합합니다.

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType

# ==============================================================================
# 1단계: 완전한 스키마를 사용하여 Cosmos DB 데이터 로드
# ==============================================================================
print("1단계: 완전한 스키마로 Cosmos DB 데이터 로딩 시작...")
comprehensive_schema = StructType([
    StructField("AREA_CD", StringType(), True), StructField("AREA_NM", StringType(), True),
    StructField("PRK_STTS", StringType(), True), StructField("PKLT_CD", StringType(), True),
    StructField("PKLT_NM", StringType(), True), StructField("ADDR", StringType(), True),
    StructField("PKLT_TYPE", StringType(), True), StructField("PRK_TYPE_NM", StringType(), True),
    StructField("OPER_SE", StringType(), True), StructField("OPER_SE_NM", StringType(), True),
    StructField("TELNO", StringType(), True), StructField("PRK_STTS_YN", StringType(), True),
    StructField("PRK_STTS_NM", StringType(), True), StructField("TPKCT", StringType(), True),
    StructField("NOW_PRK_VHCL_CNT", StringType(), True), StructField("NOW_PRK_VHCL_UPDT_TM", StringType(), True),
    StructField("PAY_YN", StringType(), True), StructField("PAY_YN_NM", StringType(), True),
    StructField("id", StringType(), True)
    # 필요 시 다른 컬럼들도 여기에 추가
])
cosmos_config = {
  "spark.cosmos.accountEndpoint" : cosmos_endpoint, "spark.cosmos.accountKey" : cosmos_key,
  "spark.cosmos.database" : "seoul-data-db", "spark.cosmos.container" : "seoul-data-container"
}
spark_df_with_schema = spark.read.format("cosmos.oltp").options(**cosmos_config).schema(comprehensive_schema).load()
print("-> 로딩 완료.")

# ==============================================================================
# 2단계: 데이터 필터링 및 Pandas 변환
# ==============================================================================
print("2단계: 주차장 데이터 필터링 및 Pandas 변환 시작...")
df_parking_only = spark_df_with_schema.filter(col("PKLT_CD").isNotNull())
pandas_df_raw = df_parking_only.toPandas()
print("-> 변환 완료.")

# ==============================================================================
# 3단계: 데이터 전처리 및 파생 변수 생성 (KeyError 해결의 핵심)
# ==============================================================================
print("3단계: 데이터 전처리 및 '점유율' 컬럼 생성 시작...")
df_processed = pandas_df_raw.copy()
# 숫자형으로 변환
df_processed['TPKCT'] = pd.to_numeric(df_processed['TPKCT'], errors='coerce')
df_processed['NOW_PRK_VHCL_CNT'] = pd.to_numeric(df_processed['NOW_PRK_VHCL_CNT'], errors='coerce')
# 날짜/시간형으로 변환
df_processed['NOW_PRK_VHCL_UPDT_TM'] = pd.to_datetime(df_processed['NOW_PRK_VHCL_UPDT_TM'], errors='coerce')
# 변환 중 문제가 생긴 행(NaT) 제거
df_processed.dropna(subset=['TPKCT', 'NOW_PRK_VHCL_CNT', 'NOW_PRK_VHCL_UPDT_TM'], inplace=True)
# 점유율 (Occupancy Rate) 생성
df_processed['OCCUPANCY_RATE'] = df_processed.apply(
    lambda row: row['NOW_PRK_VHCL_CNT'] / row['TPKCT'] if row['TPKCT'] > 0 else 0, axis=1
)
df_processed.loc[df_processed['OCCUPANCY_RATE'] > 1, 'OCCUPANCY_RATE'] = 1
print("-> 전처리 완료.")

# ==============================================================================
# 4단계: 컬럼 정리 및 한글명 변경
# ==============================================================================
print("4단계: 컬럼 정리 및 한글명 변경 시작...")
columns_to_drop = ['AREA_CD', 'AREA_NM', 'PRK_STTS']
df_cleaned = df_processed.drop(columns=columns_to_drop, errors='ignore')
korean_column_map = {
    'PKLT_NM': '주차장명', 'TPKCT': '총_주차면수', 'OCCUPANCY_RATE': '점유율'
    # 필요에 따라 다른 컬럼들도 여기에 추가
}
pandas_df_korean = df_cleaned.rename(columns=korean_column_map)
print("-> 변경 완료.")

# ==============================================================================
# 5단계: 주차장 이용 현황 (점유율) 심층 분석 (요청하신 최종 분석)
# ==============================================================================
print("\n5단계: 점유율 심층 분석 시작...")
try:
    plt.rc('font', family='NanumGothic') 
    plt.rcParams['axes.unicode_minus'] = False
except:
    print("폰트 설정 중 경고 발생")

# 주차장별 '평균 점유율' 계산
avg_occupancy_by_lot = pandas_df_korean.groupby('주차장명').agg(
    점유율=('점유율', 'mean'),
    총_주차면수=('총_주차면수', 'first')
).reset_index()

# --- 분석 1: 평균 점유율 Top 10 ---
print("\n[분석 1: 평균 점유율이 가장 높은 주차장 Top 10]")
top_10_utilized = avg_occupancy_by_lot.sort_values(by='점유율', ascending=False).head(10)
plt.figure(figsize=(12, 8))
sns.barplot(x='점유율', y='주차장명', data=top_10_utilized, palette='Reds_r')
plt.title('평균 점유율이 가장 높은 주차장 Top 10', fontsize=16, fontweight='bold')
plt.xlabel('평균 점유율', fontsize=12)
plt.ylabel('주차장명', fontsize=12)
plt.xlim(0, 1)
display(plt.gcf())
plt.clf()

# --- 분석 2: 주차장 규모와 평균 점유율의 관계 ---
print("\n[분석 2: 주차장 규모와 평균 점유율의 관계]")
plt.figure(figsize=(14, 8))
sns.scatterplot(
    data=avg_occupancy_by_lot, x='총_주차면수', y='점유율',
    size='총_주차면수', hue='점유율', palette='viridis',
    sizes=(50, 1000), alpha=0.7
)
plt.title('주차장 규모와 평균 점유율의 관계', fontsize=16, fontweight='bold')
plt.xlabel('총 주차면수 (주차장 규모)', fontsize=12)
plt.ylabel('평균 점유율', fontsize=12)
plt.grid(True)
display(plt.gcf())
plt.clf()

print("\n분석이 성공적으로 완료되었습니다.")


# COMMAND ----------

# Databricks Pandas EDA : 시간에 따른 주차 수요 분석
# 이 코드는 한글 컬럼명이 적용된 'pandas_df_korean' DataFrame을 사용합니다.
# 데이터 로딩부터, 주말 데이터 존재 여부를 확인하는 안정적인 시간 분석까지 모두 포함합니다.

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType

# ==============================================================================
# 1단계: 완전한 스키마를 사용하여 Cosmos DB 데이터 로드
# ==============================================================================
print("1단계: 완전한 스키마로 Cosmos DB 데이터 로딩 시작...")
comprehensive_schema = StructType([
    StructField("AREA_CD", StringType(), True), StructField("AREA_NM", StringType(), True),
    StructField("PRK_STTS", StringType(), True), StructField("PKLT_CD", StringType(), True),
    StructField("PKLT_NM", StringType(), True), StructField("ADDR", StringType(), True),
    StructField("TPKCT", StringType(), True), StructField("NOW_PRK_VHCL_CNT", StringType(), True),
    StructField("NOW_PRK_VHCL_UPDT_TM", StringType(), True)
    # 필요 시 다른 컬럼들도 여기에 추가
])
cosmos_config = {
  "spark.cosmos.accountEndpoint" : cosmos_endpoint, "spark.cosmos.accountKey" : cosmos_key,
  "spark.cosmos.database" : "seoul-data-db", "spark.cosmos.container" : "seoul-data-container"
}
spark_df_with_schema = spark.read.format("cosmos.oltp").options(**cosmos_config).schema(comprehensive_schema).load()
print("-> 로딩 완료.")

# ==============================================================================
# 2단계: 데이터 필터링, Pandas 변환, 전처리 및 파생 변수 생성
# ==============================================================================
print("2단계: 데이터 필터링, 변환 및 전처리 시작...")
df_parking_only = spark_df_with_schema.filter(col("PKLT_CD").isNotNull())
pandas_df_raw = df_parking_only.toPandas()

# 전처리
df_processed = pandas_df_raw.copy()
df_processed['TPKCT'] = pd.to_numeric(df_processed['TPKCT'], errors='coerce')
df_processed['NOW_PRK_VHCL_CNT'] = pd.to_numeric(df_processed['NOW_PRK_VHCL_CNT'], errors='coerce')
df_processed['NOW_PRK_VHCL_UPDT_TM'] = pd.to_datetime(df_processed['NOW_PRK_VHCL_UPDT_TM'], errors='coerce')
df_processed.dropna(subset=['TPKCT', 'NOW_PRK_VHCL_CNT', 'NOW_PRK_VHCL_UPDT_TM'], inplace=True)

# 파생 변수 생성
df_processed['OCCUPANCY_RATE'] = df_processed.apply(
    lambda row: row['NOW_PRK_VHCL_CNT'] / row['TPKCT'] if row['TPKCT'] > 0 else 0, axis=1
)
df_processed.loc[df_processed['OCCUPANCY_RATE'] > 1, 'OCCUPANCY_RATE'] = 1
df_processed['HOUR'] = df_processed['NOW_PRK_VHCL_UPDT_TM'].dt.hour
df_processed['IS_WEEKEND'] = df_processed['NOW_PRK_VHCL_UPDT_TM'].dt.weekday >= 5 # 5:토, 6:일
print("-> 전처리 및 파생 변수 생성 완료.")

# ==============================================================================
# 3단계: 컬럼 정리 및 한글명 변경
# ==============================================================================
print("3단계: 컬럼 정리 및 한글명 변경 시작...")
df_cleaned = df_processed.drop(columns=['AREA_CD', 'AREA_NM', 'PRK_STTS'], errors='ignore')
korean_column_map = {
    'PKLT_NM': '주차장명', 'TPKCT': '총_주차면수', 'NOW_PRK_VHCL_CNT': '현재_주차_차량_수',
    'NOW_PRK_VHCL_UPDT_TM': '정보_갱신_시간', 'OCCUPANCY_RATE': '점유율',
    'HOUR': '시간', 'IS_WEEKEND': '주말_여부'
}
pandas_df_korean = df_cleaned.rename(columns=korean_column_map)
print("-> 변경 완료.")

# ==============================================================================
# 4단계: 시간에 따른 주차 수요 분석 (안정성 강화)
# ==============================================================================
print("\n4단계: 시간 분석 시작")
try:
    plt.rc('font', family='NanumGothic') 
    plt.rcParams['axes.unicode_minus'] = False
except:
    print("폰트 설정 중 경고 발생")

# --- 분석 1: 서울시 전체의 시간대별 평균 주차 점유율 (항상 실행) ---
print("\n[분석 1: 서울시 전체의 시간대별 평균 주차 점유율]")
hourly_occupancy = pandas_df_korean.groupby('시간')['점유율'].mean()
plt.figure(figsize=(15, 7))
sns.lineplot(x=hourly_occupancy.index, y=hourly_occupancy.values, marker='o', color='royalblue', lw=2)
plt.title('서울시 전체 시간대별 평균 주차 점유율', fontsize=16, fontweight='bold')
plt.xlabel('시간 (24시)', fontsize=12)
plt.ylabel('평균 점유율', fontsize=12)
plt.xticks(range(0, 24))
plt.grid(True, which='both', linestyle='--', linewidth=0.5)
plt.ylim(0, 1)
display(plt.gcf())
plt.clf()

# --- 분석 2: 주중 vs 주말의 시간대별 점유율 패턴 비교 (조건부 실행) ---
print("\n[분석 2: 주중 vs 주말의 시간대별 점유율 패턴 비교]")

# [핵심 로직] '주말_여부' 컬럼에 2개 종류(True, False)의 데이터가 모두 있는지 확인
if pandas_df_korean['주말_여부'].nunique() < 2:
    print("-> 주중과 주말 데이터가 모두 존재하지 않아 비교 그래프를 생략합니다.")
    current_data_type = '주말' if pandas_df_korean['주말_여부'].unique()[0] else '주중'
    print(f"-> 현재 데이터는 '{current_data_type}' 데이터만 포함하고 있습니다.")
else:
    print("-> 주중, 주말 데이터가 모두 존재하여 비교 그래프를 생성합니다.")
    comparison_occupancy = pandas_df_korean.groupby(['주말_여부', '시간'])['점유율'].mean().reset_index()
    comparison_occupancy['주말_여부'] = comparison_occupancy['주말_여부'].apply(lambda x: '주말' if x else '주중')
    
    plt.figure(figsize=(15, 7))
    sns.lineplot(
        data=comparison_occupancy, x='시간', y='점유율', hue='주말_여부',
        marker='o', lw=2, palette={'주중': 'navy', '주말': 'crimson'}
    )
    plt.title('주중 vs 주말 시간대별 평균 주차 점유율 비교', fontsize=16, fontweight='bold')
    plt.xlabel('시간 (24시)', fontsize=12)
    plt.ylabel('평균 점유율', fontsize=12)
    plt.xticks(range(0, 24))
    plt.grid(True, which='both', linestyle='--', linewidth=0.5)
    plt.ylim(0, 1)
    plt.legend(title='구분', fontsize=12)
    display(plt.gcf())
    plt.clf()

print("\n분석이 성공적으로 완료되었습니다.")

print("\n\n 주말 데이터가 없는 이유는 아직 주말 데이터가 수집되지 않았기 때문.")


# COMMAND ----------

# MAGIC %md
# MAGIC ### 주말데이터가 없는 이유는 데이터 수집한 날이 주말이 아니기 때문.
# MAGIC

# COMMAND ----------

# 데이터 로딩부터 결측치 분석까지의 과정

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.colors import ListedColormap
from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, StringType

# ==============================================================================
# 1~3단계: 데이터 로드, 전처리, 한글명 변경
# ==============================================================================
print("1~3단계: 데이터 로드, 전처리, 한글명 변경을 시작합니다...")
# 1. 스키마 정의 및 로드
comprehensive_schema = StructType([
    StructField("AREA_CD", StringType(), True), StructField("AREA_NM", StringType(), True),
    StructField("PRK_STTS", StringType(), True), StructField("PKLT_CD", StringType(), True),
    StructField("PKLT_NM", StringType(), True), StructField("ADDR", StringType(), True),
    StructField("TPKCT", StringType(), True), StructField("NOW_PRK_VHCL_CNT", StringType(), True),
    StructField("NOW_PRK_VHCL_UPDT_TM", StringType(), True),
    StructField("TELNO", StringType(), True), StructField("PAY_YN", StringType(), True)
])
cosmos_config = {
  "spark.cosmos.accountEndpoint" : cosmos_endpoint, "spark.cosmos.accountKey" : cosmos_key,
  "spark.cosmos.database" : "seoul-data-db", "spark.cosmos.container" : "seoul-data-container"
}
spark_df_with_schema = spark.read.format("cosmos.oltp").options(**cosmos_config).schema(comprehensive_schema).load()
# 2. 필터링 및 Pandas 변환
df_parking_only = spark_df_with_schema.filter(col("PKLT_CD").isNotNull())
pandas_df_raw = df_parking_only.toPandas()
# 3. 컬럼 정리 및 한글명 변경
df_cleaned = pandas_df_raw.drop(columns=['AREA_CD', 'AREA_NM', 'PRK_STTS'], errors='ignore')
korean_column_map = {
    'PKLT_CD': '주차장_코드', 'PKLT_NM': '주차장명', 'ADDR': '주소', 'TPKCT': '총_주차면수',
    'NOW_PRK_VHCL_CNT': '현재_주차_차량_수', 'NOW_PRK_VHCL_UPDT_TM': '정보_갱신_시간',
    'TELNO': '전화번호', 'PAY_YN': '유무료_구분'
}
pandas_df_korean = df_cleaned.rename(columns=korean_column_map)
print("-> 1~3단계 완료.")

# ==============================================================================
# 4단계: 데이터 결측치 확인 (커스텀 색상 적용)
# ==============================================================================
print("\n4단계: 데이터 결측치 분석 시작...")
try:
    plt.rc('font', family='NanumGothic') 
    plt.rcParams['axes.unicode_minus'] = False
except:
    print("폰트 설정 중 경고 발생")

# --- 분석 1: 컬럼별 결측치 개수 및 비율 (변경 없음) ---
print("\n[분석 1: 컬럼별 결측치 개수 및 비율]")
missing_counts = pandas_df_korean.isnull().sum()
missing_counts = missing_counts[missing_counts > 0]
if missing_counts.empty:
    print("-> 데이터에 결측치가 없습니다.")
else:
    missing_percentage = (missing_counts / len(pandas_df_korean)) * 100
    missing_info = pd.DataFrame({'결측치_개수': missing_counts, '결측치_비율(%)': missing_percentage})
    missing_info.sort_values(by='결측치_개수', ascending=False, inplace=True)
    display(missing_info)

# --- 분석 2: 결측치 분포 시각화 (히트맵) ---
print("\n[분석 2: 결측치 분포 시각화 (히트맵)]")

# --- [사용자 지정 영역] ---
# 색상 변경 영역.
# 첫 번째 색상: 값이 있는 부분 (배경)
# 두 번째 색상: 결측치 (선)
custom_colors = ['#EAEAF2', '#483D8B']


# 커스텀 컬러맵 생성
custom_cmap = ListedColormap(custom_colors)
# -------------------------

plt.figure(figsize=(20, 10))
# [색상 변경] cmap에 직접 만든 'custom_cmap'을 적용합니다.
sns.heatmap(pandas_df_korean.isnull(), cbar=False, cmap=custom_cmap, yticklabels=False)
plt.title('데이터 결측치 분포 히트맵', fontsize=16, fontweight='bold')
display(plt.gcf())
plt.clf()

# --- 분석 3: 결측치가 있는 행(Row) 샘플 확인 (변경 없음) ---
if not missing_counts.empty:
    most_missing_col = missing_counts.idxmax()
    print(f"\n[분석 3: 결측치가 가장 많은 '{most_missing_col}' 컬럼의 샘플 데이터]")
    missing_samples = pandas_df_korean[pandas_df_korean[most_missing_col].isnull()].head()
    display(missing_samples)

print("\n분석이 성공적으로 완료되었습니다.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 주로 정보갱신시간, 전화번호가 정보가 누락이 많이 되어 있음.

# COMMAND ----------

# Databricks EDA: 전체 프로세스 재실행 및 이상치 분석
# 불완전했던 스키마 문제를 해결하고, 데이터 로딩부터 이상치 분석까지 한 번에 실행합니다.

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pyspark.sql.functions import col, to_timestamp, hour
from pyspark.sql.types import StructType, StructField, StringType

# ==============================================================================
# 1단계: [수정] 완전한 통합 스키마 정의
# ==============================================================================
# 이전에 누락되었던 요금 관련 컬럼 등을 모두 포함합니다.
comprehensive_schema = StructType([
    # 지역/관광 정보 컬럼
    StructField("AREA_CD", StringType(), True),
    StructField("AREA_NM", StringType(), True),
    StructField("PRK_STTS", StringType(), True),
    # 주차장 정보 컬럼 (전체)
    StructField("PKLT_CD", StringType(), True), StructField("PKLT_NM", StringType(), True),
    StructField("ADDR", StringType(), True), StructField("PKLT_TYPE", StringType(), True),
    StructField("PRK_TYPE_NM", StringType(), True), StructField("OPER_SE", StringType(), True),
    StructField("OPER_SE_NM", StringType(), True), StructField("TELNO", StringType(), True),
    StructField("PRK_STTS_YN", StringType(), True), StructField("PRK_STTS_NM", StringType(), True),
    StructField("TPKCT", StringType(), True), StructField("NOW_PRK_VHCL_CNT", StringType(), True),
    StructField("NOW_PRK_VHCL_UPDT_TM", StringType(), True), StructField("PAY_YN", StringType(), True),
    StructField("PAY_YN_NM", StringType(), True), StructField("NGHT_PAY_YN", StringType(), True),
    StructField("NGHT_PAY_YN_NM", StringType(), True), StructField("WD_OPER_BGNG_TM", StringType(), True),
    StructField("WD_OPER_END_TM", StringType(), True), StructField("WE_OPER_BGNG_TM", StringType(), True),
    StructField("WE_OPER_END_TM", StringType(), True), StructField("LHLDY_OPER_BGNG_TM", StringType(), True),
    StructField("LHLDY_OPER_END_TM", StringType(), True), StructField("BSC_PRK_CRG", StringType(), True),
    StructField("BSC_PRK_HR", StringType(), True), StructField("ADD_PRK_CRG", StringType(), True),
    StructField("ADD_PRK_HR", StringType(), True), StructField("DAY_MAX_CRG", StringType(), True),
    StructField("id", StringType(), True)
])
print("완전한 통합 스키마를 정의했습니다.")

# ==============================================================================
# 2단계: 정의된 스키마를 사용하여 데이터 다시 읽기
# ==============================================================================
cosmos_config = {
  "spark.cosmos.accountEndpoint" : cosmos_endpoint, "spark.cosmos.accountKey" : cosmos_key,
  "spark.cosmos.database" : "seoul-data-db", "spark.cosmos.container" : "seoul-data-container"
}
spark_df_with_schema = spark.read.format("cosmos.oltp").options(**cosmos_config).schema(comprehensive_schema).load()
print("정의된 스키마를 사용하여 데이터 로딩을 완료했습니다.")

# ==============================================================================
# 3단계: 주차장 데이터 필터링, Pandas 변환, 컬럼 정리 및 한글명 변경
# ==============================================================================
# 필터링
df_parking_only = spark_df_with_schema.filter(col("PKLT_CD").isNotNull())
# Pandas 변환
pandas_df = df_parking_only.toPandas()
# 불필요한 컬럼 삭제
columns_to_drop = ['AREA_CD', 'AREA_NM', 'PRK_STTS']
df_cleaned = pandas_df.drop(columns=columns_to_drop, errors='ignore')
# 한글명 변경
korean_column_map = {
    'PKLT_CD': '주차장_코드', 'PKLT_NM': '주차장명', 'ADDR': '주소', 'PKLT_TYPE': '주차장_유형_코드',
    'PRK_TYPE_NM': '주차장_종류명', 'OPER_SE': '운영_구분_코드', 'OPER_SE_NM': '운영_구분명', 'TELNO': '전화번호',
    'PRK_STTS_YN': '실시간_정보_제공_여부', 'PRK_STTS_NM': '실시간_정보_제공_여부명', 'TPKCT': '총_주차면수',
    'NOW_PRK_VHCL_CNT': '현재_주차_차량_수', 'NOW_PRK_VHCL_UPDT_TM': '정보_갱신_시간', 'PAY_YN': '유무료_구분',
    'PAY_YN_NM': '유무료_구분명', 'NGHT_PAY_YN': '야간_개방_여부_코드', 'NGHT_PAY_YN_NM': '야간_개방_여부명',
    'WD_OPER_BGNG_TM': '평일_운영_시작_시각', 'WD_OPER_END_TM': '평일_운영_종료_시각', 'WE_OPER_BGNG_TM': '주말_운영_시작_시각',
    'WE_OPER_END_TM': '주말_운영_종료_시각', 'LHLDY_OPER_BGNG_TM': '공휴일_운영_시작_시각', 'LHLDY_OPER_END_TM': '공휴일_운영_종료_시각',
    'BSC_PRK_CRG': '기본_주차_요금', 'BSC_PRK_HR': '기본_주차_시간(분)', 'ADD_PRK_CRG': '추가_단위_요금',
    'ADD_PRK_HR': '추가_단위_시간(분)', 'DAY_MAX_CRG': '일_최대_요금', 'id': 'ID'
}
pandas_df_korean = df_cleaned.rename(columns=korean_column_map)
print("데이터 필터링, 변환, 정리, 한글명 변경을 모두 완료했습니다.")

# ==============================================================================
# 4단계: 이상치 분석 (이전 코드와 동일)
# ==============================================================================
print("\n--- 이상치 분석 시작 ---")
try:
    plt.rc('font', family='NanumGothic') 
    plt.rcParams['axes.unicode_minus'] = False
except:
    print("폰트 설정 중 경고 발생")

# 분석할 주요 수치 컬럼 선택
numeric_cols_to_check = ['총_주차면수', '기본_주차_요금', '일_최대_요금']
for col_name in numeric_cols_to_check:
    pandas_df_korean[col_name] = pd.to_numeric(pandas_df_korean[col_name], errors='coerce')

print("\n[기술 통계]")
display(pandas_df_korean[numeric_cols_to_check].describe())

print("\n[박스 플롯 시각화]")
plt.figure(figsize=(20, 6))
for i, col_name in enumerate(numeric_cols_to_check):
    plt.subplot(1, 3, i+1)
    sns.boxplot(y=pandas_df_korean[col_name])
    plt.title(f"'{col_name}'의 박스 플롯", fontsize=14)
    plt.ylabel("값")
plt.tight_layout()
display(plt.gcf())
plt.clf()

print("\n[식별된 이상치 데이터]")
for col_name in numeric_cols_to_check:
    data = pandas_df_korean[col_name].dropna()
    Q1, Q3 = data.quantile(0.25), data.quantile(0.75)
    IQR = Q3 - Q1
    lower_bound, upper_bound = Q1 - 1.5 * IQR, Q3 + 1.5 * IQR
    outliers = pandas_df_korean[(pandas_df_korean[col_name] < lower_bound) | (pandas_df_korean[col_name] > upper_bound)]
    if not outliers.empty:
        print(f"\n'{col_name}' 컬럼에서 발견된 이상치 ({len(outliers)}개):")
        display(outliers[['주차장명', col_name, '총_주차면수', '주소']])
    else:
        print(f"\n'{col_name}' 컬럼에서는 이상치가 발견되지 않았습니다.")



# COMMAND ----------

# MAGIC %md
# MAGIC ### 주차장 번호가 누락이 되는 경우가 많음.

# COMMAND ----------

print(f"pandas_df_korean의 행 수: {len(pandas_df_korean)}")
print("pandas_df_korean의 첫 5행:")
display(pandas_df_korean.head())

# COMMAND ----------

# Azure Blob Storage에 데이터 저장 스크립트 (Databricks Notebook용)
# 이 스크립트는 Spark CSV 쓰기 동작을 활용하여 단일 CSV 파일을 생성합니다.

import datetime
import traceback # Added for detailed error logging

# 이 스크립트를 실행하기 전에 Databricks Notebook 환경에 다음 변수가 설정되어 있어야 합니다:
storage_account_name = "cosmo2csv"  # 실제 스토리지 계정 이름으로 변경하세요.
storage_account_key = "jkUvA9iMfrJ8JHNSuuOs21uFYfM7g2Gu7D/CubSAEE6bknEtqp7x8woG3XGZSqviuth3t14oPvpk+AStKqz1qg==" # Azure Portal에서 스토리지 계정의 액세스 키를 확인하여 여기에 붙여넣으세요.

print("Azure Blob Storage에 단일 CSV 파일 저장을 시작합니다...")

try:
    # Spark 설정: 스토리지 계정 키를 사용하여 Blob Storage에 연결합니다.
    # 이 설정은 Databricks 세션 시작 시 한 번만 해주면 됩니다.
    spark.conf.set(f"fs.azure.account.key.{storage_account_name}.dfs.core.windows.net", storage_account_key)
    print("-> Spark 설정 완료: Blob Storage 연결 준비.")

    # Pandas DataFrame을 Spark DataFrame으로 변환합니다.
    # Databricks 환경에서 대용량 데이터를 처리할 때 Spark DataFrame을 사용하는 것이 효율적입니다.
    spark_df_to_save = spark.createDataFrame(pandas_df_korean)
    print("-> Pandas DataFrame을 Spark DataFrame으로 변환 완료.")

    # --- 진단 코드 시작 ---
    # Spark DataFrame의 행 수 확인
    spark_df_row_count = spark_df_to_save.count()
    print(f"-> Spark DataFrame (spark_df_to_save)의 행 수: {spark_df_row_count}")
    if spark_df_row_count == 0:
        print("경고: Spark DataFrame이 비어있습니다. 0바이트 파일이 생성될 수 있습니다. 쓰기 작업을 건너뜁니다.")
        print("데이터 저장 파이프라인이 완료되었습니다 (데이터 없음).")
        exit() # 또는 return
    
    # Spark DataFrame 캐싱 (선택 사항이지만, 데이터 유무 확인에 도움)
    spark_df_to_save.cache()
    print("-> Spark DataFrame 캐싱 완료.")
    # --- 진단 코드 끝 ---

    # Spark가 CSV를 저장할 임시 디렉토리 경로 설정
    # 고유한 디렉토리 이름을 사용하여 충돌을 방지합니다.
    temp_output_dir = f"abfss://parkingcsv@{storage_account_name}.dfs.core.windows.net/temp_parking_data_{datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')}"
    print(f"-> Spark 임시 출력 디렉토리: {temp_output_dir}")

    # Spark DataFrame을 CSV로 임시 ���렉토리에 저장합니다.
    # .repartition(1)을 사용하여 모든 데이터를 단일 파티션으로 모아 하나의 part-xxxxx.csv 파일로 저장되도록 합니다.
    spark_df_to_save.repartition(1).write.mode("overwrite").option("header", "true").csv(temp_output_dir)
    print(f"-> 데이터가 임시 디렉토리 {temp_output_dir}에 성공적으로 저장되었습니다.")

    # 임시 디렉토리에서 실제 part-xxxxx.csv 파일 찾기
    # dbutils는 Databricks 환경에서만 사용 가능합니다.
    part_file_path = None
    files_in_temp_dir = dbutils.fs.ls(temp_output_dir)
    for f in files_in_temp_dir:
        if f.name.startswith("part-") and f.name.endswith(".csv"):
            part_file_path = f.path
            break

    if part_file_path:
        # 최종적으로 원하는 단일 CSV 파일 경로 설정
        final_output_path = f"abfss://parkingcsv@{storage_account_name}.dfs.core.windows.net/parking_data.csv"
        
        # part-xxxxx.csv 파일을 원하는 이름으로 복사
        # recurse=True는 파일 복사에도 사용될 수 있으며, 대상 파일이 이미 존재하면 덮어씁니다.
        dbutils.fs.cp(part_file_path, final_output_path, recurse=True)
        print(f"-> {part_file_path} 파일이 {final_output_path}로 성공적으로 복사되었습��다.")
        print(f"Blob Storage에서 {final_output_path} 파일을 확인해주세요.")
    else:
        print("경고: 임시 디렉토리에서 'part-xxxxx.csv' 파일을 찾을 수 없습니다. 단일 파일 복사 실패.")

except Exception as e:
    print(f"Azure Blob Storage에 데이터 저장 중 오류 발생: {e}")
    # 더 자세한 오류 메시지를 위해 스택 트레이스도 출력
    traceback.print_exc()
    raise e

finally:
    # 임시 디렉토리 정리 (선택 사항이지만 권장)
    try:
        if 'temp_output_dir' in locals() and dbutils.fs.ls(temp_output_dir): # 디렉토리가 존재하는지 확인 후 삭제
            dbutils.fs.rm(temp_output_dir, recurse=True)
            print(f"-> 임시 디렉토리 {temp_output_dir} 삭제 완료.")
    except Exception as e:
        print(f"임시 디렉토리 삭제 중 오류 발생: {e}")
        traceback.print_exc()

print("데이터 저장 파이프라인이 완료되었습니다.")
