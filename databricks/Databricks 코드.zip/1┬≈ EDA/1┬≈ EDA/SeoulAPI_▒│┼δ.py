# Databricks notebook source
spark.sql("USE default")

df1 = spark.sql("SELECT * FROM seoul_city_data_full_20250707_175748")
df2 = spark.sql("SELECT * FROM seoul_city_data_full_20250708_040103")
df = df1.unionByName(df2)

# COMMAND ----------

df_combined.write\
    .option("header", True)\
    .mode("overwrite")\
    .csv("dbfs:/user/your_name/seoul_city_data_combined_csv")


# COMMAND ----------

from pyspark.sql.functions import col

transport_df1 = df.select(
    col("`CITYDATA.AREA_NM`"),
    col("`CITYDATA.AREA_CD`"),
    col("`CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_SPD`"),
    col("`CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_IDX`"),
    col("`CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_TIME`"),
    col("`CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_MSG`"),
    col("`CITYDATA.ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS`"),
    col("`CITYDATA.PRK_STTS`"),
    col("`CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTON_PPLTN_MIN`"),
    col("`CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTOFF_PPLTN_MIN`"),
    col("`CITYDATA.LIVE_SUB_PPLTN.SUB_STN_CNT`"),
    col("`CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTON_PPLTN_MIN`"),
    col("`CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTOFF_PPLTN_MIN`"),
    col("`CITYDATA.LIVE_BUS_PPLTN.BUS_STN_CNT`"),
    col("`CITYDATA.ACDNT_CNTRL_STTS`"),
    col("`CITYDATA.SBIKE_STTS`"),
    col("`CITYDATA.WEATHER_STTS`"),
    col("`CITYDATA.EVENT_STTS`")
)


# COMMAND ----------

transport_df1

# COMMAND ----------

from pyspark.sql.functions import when, col

transport_df1 = transport_df1.withColumn(
    "traffic_level",
    when(col("`CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_IDX`") == "원활", 1)
    .when(col("`CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_IDX`") == "서행", 2)
    .when(col("`CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_IDX`") == "정체", 3)
    .when(col("`CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_IDX`") == "급정체", 4)
    .otherwise(None)
)


# COMMAND ----------

from pyspark.sql.functions import col, avg

summary = transport_df.groupBy(col("`CITYDATA.AREA_NM`")).agg(
    avg(col("`CITYDATA.ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_SPD`")).alias("평균교통속도(km/h)"),
    avg(col("traffic_level")).alias("평균혼잡도(1~4)"),
    avg(col("`CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTON_PPLTN_MIN`")).alias("지하철_승차인원_평균"),
    avg(col("`CITYDATA.LIVE_SUB_PPLTN.SUB_ACML_GTOFF_PPLTN_MIN`")).alias("지하철_하차인원_평균"),
    avg(col("`CITYDATA.LIVE_SUB_PPLTN.SUB_STN_CNT`")).alias("지하철역_개수"),
    avg(col("`CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTON_PPLTN_MIN`")).alias("버스_승차인원_평균"),
    avg(col("`CITYDATA.LIVE_BUS_PPLTN.BUS_ACML_GTOFF_PPLTN_MIN`")).alias("버스_하차인원_평균"),
    avg(col("`CITYDATA.LIVE_BUS_PPLTN.BUS_STN_CNT`")).alias("버스정류장_개수")
).orderBy(col("평균혼잡도(1~4)").desc())

summary.show(truncate=False)


# COMMAND ----------

from pyspark.sql.functions import col, count, when, isnan
from pyspark.sql.types import FloatType, DoubleType

# 전체 행 수
total_rows = df.count()

# 컬럼별 결측치 수 집계 (isnan은 float/double에만 적용)
null_exprs = []

for field in df.schema.fields:
    col_name = field.name
    dtype = field.dataType
    col_ref = col(f"`{col_name}`")
    
    if isinstance(dtype, (FloatType, DoubleType)):
        # float/double인 경우 isnan 포함
        expr = count(when(col_ref.isNull() | isnan(col_ref), col_name)).alias(col_name)
    else:
        # 그 외 타입은 isnan 제외
        expr = count(when(col_ref.isNull(), col_name)).alias(col_name)
    
    null_exprs.append(expr)

# 실행
null_counts = df_combined.select(null_exprs)
null_counts_row = null_counts.collect()[0].asDict()

# 정리
null_stats = [(k, v, round(v / total_rows * 100, 2)) for k, v in null_counts_row.items() if v > 0]

# 보기 좋게 출력
import pandas as pd
null_df = pd.DataFrame(null_stats, columns=["컬럼명", "결측치 수", "결측률 (%)"])
null_df.sort_values("결측률 (%)", ascending=False, inplace=True)
null_df.reset_index(drop=True, inplace=True)

null_df.head(20)


# COMMAND ----------

