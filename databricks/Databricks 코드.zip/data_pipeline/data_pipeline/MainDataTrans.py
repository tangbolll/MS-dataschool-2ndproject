# Databricks notebook source
cosmos_endpoint = "https://seoul-data-db.documents.azure.com:443/"
cosmos_key = "gdgCLQrX8omjZKrDkLRCyo41URDljVi7K8rdHzTUcUpRLg2k1BR8th6CmyKtUG3XS0wLB2hwe49oACDbxniaXQ=="
cosmos_database = "seoul-data-db"
cosmos_container = "seoul-data-container"


# COMMAND ----------

cosmos_config = {
  "spark.cosmos.accountEndpoint": cosmos_endpoint,
  "spark.cosmos.accountKey": cosmos_key,
  "spark.cosmos.database": cosmos_database,
  "spark.cosmos.container": cosmos_container,
  "spark.cosmos.read.inferSchema.enabled": "true"
}

df = spark.read.format("cosmos.oltp").options(**cosmos_config).load()


# COMMAND ----------

from pyspark.sql.functions import col

def get_array_like_columns(df):
    # 첫 행 가져오기 (toLocalIterator는 lazy하지 않음, 확실히 값 가져옴)
    first_row = next(df.limit(1).toLocalIterator(), None)

    array_like_cols = []

    if first_row:
        for field in df.schema.fields:
            col_name = field.name
            value = first_row[col_name]
            # 값이 문자열이고 "["로 시작하는 경우
            if isinstance(value, str) and value.strip().startswith("["):
                array_like_cols.append(col_name)

    return array_like_cols


# COMMAND ----------

array_like_columns = get_array_like_columns(df)
print("중첩 배열 형태 컬럼:", array_like_columns)


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC     "LIVE_CMRCL_STTS",
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# 제거할 중첩 문자열 컬럼 리스트
cols_to_drop = [
    "BUS_STN_STTS", "ACDNT_CNTRL_STTS", "CHARGER_STTS", "EVENT_STTS",
    "LIVE_CMRCL_STTS", "LIVE_CMRCL_STTS.CMRCL_RSB", "PRK_STTS", "SUB_STTS",
    "WEATHER_STTS", "SBIKE_STTS", "ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS",
    "LIVE_PPLTN_STTS"
]

# 존재하는 컬럼만 제거
df = df.drop(*[col for col in cols_to_drop if col in df.columns])


# COMMAND ----------

# 스토리지 설정
storage_account_name = "cosmo2csv"
container_name = "test"
storage_account_key = "jkUvA9iMfrJ8JHNSuuOs21uFYfM7g2Gu7D/CubSAEE6bknEtqp7x8woG3XGZSqviuth3t14oPvpk+AStKqz1qg=="

# 연결 설정
spark.conf.set(
    f"fs.azure.account.key.{storage_account_name}.dfs.core.windows.net",
    storage_account_key
)


# COMMAND ----------

# 저장 경로 지정
output_path = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/json_output"


# COMMAND ----------

# JSON 형식으로 저장
df.write \
    .mode("overwrite").json(output_path)

print("JSON 저장 완료")


# COMMAND ----------

