# Databricks notebook source
cosmosEndpoint = "https://seoul-data-db.documents.azure.com:443/"
cosmosMasterKey = "gdgCLQrX8omjZKrDkLRCyo41URDljVi7K8rdHzTUcUpRLg2k1BR8th6CmyKtUG3XS0wLB2hwe49oACDbxniaXQ=="
cosmosDatabaseName = "seoul-data-db"
cosmosContainerName = "seoul-data-container"

cfg = {
    "spark.cosmos.accountEndpoint": cosmosEndpoint,
    "spark.cosmos.accountKey": cosmosMasterKey,
    "spark.cosmos.database": cosmosDatabaseName,
    "spark.cosmos.container": cosmosContainerName,
    "spark.cosmos.read.inferSchema.enabled": "true"
}

df = spark.read.format("cosmos.oltp").options(**cfg).load()
df.show()


# COMMAND ----------

from pyspark.sql import functions as F

# ──────────────────────────────────
# 1) 뽑아낼 컬럼 목록
# ──────────────────────────────────
cols_to_extract = [
    "BUS_STN_STTS",
    "ACDNT_CNTRL_STTS",
    "CHARGER_STTS",
    "EVENT_STTS",
    "LIVE_CMRCL_STTS",
    "LIVE_CMRCL_STTS.CMRCL_RSB",
    "PRK_STTS",
    "SUB_STTS",
    "WEATHER_STTS",
    "SBIKE_STTS",
    "ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS",
    "LIVE_PPLTN_STTS"
]

# ──────────────────────────────────
# 2) 점(.)이 있는 컬럼 → 백틱(`) 처리
#    예: ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS  →  `ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS`
# ──────────────────────────────────
cols_with_backticks = [f"`{c}`" if "." in c else c for c in cols_to_extract]

# ──────────────────────────────────
# 3) 개별 DataFrame 생성
#    { "BUS_STN_STTS": DataFrame, ... } 형태로 저장
# ──────────────────────────────────
single_col_dfs = {}
for raw_col, safe_col in zip(cols_to_extract, cols_with_backticks):
    if raw_col in df.columns:               # 컬럼 존재 여부 체크
        single_col_dfs[raw_col] = df.selectExpr(safe_col)   # 하나만 남긴 DF
    else:
        print(f"[WARN] 컬럼 '{raw_col}' 이(가) df 에 존재하지 않습니다.")

# ──────────────────────────────────
# 4) 사용 예시: 첫 번째 DataFrame 확인
# ──────────────────────────────────
display(single_col_dfs["BUS_STN_STTS"])
