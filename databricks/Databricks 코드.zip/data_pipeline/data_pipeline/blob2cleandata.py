# Databricks notebook source
# Azure Blob Storage에서 Databricks로 CSV 데이터 가져오기

# ==========================================
# 1. Azure Storage Account 연결 설정
# ==========================================

# Storage Account 정보
storage_account_name = "cosmo2csv"
container_name = "cosmo-to-csv"

# 여기에 Azure Portal에서 복사한 Access Key를 붙여넣으세요
storage_account_key = "jkUvA9iMfrJ8JHNSuuOs21uFYfM7g2Gu7D/CubSAEE6bknEtqp7x8woG3XGZSqviuth3t14oPvpk+AStKqz1qg=="

# Spark 설정에 Storage Account Key 추가
spark.conf.set(
    f"fs.azure.account.key.{storage_account_name}.dfs.core.windows.net",
    storage_account_key
)

print("Azure Storage 연결 설정 완료!")

# COMMAND ----------


# ==========================================
# 2. Blob Storage 내 파일 목록 확인
# ==========================================

# Blob Storage 경로 설정
blob_path = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/"

# 컨테이너 내 파일 목록 확인
print("=== 컨테이너 내 파일 목록 ===")
files = dbutils.fs.ls(blob_path)
for file in files:
    print(f"파일명: {file.name}, 크기: {file.size} bytes, 경로: {file.path}")

# CSV 파일만 필터링
csv_files = [file for file in files if file.name.endswith('.csv')]
print(f"\n총 {len(csv_files)}개의 CSV 파일 발견")



# COMMAND ----------

# ==========================================
# 3. CSV 파일 읽기
# ==========================================

# 방법 1: 모든 CSV 파일을 한번에 읽기
print("\n=== 모든 CSV 파일 읽기 ===")
df_all = spark.read.option("header", "true").option("inferSchema", "true").csv(blob_path + "*.csv")

# 방법 2: 특정 CSV 파일만 읽기 (파일명을 알고 있는 경우)
# csv_file_name = "your_specific_file.csv"  # 실제 파일명으로 변경
# df_specific = spark.read.option("header", "true").option("inferSchema", "true").csv(blob_path + csv_file_name)

# 방법 3: 가장 최신 CSV 파일만 읽기
if csv_files:
    # 파일을 수정시간 순으로 정렬 (가장 최신 파일 가져오기)
    latest_file = max(csv_files, key=lambda x: x.modificationTime)
    print(f"가장 최신 파일: {latest_file.name}")
    
    df_latest = spark.read.option("header", "true").option("inferSchema", "true").csv(latest_file.path)
    print("최신 CSV 파일 로드 완료!")



# COMMAND ----------

print("\n=== 기본 데이터 정보 ===")

# 사용할 DataFrame 선택 (전체 데이터 또는 최신 데이터)
df = df_all  # 또는 df_latest 사용

# 데이터 크기 확인
row_count = df.count()
col_count = len(df.columns)
print(f"데이터 shape: {row_count} rows × {col_count} columns")

# 스키마 정보
print("\n=== 데이터 스키마 ===")
df.printSchema()

# 처음 5행 확인
print("\n=== 데이터 미리보기 ===")
df.show(5, truncate=False)

# 컬럼명 확인
print(f"\n=== 컬럼명 목록 ===")
print(df.columns)


# COMMAND ----------

# 컬럼 개수와 행 개수 확인
print(f"컬럼 개수: {len(df.columns)}")
print(f"행 개수: {df.count()}")

# 기본 정보 컬럼들만 먼저 보기
basic_cols = ['poi_code', 'AREA_NM', 'AREA_CD', 'inserted_at']
df.select(basic_cols).show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC 중첩 컬럼 구분

# COMMAND ----------

from pyspark.sql.functions import col

json_cols = ['ACDNT_CNTRL_STTS','BUS_STN_STTS', 'CHARGER_STTS', 'EVENT_STTS', 'LIVE_CMRCL_STTS.CMRCL_RSB','LIVE_PPLTN_STTS','PRK_STTS', 'ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS', 'SBIKE_STTS', 'SUB_STTS', 'WEATHER_STTS']

# 빠른 체크 - 백틱 사용
for column in df.columns:
    if column not in json_cols:
        try:
            # 점이 포함된 컬럼명은 백틱으로 감싸기
            column_escaped = f"`{column}`"
            first_val = df.select(column_escaped).first()[0]
            
            if first_val and isinstance(first_val, str):
                if first_val.startswith('[') or first_val.startswith('{'):
                    print(f"JSON 의심: {column}")
        except Exception as e:
            print(f"에러 발생 컬럼: {column} - {str(e)}")

# COMMAND ----------

# MAGIC %md
# MAGIC 중첩 없는 칼럼들만 main_csv로 만들기

# COMMAND ----------

json_cols = ['ACDNT_CNTRL_STTS','BUS_STN_STTS', 'CHARGER_STTS', 'EVENT_STTS', 
             'LIVE_CMRCL_STTS.CMRCL_RSB','LIVE_PPLTN_STTS','PRK_STTS', 
             'ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS', 'SBIKE_STTS', 'SUB_STTS', 'WEATHER_STTS']

# JSON 컬럼들을 제외한 main_df 생성
main_df = df.drop(*json_cols)

# 결과 확인
print("=== JSON 컬럼 제외 후 main_df ===")
main_df.show(5, truncate=False)

print(f"원본 컬럼 수: {len(df.columns)}")
print(f"main_df 컬럼 수: {len(main_df.columns)}")
print(f"제거된 컬럼 수: {len(json_cols)}")

print("\n=== main_df 컬럼 목록 ===")
for i, col_name in enumerate(main_df.columns):
    print(f"{i+1}. {col_name}")

# COMMAND ----------

# MAGIC %md
# MAGIC 중첩 컬럼 내용 확인

# COMMAND ----------

# MAGIC %md
# MAGIC 사고통제현황 -> 필요없음

# COMMAND ----------

df.select("`ACDNT_CNTRL_STTS`").show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC 인구 현황

# COMMAND ----------

df.select("LIVE_PPLTN_STTS").show(1, truncate=False)

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType

def flatten_ppltn_stts_auto(df):
    # 샘플 데이터로 스키마 추론
    sample_json = df.select("LIVE_PPLTN_STTS").first()[0]
    
    # 임시로 스키마 추론을 위한 DataFrame 생성
    temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
    inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    
    # JSON 파싱 및 explode
    df_parsed = df.withColumn("ppltn_parsed", from_json(col("LIVE_PPLTN_STTS"), ArrayType(inferred_schema)))
    
    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("ppltn_parsed")).alias("population")
    ).select("poi_code", "inserted_at", "AREA_NM", "AREA_CD", "population.*").drop("FCST_PPLTN")

# 실행
ppltn_df = flatten_ppltn_stts_auto(df)
ppltn_df.show(5, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC 버스정류소 현황

# COMMAND ----------

df.select("BUS_STN_STTS").show(1, truncate=False)

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType

def flatten_bus_stn_stts_auto(df):
    # 샘플 데이터로 스키마 추론
    sample_json = df.select("BUS_STN_STTS").first()[0]
    
    # 임시로 스키마 추론을 위한 DataFrame 생성
    temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
    inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    
    # JSON 파싱 및 explode
    df_parsed = df.withColumn("bus_parsed", from_json(col("BUS_STN_STTS"), ArrayType(inferred_schema)))
    
    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("bus_parsed")).alias("bus_station")
    ).select("poi_code", "inserted_at", "AREA_NM", "AREA_CD", "bus_station.*").drop("BUS_DETAIL","BUS_RESULT_MSG")

# 실행
bus_df = flatten_bus_stn_stts_auto(df)
bus_df.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC 전기차충전소 현황

# COMMAND ----------

df.select("CHARGER_STTS").show(1, truncate=False)

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType

def flatten_charger_stts_main_only(df):
    sample_json = df.select("CHARGER_STTS").filter(col("CHARGER_STTS") != "[]").first()[0]
    temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
    inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    
    df_parsed = df.withColumn("charger_parsed", from_json(col("CHARGER_STTS"), ArrayType(inferred_schema)))
    
    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("charger_parsed")).alias("charger_station")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("charger_station.STAT_NM").alias("STAT_NM"),
        col("charger_station.STAT_ID").alias("STAT_ID"),
        col("charger_station.STAT_ADDR").alias("STAT_ADDR"),
        col("charger_station.STAT_X").alias("STAT_X"),
        col("charger_station.STAT_Y").alias("STAT_Y"),
        col("charger_station.STAT_USETIME").alias("STAT_USETIME"),
        col("charger_station.STAT_PARKPAY").alias("STAT_PARKPAY"),
        col("charger_station.STAT_LIMITYN").alias("STAT_LIMITYN"),
        col("charger_station.STAT_LIMITDETAIL").alias("STAT_LIMITDETAIL"),
        col("charger_station.STAT_KINDDETAIL").alias("STAT_KINDDETAIL")
        # CHARGER_DETAILS 제외 (모든 값이 null이므로)
    )

# 실행
charger_df = flatten_charger_stts_main_only(df)
charger_df.show(5, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC 행사 정보 -> 필요없음, 다른 csv로 대체하면됨.

# COMMAND ----------

df.select("EVENT_STTS").show(1, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC 실시간 상권 현황 -> 필요 없음

# COMMAND ----------

df.select("LIVE_CMRCL_STTS").show(1, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC 업종별 상권 현황

# COMMAND ----------

df.select("`LIVE_CMRCL_STTS.CMRCL_RSB`").show(1, truncate=False)

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType

# LIVE_CMRCL_STTS.CMRCL_RSB를 flatten
def flatten_cmrcl_rsb_auto(df):
    # 샘플 데이터로 스키마 추론
    sample_json = df.select("`LIVE_CMRCL_STTS.CMRCL_RSB`").first()[0]
    
    # 임시로 스키마 추론을 위한 DataFrame 생성
    temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
    inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    
    # JSON 파싱 및 explode
    df_parsed = df.withColumn("cmrcl_parsed", from_json(col("`LIVE_CMRCL_STTS.CMRCL_RSB`"), ArrayType(inferred_schema)))
    
    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("cmrcl_parsed")).alias("cmrcl_item")
    ).select("poi_code", "inserted_at", "AREA_NM", "AREA_CD", "cmrcl_item.*")

# 실행
cmrcl_df = flatten_cmrcl_rsb_auto(df)
cmrcl_df.show(5, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC 주차정보

# COMMAND ----------

df.select("PRK_STTS").show(1, truncate=False)

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType

# PRK_STTS를 flatten
def flatten_prk_stts_auto(df):
    # 샘플 데이터로 스키마 추론
    sample_json = df.select("PRK_STTS").first()[0]
    
    # 임시로 스키마 추론을 위한 DataFrame 생성
    temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
    inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    
    # JSON 파싱 및 explode
    df_parsed = df.withColumn("parking_parsed", from_json(col("PRK_STTS"), ArrayType(inferred_schema)))
    
    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("parking_parsed")).alias("parking_station")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("parking_station.PRK_NM").alias("PRK_NM"),
        col("parking_station.PRK_CD").alias("PRK_CD"),
        col("parking_station.PRK_TYPE").alias("PRK_TYPE"),
        col("parking_station.CPCTY").alias("CPCTY"),
        col("parking_station.CUR_PRK_CNT").alias("CUR_PRK_CNT"),
        col("parking_station.CUR_PRK_TIME").alias("CUR_PRK_TIME"),
        col("parking_station.CUR_PRK_YN").alias("CUR_PRK_YN"),
        col("parking_station.PAY_YN").alias("PAY_YN"),
        col("parking_station.RATES").alias("RATES"),
        col("parking_station.TIME_RATES").alias("TIME_RATES"),
        col("parking_station.ADD_RATES").alias("ADD_RATES"),
        col("parking_station.ADD_TIME_RATES").alias("ADD_TIME_RATES"),
        col("parking_station.ADDRESS").alias("ADDRESS"),
        col("parking_station.ROAD_ADDR").alias("ROAD_ADDR"),
        col("parking_station.LNG").alias("LNG"),
        col("parking_station.LAT").alias("LAT")
    )

# 실행
parking_df = flatten_prk_stts_auto(df)
parking_df.show(5, truncate=False)

# 개수 확인
print(f"총 주차장 개수: {parking_df.count()}")

# COMMAND ----------

# MAGIC %md
# MAGIC 도로소통현황
# MAGIC

# COMMAND ----------

df.select("`ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS`").show(1, truncate=False)

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType

# ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS를 flatten
def flatten_road_traffic_stts_auto(df):
    # 샘플 데이터로 스키마 추론
    sample_json = df.select("`ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS`").first()[0]
    
    # 임시로 스키마 추론을 위한 DataFrame 생성
    temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
    inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    
    # JSON 파싱 및 explode
    df_parsed = df.withColumn("traffic_parsed", from_json(col("`ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS`"), ArrayType(inferred_schema)))
    
    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("traffic_parsed")).alias("traffic_info")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("traffic_info.LINK_ID").alias("LINK_ID"),
        col("traffic_info.ROAD_NM").alias("ROAD_NM"),
        col("traffic_info.START_ND_CD").alias("START_ND_CD"),
        col("traffic_info.START_ND_NM").alias("START_ND_NM"),
        col("traffic_info.START_ND_XY").alias("START_ND_XY"),
        col("traffic_info.END_ND_CD").alias("END_ND_CD"),
        col("traffic_info.END_ND_NM").alias("END_ND_NM"),
        col("traffic_info.END_ND_XY").alias("END_ND_XY"),
        col("traffic_info.DIST").alias("DIST"),
        col("traffic_info.SPD").alias("SPD"),
        col("traffic_info.IDX").alias("IDX"),
        col("traffic_info.XYLIST").alias("XYLIST")
    )

# 실행
traffic_df = flatten_road_traffic_stts_auto(df)
traffic_df.show(5, truncate=False)

# 개수 확인
print(f"총 도로교통 정보 개수: {traffic_df.count()}")

# COMMAND ----------

# MAGIC %md
# MAGIC 따릉이

# COMMAND ----------

df.select("SBIKE_STTS").show(2, truncate=False)

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType

# SBIKE_STTS를 flatten
def flatten_sbike_stts_auto(df):
    # 비어있지 않은 샘플 데이터로 스키마 추론
    sample_json = df.select("SBIKE_STTS").filter(col("SBIKE_STTS") != "[]").first()[0]
    
    # 임시로 스키마 추론을 위한 DataFrame 생성
    temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
    inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    
    # JSON 파싱 및 explode
    df_parsed = df.withColumn("sbike_parsed", from_json(col("SBIKE_STTS"), ArrayType(inferred_schema)))
    
    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("sbike_parsed")).alias("sbike_station")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("sbike_station.SBIKE_SPOT_NM").alias("SBIKE_SPOT_NM"),
        col("sbike_station.SBIKE_SPOT_ID").alias("SBIKE_SPOT_ID"),
        col("sbike_station.SBIKE_SHARED").alias("SBIKE_SHARED"),
        col("sbike_station.SBIKE_PARKING_CNT").alias("SBIKE_PARKING_CNT"),
        col("sbike_station.SBIKE_RACK_CNT").alias("SBIKE_RACK_CNT"),
        col("sbike_station.SBIKE_X").alias("SBIKE_X"),
        col("sbike_station.SBIKE_Y").alias("SBIKE_Y")
    )

# 실행
sbike_df = flatten_sbike_stts_auto(df)
sbike_df.show(5, truncate=False)

# 개수 확인
print(f"총 공유자전거 정류장 개수: {sbike_df.count()}")

# COMMAND ----------

# MAGIC %md
# MAGIC 지하철 정보 -> 그냥 지하철 위치 정보여서 제외

# COMMAND ----------

df.select("`SUB_STTS`").show(1, truncate=False)

# COMMAND ----------

# SUB_FACIINFO와 SUB_DETAIL 제외하고 메인 정보만
def flatten_sub_stts_main_only(df):
    sample_json = df.select("SUB_STTS").filter(col("SUB_STTS") != "[]").first()[0]
    temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
    inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    
    df_parsed = df.withColumn("sub_parsed", from_json(col("SUB_STTS"), ArrayType(inferred_schema)))
    
    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("sub_parsed")).alias("sub_station")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("sub_station.SUB_STN_NM").alias("SUB_STN_NM"),
        col("sub_station.SUB_STN_LINE").alias("SUB_STN_LINE"),
        col("sub_station.SUB_STN_RADDR").alias("SUB_STN_RADDR"),
        col("sub_station.SUB_STN_JIBUN").alias("SUB_STN_JIBUN"),
        col("sub_station.SUB_STN_X").alias("SUB_STN_X"),
        col("sub_station.SUB_STN_Y").alias("SUB_STN_Y")
        # SUB_FACIINFO, SUB_DETAIL 제외
    )

# 메인 정보만 필요하다면:
sub_df = flatten_sub_stts_main_only(df)
sub_df.show(5, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC 날씨

# COMMAND ----------

df.select("`WEATHER_STTS`").show(1, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC - 현재 날씨 & 뉴스 정보

# COMMAND ----------

from pyspark.sql.functions import explode, col, from_json
from pyspark.sql.types import ArrayType

def flatten_weather_stts_main_only(df):
    sample_json = df.select("WEATHER_STTS").filter(col("WEATHER_STTS") != "[]").first()[0]
    temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
    inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    
    df_parsed = df.withColumn("weather_parsed", from_json(col("WEATHER_STTS"), ArrayType(inferred_schema)))
    
    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("weather_parsed")).alias("weather_info")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("weather_info.WEATHER_TIME").alias("WEATHER_TIME"),
        col("weather_info.TEMP").alias("TEMP"),
        col("weather_info.SENSIBLE_TEMP").alias("SENSIBLE_TEMP"),
        col("weather_info.MAX_TEMP").alias("MAX_TEMP"),
        col("weather_info.MIN_TEMP").alias("MIN_TEMP"),
        col("weather_info.HUMIDITY").alias("HUMIDITY"),
        col("weather_info.WIND_DIRCT").alias("WIND_DIRCT"),
        col("weather_info.WIND_SPD").alias("WIND_SPD"),
        col("weather_info.PRECIPITATION").alias("PRECIPITATION"),
        col("weather_info.PRECPT_TYPE").alias("PRECPT_TYPE"),
        col("weather_info.PCP_MSG").alias("PCP_MSG"),
        col("weather_info.SUNRISE").alias("SUNRISE"),
        col("weather_info.SUNSET").alias("SUNSET"),
        col("weather_info.UV_INDEX_LVL").alias("UV_INDEX_LVL"),
        col("weather_info.UV_INDEX").alias("UV_INDEX"),
        col("weather_info.UV_MSG").alias("UV_MSG"),
        col("weather_info.PM25_INDEX").alias("PM25_INDEX"),
        col("weather_info.PM25").alias("PM25"),
        col("weather_info.PM10_INDEX").alias("PM10_INDEX"),
        col("weather_info.PM10").alias("PM10"),
        col("weather_info.AIR_IDX").alias("AIR_IDX"),
        col("weather_info.AIR_IDX_MVL").alias("AIR_IDX_MVL"),
        col("weather_info.AIR_IDX_MAIN").alias("AIR_IDX_MAIN"),
        col("weather_info.AIR_MSG").alias("AIR_MSG")
        # FCST24HOURS, NEWS_LIST 제외
    )

# 메인 날씨 정보만
weather_df = flatten_weather_stts_main_only(df)
weather_df.show(5, truncate=False)

# CSV로 저장
weather_df.coalesce(1).write.mode("overwrite").option("header", "true").csv("weather_main_data")

# COMMAND ----------

def flatten_weather_forecast(df):
    sample_json = df.select("WEATHER_STTS").filter(col("WEATHER_STTS") != "[]").first()[0]
    temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
    inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    
    df_parsed = df.withColumn("weather_parsed", from_json(col("WEATHER_STTS"), ArrayType(inferred_schema)))
    
    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("weather_parsed")).alias("weather_info")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("weather_info.FCST24HOURS")).alias("forecast")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("forecast.FCST_DT").alias("FCST_DT"),
        col("forecast.TEMP").alias("FCST_TEMP"),
        col("forecast.PRECIPITATION").alias("FCST_PRECIPITATION"),
        col("forecast.PRECPT_TYPE").alias("FCST_PRECPT_TYPE"),
        col("forecast.RAIN_CHANCE").alias("RAIN_CHANCE"),
        col("forecast.SKY_STTS").alias("SKY_STTS")
    )

# 24시간 예보 데이터
weather_forecast_df = flatten_weather_forecast(df)
weather_forecast_df.show(10, truncate=False)

# CSV로 저장
weather_forecast_df.coalesce(1).write.mode("overwrite").option("header", "true").csv("weather_forecast_data")

# COMMAND ----------

def flatten_weather_news(df):
    sample_json = df.select("WEATHER_STTS").filter(col("WEATHER_STTS") != "[]").first()[0]
    temp_df = spark.createDataFrame([(sample_json,)], ["json_str"])
    inferred_schema = spark.read.json(temp_df.select("json_str").rdd.map(lambda x: x[0])).schema
    
    df_parsed = df.withColumn("weather_parsed", from_json(col("WEATHER_STTS"), ArrayType(inferred_schema)))
    
    return df_parsed.select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("weather_parsed")).alias("weather_info")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        explode(col("weather_info.NEWS_LIST")).alias("news")
    ).select(
        "poi_code", "inserted_at", "AREA_NM", "AREA_CD",
        col("news.WARN_VAL").alias("WARN_VAL"),
        col("news.WARN_STRESS").alias("WARN_STRESS"),
        col("news.ANNOUNCE_TIME").alias("ANNOUNCE_TIME"),
        col("news.COMMAND").alias("COMMAND"),
        col("news.CANCEL_YN").alias("CANCEL_YN"),
        col("news.WARN_MSG").alias("WARN_MSG")
    )

# 경보/뉴스 데이터
weather_news_df = flatten_weather_news(df)
weather_news_df.show(5, truncate=False)

# CSV로 저장
weather_news_df.coalesce(1).write.mode("overwrite").option("header", "true").csv("weather_news_data")

# COMMAND ----------

# MAGIC %md
# MAGIC blob으로 다시 보내기

# COMMAND ----------

import time

# ✅ 기존 파일명 그대로 덮어쓰기
existing_files = {
    "main": "part-00000-tid-7749007723288229021-b91267aa-a8de-49fe-b083-6258af1c2d7d-376-1-c000.csv",
    "ppltn": "part-00000-tid-3991055948568772290-91829bcc-6124-4a5c-a3af-d167a18494bb-717-1-c000.csv",
    "bus": "part-00000-tid-9167073725269241119-2ba287b4-d628-4c88-9ccd-5b633bcb1ce0-377-1-c000.csv",
    "charger": "part-00000-tid-6625500281674068734-93abdea6-91aa-4d2f-bd08-3d86b2b82c55-378-1-c000.csv",
    "cmrcl": "part-00000-tid-2468397818266087095-63c5f7bd-9191-4c2a-a0ba-32d6e59a1721-379-1-c000.csv",
    "parking": "part-00000-tid-2925487736592688938-06d9c5ef-9084-49a7-8315-46181e12ddc7-380-1-c000.csv",
    "traffic": "part-00000-tid-7020725973451166923-0c1646da-513f-4615-82a5-4d43dcb449ab-381-1-c000.csv",
    "sbike": "part-00000-tid-8028706137013183732-c688343b-7938-4480-babf-a067b924696e-382-1-c000.csv",
    "sub": "part-00000-tid-5464332937530531076-16cff785-38d7-414a-bcf7-cf78b543973f-383-1-c000.csv",
    "weather": "part-00000-tid-2261085694338821007-4429d0f4-8935-43ad-8362-b8b56781dd97-384-1-c000.csv",
    "weather_forecast": "part-00000-tid-7944939390066419023-1beda0bb-cf3e-462c-a0b6-b1861dfc0e49-385-1-c000.csv",
    "weather_news": "part-00000-tid-6144648646303114499-9f939977-d965-4f56-bf27-a31e82e6dffd-386-1-c000.csv"
}

# # ✅ abfss:// 경로로 수정
# for name, df in dataframes.items():
#     if df.count() == 0:
#         continue
        
#     print(f"Updating {name} file...")
    
#     # 1. 임시 폴더에 저장
#     temp_folder = f"abfss://cosmo-to-csv@cosmo2csv.dfs.core.windows.net/clean-data/temp_{name}_update"
#     df.coalesce(1).write.mode("overwrite").option("header", "true").csv(temp_folder)
    
#     # 2. dbutils로 파일 찾기
#     files = dbutils.fs.ls(temp_folder)
#     new_part_file = None
#     for file in files:
#         if file.name.startswith("part-") and file.name.endswith(".csv"):
#             new_part_file = file.path
#             break
    
#     if new_part_file:
#         target_path = f"abfss://cosmo-to-csv@cosmo2csv.dfs.core.windows.net/clean-data/{name}.csv/{existing_files[name]}"
        
#         # 3. 기존 파일 덮어쓰기
#         try:
#             dbutils.fs.rm(target_path)  # 기존 파일 삭제
#         except:
#             pass  # 파일이 없을 수도 있음
        
#         dbutils.fs.cp(new_part_file, target_path)  # 새 파일 복사
#         dbutils.fs.rm(temp_folder, True)  # 임시 폴더 삭제
        
#         print(f"✅ {name}: 덮어쓰기 완료!")

# COMMAND ----------

dataframes = {
    "main": main_df,
    "ppltn": ppltn_df,
    "bus": bus_df,
    "charger": charger_df,
    "cmrcl": cmrcl_df,
    "parking": parking_df,
    "traffic": traffic_df,
    "sbike": sbike_df,
    "sub": sub_df,
    "weather": weather_df,
    "weather_forecast": weather_forecast_df,
    "weather_news": weather_news_df
}

# COMMAND ----------

import time

# ✅ 기존 파일명 그대로 덮어쓰기 (팀원 6명 연동용 + ppltn 추가)
existing_files = {
    "main": "part-00000-tid-7749007723288229021-b91267aa-a8de-49fe-b083-6258af1c2d7d-376-1-c000.csv",
    "ppltn": "part-00000-tid-3991055948568772290-91829bcc-6124-4a5c-a3af-d167a18494bb-717-1-c000.csv",
    "bus": "part-00000-tid-9167073725269241119-2ba287b4-d628-4c88-9ccd-5b633bcb1ce0-377-1-c000.csv",
    "charger": "part-00000-tid-6625500281674068734-93abdea6-91aa-4d2f-bd08-3d86b2b82c55-378-1-c000.csv",
    "cmrcl": "part-00000-tid-2468397818266087095-63c5f7bd-9191-4c2a-a0ba-32d6e59a1721-379-1-c000.csv",
    "parking": "part-00000-tid-2925487736592688938-06d9c5ef-9084-49a7-8315-46181e12ddc7-380-1-c000.csv",
    "traffic": "part-00000-tid-7020725973451166923-0c1646da-513f-4615-82a5-4d43dcb449ab-381-1-c000.csv",
    "sbike": "part-00000-tid-8028706137013183732-c688343b-7938-4480-babf-a067b924696e-382-1-c000.csv",
    "sub": "part-00000-tid-5464332937530531076-16cff785-38d7-414a-bcf7-cf78b543973f-383-1-c000.csv",
    "weather": "part-00000-tid-2261085694338821007-4429d0f4-8935-43ad-8362-b8b56781dd97-384-1-c000.csv",
    "weather_forecast": "part-00000-tid-7944939390066419023-1beda0bb-cf3e-462c-a0b6-b1861dfc0e49-385-1-c000.csv",
    "weather_news": "part-00000-tid-6144648646303114499-9f939977-d965-4f56-bf27-a31e82e6dffd-386-1-c000.csv"
}

# ✅ DataFrame 정의
dataframes = {
    "main": main_df,
    "ppltn": ppltn_df,  
    "bus": bus_df,
    "charger": charger_df,
    "cmrcl": cmrcl_df,
    "parking": parking_df,
    "traffic": traffic_df,
    "sbike": sbike_df,
    "sub": sub_df,
    "weather": weather_df,
    "weather_forecast": weather_forecast_df,
    "weather_news": weather_news_df
}

# ✅ 특정 파일명으로 생성하는 함수
def create_file_with_exact_name(name, df, target_filename):
    """정확한 파일명으로 생성하는 함수"""
    try:
        print(f"🆕 {name} 새로 생성 시작...")
        
        # 1. 임시 폴더에 저장
        temp_folder = f"abfss://cosmo-to-csv@cosmo2csv.dfs.core.windows.net/clean-data/temp_{name}_create"
        df.coalesce(1).write.mode("overwrite").option("header", "true").csv(temp_folder)
        
        # 2. 저장 완료 대기
        time.sleep(3)
        
        # 3. 새 파일 찾기
        files = dbutils.fs.ls(temp_folder)
        new_part_file = None
        for file in files:
            if file.name.startswith("part-") and file.name.endswith(".csv"):
                new_part_file = file.path
                break
        
        if not new_part_file:
            print(f"❌ {name}: 새 파일을 찾을 수 없음")
            return False
        
        # 4. 타겟 폴더 생성
        target_folder = f"abfss://cosmo-to-csv@cosmo2csv.dfs.core.windows.net/clean-data/{name}.csv"
        target_path = f"{target_folder}/{target_filename}"
        
        # 5. 폴더 생성 (필요시)
        try:
            dbutils.fs.ls(target_folder)
            print(f"  📁 {name}: 폴더 이미 존재")
        except:
            print(f"  📁 {name}: 폴더 생성 필요")
        
        # 6. 정확한 파일명으로 복사
        try:
            dbutils.fs.cp(new_part_file, target_path)
            print(f"  ✅ {name}: 파일 생성 완료 - {target_filename}")
        except Exception as e:
            print(f"  ❌ {name}: 파일 생성 실패 - {e}")
            return False
        
        # 7. 임시 폴더 삭제
        try:
            dbutils.fs.rm(temp_folder, True)
            print(f"  🧹 {name}: 임시 폴더 삭제 완료")
        except Exception as e:
            print(f"  ⚠️ {name}: 임시 폴더 삭제 실패 - {e}")
        
        # 8. 최종 확인
        try:
            file_info = dbutils.fs.ls(target_path)
            if file_info:
                print(f"  ✅ {name}: 최종 확인 완료 - 파일 존재함")
                return True
        except:
            print(f"  ❌ {name}: 최종 확인 실패")
            return False
        
    except Exception as e:
        print(f"❌ {name}: 전체 과정 실패 - {e}")
        return False

# ✅ 안전한 업데이트 로직 (기존 함수)
def safe_update_file(name, df, target_filename):
    """안전한 파일 업데이트 함수"""
    try:
        print(f"🔄 {name} 업데이트 시작...")
        
        # 1. 임시 폴더에 저장
        temp_folder = f"abfss://cosmo-to-csv@cosmo2csv.dfs.core.windows.net/clean-data/temp_{name}_update"
        df.coalesce(1).write.mode("overwrite").option("header", "true").csv(temp_folder)
        
        # 2. 저장 완료 대기
        time.sleep(3)
        
        # 3. 새 파일 찾기
        files = dbutils.fs.ls(temp_folder)
        new_part_file = None
        for file in files:
            if file.name.startswith("part-") and file.name.endswith(".csv"):
                new_part_file = file.path
                break
        
        if not new_part_file:
            print(f"❌ {name}: 새 파일을 찾을 수 없음")
            return False
        
        # 4. 타겟 경로 설정
        target_path = f"abfss://cosmo-to-csv@cosmo2csv.dfs.core.windows.net/clean-data/{name}.csv/{target_filename}"
        
        # 5. 기존 파일 삭제 (안전하게)
        try:
            dbutils.fs.rm(target_path)
            print(f"  🗑️ {name}: 기존 파일 삭제 완료")
        except Exception as e:
            print(f"  ⚠️ {name}: 기존 파일 삭제 실패 (없을 수도 있음) - {e}")
        
        # 6. 새 파일 복사 (재시도 로직)
        max_retries = 3
        for attempt in range(max_retries):
            try:
                dbutils.fs.cp(new_part_file, target_path)
                print(f"  ✅ {name}: 파일 복사 완료 (시도 {attempt + 1})")
                break
            except Exception as e:
                print(f"  ⚠️ {name}: 복사 실패 (시도 {attempt + 1}/{max_retries}) - {e}")
                if attempt < max_retries - 1:
                    time.sleep(2)
                else:
                    print(f"  ❌ {name}: 모든 복사 시도 실패")
                    return False
        
        # 7. 임시 폴더 삭제
        try:
            dbutils.fs.rm(temp_folder, True)
            print(f"  🧹 {name}: 임시 폴더 삭제 완료")
        except Exception as e:
            print(f"  ⚠️ {name}: 임시 폴더 삭제 실패 - {e}")
        
        # 8. 최종 확인
        try:
            file_info = dbutils.fs.ls(target_path)
            if file_info:
                print(f"  ✅ {name}: 최종 확인 완료 - 파일 존재함")
                return True
        except:
            print(f"  ❌ {name}: 최종 확인 실패")
            return False
        
    except Exception as e:
        print(f"❌ {name}: 전체 과정 실패 - {e}")
        return False

# ✅ 실행
success_count = 0
failed_files = []

for name, df in dataframes.items():
    # 키 매칭 확인
    if name not in existing_files:
        print(f"⚠️ {name}: existing_files에 없음 - 건너뛰기")
        continue
    
    # 빈 DataFrame 확인
    if df.count() == 0:
        print(f"⚠️ {name}: 빈 DataFrame - 건너뛰기")
        continue
    
    # 기존 파일 존재 확인
    target_path = f"abfss://cosmo-to-csv@cosmo2csv.dfs.core.windows.net/clean-data/{name}.csv/{existing_files[name]}"
    
    try:
        # 기존 파일이 있으면 업데이트
        dbutils.fs.ls(target_path)
        print(f"📄 {name}: 기존 파일 존재 - 업데이트 모드")
        
        if safe_update_file(name, df, existing_files[name]):
            success_count += 1
            print(f"🎉 {name}: 업데이트 완료!\n")
        else:
            failed_files.append(name)
            print(f"💥 {name}: 업데이트 실패!\n")
            
    except:
        # 기존 파일이 없으면 새로 생성
        print(f"🆕 {name}: 기존 파일 없음 - 생성 모드")
        
        if create_file_with_exact_name(name, df, existing_files[name]):
            success_count += 1
            print(f"🎉 {name}: 생성 완료!\n")
        else:
            failed_files.append(name)
            print(f"💥 {name}: 생성 실패!\n")

# ✅ 최종 결과
print("=" * 60)
print(f"✅ 성공: {success_count}개")
print(f"❌ 실패: {len(failed_files)}개")
if failed_files:
    print(f"실패한 파일들: {failed_files}")
print("=" * 60)

if success_count > 0:
    print("새로고침하면 최신 데이터가 반영됩니다!")