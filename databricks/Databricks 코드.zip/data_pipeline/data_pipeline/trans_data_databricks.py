# Databricks notebook source
# Azure Blob Storage에서 Databricks로 CSV 데이터 가져오기

# ==========================================
# 1. Azure Storage Account 연결 설정
# ==========================================

# Storage Account 정보
storage_account_name = "cosmo2csv"
container_name = "test"

# 여기에 Azure Portal에서 복사한 Access Key를 붙여넣으세요
storage_account_key = "jkUvA9iMfrJ8JHNSuuOs21uFYfM7g2Gu7D/CubSAEE6bknEtqp7x8woG3XGZSqviuth3t14oPvpk+AStKqz1qg=="

# Spark 설정에 Storage Account Key 추가
spark.conf.set(
    f"fs.azure.account.key.{storage_account_name}.dfs.core.windows.net",
    storage_account_key
)

print("Azure Storage 연결 설정 완료!")

# COMMAND ----------

from pyspark.dbutils import DBUtils
dbutils = DBUtils(spark)

# 파일 목록 가져오기
files = dbutils.fs.ls("abfss://test@cosmo2csv.dfs.core.windows.net/")

# CSV 파일만 필터링
csv_files = [f.path for f in files if f.path.endswith(".csv")]

# 개별 DataFrame 생성 (비효율적이므로 이름은 동적으로)
dataframes = {}

for i, path in enumerate(csv_files):
    df = spark.read \
        .format("csv") \
        .option("header", True) \
        .option("inferSchema", True) \
        .load(path)
    
    dataframes[f"df_{i}"] = df

# 예시로 첫 번째 DataFrame 출력
display(dataframes["df_0"])


# COMMAND ----------

import json
from pyspark.sql.functions import col, explode, from_json
from pyspark.sql.types import StructType, StructField, ArrayType, StringType

def flatten_and_save_valid_json_columns(df, df_name, base_output_path):
    print(f"\n📂 처리 중: {df_name}")
    flattened_any = False

    for col_name in df.columns:
        print(f"🔎 {col_name} 컬럼 분석 중...")

        # 점(.)이 포함된 컬럼은 백틱(`)으로 감싸 안전하게 처리
        safe_col = f"`{col_name}`" if "." in col_name else col_name

        try:
            # 고유한 문자열 샘플 수집
            all_values = df.select(col(safe_col)).dropna().distinct().rdd.flatMap(lambda x: x).collect()

            # 유효한 JSON 배열이 있는지 확인
            valid_sample = None
            for val in all_values:
                if isinstance(val, str) and val.strip().startswith("[") and val.strip() != "[]":
                    try:
                        parsed = json.loads(val)
                        if isinstance(parsed, list) and parsed and isinstance(parsed[0], dict):
                            valid_sample = parsed[0]
                            print(f"✅ JSON 배열 탐지됨 → {col_name}")
                            break
                    except Exception:
                        continue

            # 유효한 JSON이 있으면 평탄화 후 저장
            if valid_sample:
                schema = ArrayType(StructType([
                    StructField(k, StringType(), True) for k in valid_sample.keys()
                ]))

                df_parsed = df.withColumn("parsed_array", from_json(col(safe_col), schema))
                df_exploded = df_parsed.withColumn("exploded_row", explode(col("parsed_array")))
                df_flat = df_exploded.select([col(f"exploded_row.{k}").alias(k) for k in valid_sample.keys()])

                output_path = f"{base_output_path}/{df_name}/{col_name}/"
                print(f"💾 CSV 저장 위치: {output_path}")

                df_flat.write \
                    .format("csv") \
                    .option("header", True) \
                    .mode("overwrite") \
                    .save(output_path)

                flattened_any = True
            else:
                print(f"⚠️ '{col_name}' 컬럼은 모든 값이 '[]' 또는 JSON 배열 아님 → 스킵")

        except Exception as e:
            print(f"❌ {col_name} 처리 중 오류 발생: {str(e)}")

    if not flattened_any:
        print(f"🚫 평탄화 가능한 JSON 배열이 없습니다: {df_name}")


# ===============================
# 전체 DataFrame 반복 처리
# ===============================
base_output_path = "abfss://test@cosmo2csv.dfs.core.windows.net/flattened_output250716"

for df_name, df in dataframes.items():
    flatten_and_save_valid_json_columns(df, df_name, base_output_path)


# COMMAND ----------

import json
from pyspark.sql.functions import col, explode, from_json
from pyspark.sql.types import StructType, StructField, ArrayType, StringType

def flatten_and_save_valid_json_columns(df, df_name, base_output_path):
    print(f"\n📂 처리 중: {df_name}")
    flattened_any = False

    for col_name in df.columns:
        print(f"🔎 {col_name} 컬럼 분석 중...")

        # 백틱 처리된 컬럼 이름 (Spark에서 '.' 포함된 컬럼을 사용할 수 있도록)
        safe_col_name = f"`{col_name}`" if "." in col_name else col_name

        # 전체 고유 값 수집
        try:
            all_values = df.select(col(safe_col_name)).dropna().distinct().rdd.flatMap(lambda x: x).collect()
        except Exception as e:
            print(f"⚠️ 컬럼 '{col_name}' 처리 중 오류 발생: {e}")
            continue

        # JSON 배열 탐색
        valid_sample = None
        for val in all_values:
            if isinstance(val, str) and val.strip().startswith("[") and val.strip() != "[]":
                try:
                    parsed = json.loads(val)
                    if isinstance(parsed, list) and parsed and isinstance(parsed[0], dict):
                        valid_sample = parsed[0]
                        print(f"✅ JSON 배열 탐지됨 → {col_name}")
                        break
                except:
                    continue


# =======================================
# 전체 DataFrame 반복 처리
# =======================================
base_output_path = "abfss://test@cosmo2csv.dfs.core.windows.net/json_output"

for df_name, df in dataframes.items():
    flatten_and_save_valid_json_columns(df, df_name, base_output_path)


# COMMAND ----------

import json
from pyspark.sql.functions import col, explode, from_json
from pyspark.sql.types import StructType, StructField, ArrayType, StringType

def flatten_and_save_valid_json_columns(df, df_name, base_output_path):
    print(f"\n📂 처리 중: {df_name}")
    flattened_any = False

    for col_name in df.columns:
        print(f"🔎 {col_name} 컬럼 분석 중...")

        safe_col = f"`{col_name}`" if "." in col_name else col_name

        try:
            all_values = df.select(col(safe_col)).dropna().distinct().rdd.flatMap(lambda x: x).collect()

            valid_sample = None
            for val in all_values:
                if isinstance(val, str) and val.strip().startswith("[") and val.strip() != "[]":
                    try:
                        parsed = json.loads(val)
                        if isinstance(parsed, list) and parsed and isinstance(parsed[0], dict):
                            valid_sample = parsed[0]
                            print(f"✅ JSON 배열 탐지됨 → {col_name}")
                            break
                    except Exception:
                        continue

            if valid_sample:
                schema = ArrayType(StructType([
                    StructField(k, StringType(), True) for k in valid_sample.keys()
                ]))

                df_parsed = df.withColumn("parsed_array", from_json(col(safe_col), schema))
                df_exploded = df_parsed.withColumn("exploded_row", explode(col("parsed_array")))
                df_flat = df_exploded.select([col(f"exploded_row.{k}").alias(k) for k in valid_sample.keys()])

                output_path = f"{base_output_path}/{df_name}/{col_name}/"
                print(f"💾 단일 JSON 저장 위치: {output_path}")

                df_flat.coalesce(1).write \
                    .format("json") \
                    .mode("overwrite") \
                    .save(output_path)

                flattened_any = True
            else:
                print(f"⚠️ '{col_name}' 컬럼은 JSON 배열 형식이 아님 또는 비어 있음 → 스킵")

        except Exception as e:
            print(f"❌ {col_name} 처리 중 오류 발생: {str(e)}")

    if not flattened_any:
        print(f"🚫 평탄화 가능한 JSON 배열이 없습니다: {df_name}")


# ===============================
# 전체 DataFrame 반복 처리
# ===============================
base_output_path = "abfss://test@cosmo2csv.dfs.core.windows.net/flattened_output250716_json"

for df_name, df in dataframes.items():
    flatten_and_save_valid_json_columns(df, df_name, base_output_path)


# COMMAND ----------

import json
from pyspark.sql.functions import col, explode, from_json
from pyspark.sql.types import StructType, StructField, ArrayType, StringType

def flatten_and_save_valid_json_columns(df, df_name, base_output_path):
    print(f"\n📂 처리 중: {df_name}")
    flattened_any = False

    for col_name in df.columns:
        print(f"🔎 {col_name} 컬럼 분석 중...")

        # 안전하게 컬럼에 접근 (점이 있는 일반 컬럼 vs 구조체 필드 구분)
        try:
            if col_name in df.columns:
                # 단일 문자열 컬럼 (점 포함되어 있어도 문자열이면 백틱 처리)
                safe_col = col(f"`{col_name}`")
            else:
                # 구조체 필드로 간주하고 접근
                parts = col_name.split(".")
                safe_col = col(parts[0])
                for p in parts[1:]:
                    safe_col = safe_col.getField(p)
        except Exception as e:
            print(f"❌ {col_name} 접근 실패: {e}")
            continue

        try:
            all_values = df.select(safe_col.alias("json_col")) \
                           .dropna() \
                           .distinct() \
                           .rdd.flatMap(lambda x: x) \
                           .collect()

            valid_sample = None
            is_array = False
            is_object = False

            for val in all_values:
                if isinstance(val, str):
                    val_strip = val.strip()
                    try:
                        parsed = json.loads(val_strip)
                        if isinstance(parsed, list) and parsed and isinstance(parsed[0], dict):
                            valid_sample = parsed[0]
                            is_array = True
                            break
                        elif isinstance(parsed, dict):
                            valid_sample = parsed
                            is_object = True
                            break
                    except:
                        continue

            if valid_sample:
                # 스키마 구성
                struct_fields = [StructField(k, StringType(), True) for k in valid_sample.keys()]
                if is_array:
                    schema = ArrayType(StructType(struct_fields))
                    df_parsed = df.withColumn("parsed_array", from_json(safe_col, schema))
                    df_exploded = df_parsed.withColumn("exploded_row", explode(col("parsed_array")))
                    df_flat = df_exploded.select([col(f"exploded_row.{k}").alias(k) for k in valid_sample.keys()])
                elif is_object:
                    schema = StructType(struct_fields)
                    df_parsed = df.withColumn("parsed_object", from_json(safe_col, schema))
                    df_flat = df_parsed.select([col(f"parsed_object.{k}").alias(k) for k in valid_sample.keys()])

                # 디렉토리 안전하게 만들기
                safe_dir_col_name = col_name.replace(".", "_")
                output_path = f"{base_output_path}/{df_name}/{safe_dir_col_name}/"
                print(f"💾 JSON 저장 위치: {output_path}")

                df_flat.coalesce(1).write \
                    .format("json") \
                    .mode("overwrite") \
                    .save(output_path)

                flattened_any = True
            else:
                print(f"⚠️ '{col_name}' 컬럼은 유효한 JSON 구조가 아님 → 스킵")

        except Exception as e:
            print(f"❌ {col_name} 처리 중 오류 발생: {str(e)}")

    if not flattened_any:
        print(f"🚫 평탄화 가능한 JSON 컬럼 없음: {df_name}")


# ===============================
# 전체 DataFrame 반복 처리
# ===============================
base_output_path = "abfss://test@cosmo2csv.dfs.core.windows.net/flattened_output250716_json"

for df_name, df in dataframes.items():
    flatten_and_save_valid_json_columns(df, df_name, base_output_path)
