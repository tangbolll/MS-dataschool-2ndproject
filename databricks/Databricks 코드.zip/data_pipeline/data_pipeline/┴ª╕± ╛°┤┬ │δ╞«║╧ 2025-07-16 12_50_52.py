# Databricks notebook source
cosmos_endpoint = "https://seoul-data-db.documents.azure.com:443/"
cosmos_key = "gdgCLQrX8omjZKrDkLRCyo41URDljVi7K8rdHzTUcUpRLg2k1BR8th6CmyKtUG3XS0wLB2hwe49oACDbxniaXQ=="
cosmos_database = "seoul-data-db"
cosmos_container = "seoul-data-container"
cosmos_config = {
  "spark.cosmos.accountEndpoint": cosmos_endpoint,
  "spark.cosmos.accountKey": cosmos_key,
  "spark.cosmos.database": cosmos_database,
  "spark.cosmos.container": cosmos_container,
  "spark.cosmos.read.inferSchema.enabled": "true"
}

df = spark.read.format("cosmos.oltp").options(**cosmos_config).load()


# COMMAND ----------

base_output_path = "abfss://cosmo-to-csv@cosmo2csv.dfs.core.windows.net/test/json250716"
spark.conf.set(
    "fs.azure.account.key.cosmo2csv.dfs.core.windows.net",
    "jkUvA9iMfrJ8JHNSuuOs21uFYfM7g2Gu7D/CubSAEE6bknEtqp7x8woG3XGZSqviuth3t14oPvpk+AStKqz1qg=="
)


# COMMAND ----------

# 공통 참조 컬럼
ref_cols = ['id', 'poi_code', 'inserted_at', 'AREA_NM']

# 중첩 컬럼 리스트
nested_cols = [
    'SUB_STTS',
    'CHARGER_STTS',
    'BUS_STN_STTS',
    'WEATHER_STTS',
    'SBIKE_STTS',
    'ACDNT_CNTRL_STTS',
    'ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS',
    'PRK_STTS',
    'LIVE_CMRCL_STTS.CMRCL_RSB',
    'EVENT_STTS'
]

# 중첩 컬럼별로 df 추출
df_nested_dict = {}  # 딕셔너리에 저장

for col_name in nested_cols:
    safe_col = f"`{col_name}`" if "." in col_name else col_name
    try:
        selected_cols = ref_cols + [safe_col]
        df_nested = df.select(*selected_cols)
        df_nested_dict[col_name.replace(".", "_")] = df_nested
        print(f"✅ {col_name} → df_nested_dict['{col_name.replace('.', '_')}'] 저장 완료")
    except Exception as e:
        print(f"❌ {col_name} 선택 중 오류 발생: {e}")


# COMMAND ----------

for key, nested_df in df_nested_dict.items():
    print(f"\n📄 {key} 샘플 데이터:")
    try:
        nested_df.show(1, truncate=False)
    except Exception as e:
        print(f"❌ {key} 출력 오류: {e}")


# COMMAND ----------

# 공통 참조 컬럼
ref_cols = ['id', 'poi_code', 'inserted_at', 'AREA_NM']

# 중첩 컬럼 리스트
nested_cols = [
    'SUB_STTS',
    'CHARGER_STTS',
    'BUS_STN_STTS',
    'WEATHER_STTS',
    'SBIKE_STTS',
    'ACDNT_CNTRL_STTS',
    'ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS',
    'PRK_STTS',
    'LIVE_CMRCL_STTS.CMRCL_RSB',
    'EVENT_STTS'
]

# 중첩 컬럼별로 df 추출 + 캐싱까지 수행
df_nested_dict = {}  # 딕셔너리에 저장

for col_name in nested_cols:
    safe_col = f"`{col_name}`" if "." in col_name else col_name
    try:
        selected_cols = ref_cols + [safe_col]
        df_nested = df.select(*selected_cols)
        
        # 메모리에 캐싱 및 강제 평가
        df_cached = df_nested.cache()
        row_count = df_cached.count()

        # 딕셔너리에 저장 (키는 점(.)을 밑줄(_)로 치환)
        df_nested_dict[col_name.replace(".", "_")] = df_cached
        print(f"✅ {col_name} → df_nested_dict['{col_name.replace('.', '_')}'] 저장 및 캐싱 완료 ({row_count} rows)")

    except Exception as e:
        print(f"❌ {col_name} 선택 중 오류 발생: {e}")
