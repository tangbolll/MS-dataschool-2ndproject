# Databricks notebook source
# Azure Blob Storage에서 Databricks로 CSV 데이터 가져오기

# ==========================================
# 1. Azure Storage Account 연결 설정
# ==========================================

# Storage Account 정보
storage_account_name = "seouldatastorage"
container_name = "seouldata-transcsv"

# 여기에 Azure Portal에서 복사한 Access Key를 붙여넣으세요
storage_account_key = "VtctPhScLJV3PxRGDhpEA5AML7OTnqaEggX2rl0QFdpQGeLi7EfNT8Ay9guOD6IAlZiYNxAd8pTU+AStJ2XL5Q=="

# Spark 설정에 Storage Account Key 추가
spark.conf.set(
    f"fs.azure.account.key.{storage_account_name}.dfs.core.windows.net",
    storage_account_key
)

print("Azure Storage 연결 설정 완료!")


# COMMAND ----------


# ==========================================
# 2. Blob Storage 내 파일 목록 확인
# ==========================================

# Blob Storage 경로 설정
blob_path = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/"

# 컨테이너 내 파일 목록 확인
print("=== 컨테이너 내 파일 목록 ===")
files = dbutils.fs.ls(blob_path)
for file in files:
    print(f"파일명: {file.name}, 크기: {file.size} bytes, 경로: {file.path}")

# CSV 파일만 필터링
csv_files = [file for file in files if file.name.endswith('.csv')]
print(f"\n총 {len(csv_files)}개의 CSV 파일 발견")



# COMMAND ----------

# ==========================================
# 3. CSV 파일 읽기
# ==========================================

# 방법 1: 모든 CSV 파일을 한번에 읽기
print("\n=== 모든 CSV 파일 읽기 ===")
df_all = spark.read.option("header", "true").option("inferSchema", "true").csv(blob_path + "*.csv")

# 방법 2: 특정 CSV 파일만 읽기 (파일명을 알고 있는 경우)
# csv_file_name = "your_specific_file.csv"  # 실제 파일명으로 변경
# df_specific = spark.read.option("header", "true").option("inferSchema", "true").csv(blob_path + csv_file_name)

# 방법 3: 가장 최신 CSV 파일만 읽기
if csv_files:
    # 파일을 수정시간 순으로 정렬 (가장 최신 파일 가져오기)
    latest_file = sorted(csv_files, key=lambda x: x.modificationTime)[-1]
    print(f"가장 최신 파일: {latest_file.name}")
    
    df_latest = spark.read.option("header", "true").option("inferSchema", "true").csv(latest_file.path)
    print("최신 CSV 파일 로드 완료!")



# COMMAND ----------

# ==========================================
# 4. 기본 EDA 시작
# ==========================================

print("\n=== 기본 데이터 정보 ===")

# 사용할 DataFrame 선택 (전체 데이터 또는 최신 데이터)
df = df_all  # 또는 df_latest 사용

# 데이터 크기 확인
row_count = df.count()
col_count = len(df.columns)
print(f"데이터 shape: {row_count} rows × {col_count} columns")

# 스키마 정보
print("\n=== 데이터 스키마 ===")
df.printSchema()

# 처음 5행 확인
print("\n=== 데이터 미리보기 ===")
df.show(5, truncate=False)

# 컬럼명 확인
print(f"\n=== 컬럼명 목록 ===")
print(df.columns)


# COMMAND ----------

# DataFrame으로 읽기
df = spark.read.csv(
    f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/part-00000-9aad8f9a-7cb6-44b3-9f62-3370add28b73-c000.csv",
    header=True,  # 헤더가 있는 경우
    inferSchema=True  # 데이터 타입 자동 추론
)

# 데이터 구조 확인
df.printSchema()  # 컬럼명과 데이터 타입
df.count()        # 총 행 수
df.columns        # 컬럼명 리스트

# COMMAND ----------

df.show(5)       # 상위 5개 행 출력

# COMMAND ----------

# 컬럼 개수와 행 개수 확인
print(f"컬럼 개수: {len(df.columns)}")
print(f"행 개수: {df.count()}")

# 기본 정보 컬럼들만 먼저 보기
basic_cols = ['poi_code', 'AREA_NM', 'AREA_CD', 'inserted_at']
df.select(basic_cols).show(truncate=False)

# COMMAND ----------

# 2) 버스 관련 정보 (LIVE_BUS_PPLTN)
bus_cols = [col for col in df.columns if 'BUS' in col]
print("버스 관련 컬럼들:", bus_cols)

# 3) 지하철 관련 정보 (LIVE_SUB_PPLTN)  
subway_cols = [col for col in df.columns if 'SUB' in col]
print("지하철 관련 컬럼들:", subway_cols)

# 4) 상업 활동 정보 (LIVE_CMRCL_STTS)
commercial_cols = [col for col in df.columns if 'CMRCL' in col]
print("상업 관련 컬럼들:", commercial_cols)

# COMMAND ----------

# JSON 문자열로 된 컬럼들 확인
json_cols = ['BUS_STN_STTS', 'CHARGER_STTS', 'EVENT_STTS', 'PRK_STTS', 'SBIKE_STTS', 'SUB_STTS', 'WEATHER_STTS']

# 예시: 날씨 정보 보기
df.select('AREA_NM', 'WEATHER_STTS').show(5, truncate=False)

# COMMAND ----------

df.printSchema()

# COMMAND ----------

from pyspark.sql.functions import from_json, col
from pyspark.sql.types import *

# 예시: WEATHER_STTS JSON 파싱
df_with_weather = df.select(
    'AREA_NM', 
    'WEATHER_STTS'
).filter(col('WEATHER_STTS').isNotNull())

df_with_weather.show(truncate=False)

# COMMAND ----------

# ==========================================
# 5. 데이터 품질 체크
# ==========================================

print("\n=== 데이터 품질 체크 ===")

from pyspark.sql.functions import col, sum as spark_sum, when, isnan, isnull, count

# 각 컬럼의 null 값 개수
null_counts = df.select([
    spark_sum(when(isnull(c) | isnan(c), 1).otherwise(0)).alias(c) 
    for c in df.columns
])

print("=== 각 컬럼별 NULL 값 개수 ===")
null_counts.show()

# 중복 행 개수 확인
duplicate_count = df.count() - df.distinct().count()
print(f"중복 행 개수: {duplicate_count}")

# ==========================================
# 6. 기본 통계 정보
# ==========================================

print("\n=== 기본 통계 정보 ===")
df.describe().show()

# 숫자형 컬럼만 따로 통계
numeric_cols = [col_name for col_name, data_type in df.dtypes if data_type in ['int', 'bigint', 'float', 'double']]
if numeric_cols:
    print(f"\n=== 숫자형 컬럼 ({len(numeric_cols)}개) 통계 ===")
    df.select(numeric_cols).describe().show()

# 문자형 컬럼의 유니크 값 개수
string_cols = [col_name for col_name, data_type in df.dtypes if data_type == 'string']
if string_cols:
    print(f"\n=== 문자형 컬럼 ({len(string_cols)}개) 유니크 값 개수 ===")
    for col_name in string_cols:
        unique_count = df.select(col_name).distinct().count()
        print(f"{col_name}: {unique_count} 개의 유니크 값")

# ==========================================
# 7. 추가 분석을 위한 DataFrame 등록
# ==========================================

# 임시 뷰로 등록 (SQL 쿼리 사용 가능)
df.createOrReplaceTempView("cosmo_data")
print("\n임시 뷰 'cosmo_data'로 등록 완료!")
print("이제 SQL 쿼리를 사용할 수 있습니다:")
print("예: spark.sql('SELECT * FROM cosmo_data LIMIT 10').show()")

# ==========================================
# 8. 실시간 데이터 처리를 위한 Delta Lake 저장 (선택사항)
# ==========================================

# Delta Lake로 저장 (한 번만 실행)
delta_path = "/delta/cosmo_transcsv_data"

print(f"\n=== Delta Lake로 저장 ===")
print(f"저장 경로: {delta_path}")

# 첫 번째 저장 (overwrite)
# df.write.format("delta").mode("overwrite").save(delta_path)
# print("Delta Lake 테이블 생성 완료!")

# 이후 새 데이터 추가시 사용 (append)
# new_df.write.format("delta").mode("append").save(delta_path)

# Delta 테이블 읽기
# delta_df = spark.read.format("delta").load(delta_path)

print("\n=== EDA 초기 설정 완료! ===")
print("이제 구체적인 분석을 시작하세요!")

# COMMAND ----------

# ============================================================================
# Databricks 중첩 배열 Flatten 코드
# ============================================================================

from pyspark.sql.functions import *
from pyspark.sql.types import *
import json

# 파일이 이미 로드되어 있다고 가정 (df라는 이름의 DataFrame)
print("📊 원본 데이터 확인:")
print(f"총 행 수: {df.count()}")
print(f"총 컬럼 수: {len(df.columns)}")

# 지역 기본 정보 추출 (모든 분리된 테이블에 추가할 정보)
base_info = df.select('poi_code', 'AREA_NM', 'AREA_CD', 'inserted_at').collect()[0]
area_name = base_info['AREA_NM']
area_code = base_info['AREA_CD']  
poi_code = base_info['poi_code']
inserted_time = base_info['inserted_at']

print(f"🏷️ 지역 정보: {area_name} ({area_code})")
print()

# ============================================================================
# 1. ACDNT_CNTRL_STTS (사고제어상황) - 빈 배열일 가능성 높음
# ============================================================================
print("🚨 1. 사고제어상황 (ACDNT_CNTRL_STTS) 처리 중...")

try:
    accident_json = df.select('ACDNT_CNTRL_STTS').collect()[0]['ACDNT_CNTRL_STTS']
    if accident_json and accident_json.strip() != "[]":
        accident_data = json.loads(accident_json)
        if len(accident_data) > 0:
            accident_df = spark.createDataFrame(accident_data)
            accident_df = accident_df.withColumn('지역명', lit(area_name)) \
                                   .withColumn('지역코드', lit(area_code)) \
                                   .withColumn('POI코드', lit(poi_code)) \
                                   .withColumn('데이터수집시간', lit(inserted_time))
            
            # 저장
            accident_df.coalesce(1).write.mode("overwrite").option("header", "true") \
                .csv("/mnt/citydata/separated/accident_control")
            print(f"   ✅ 저장 완료: {len(accident_data)}개 레코드")
        else:
            print("   ⚠️ 빈 배열")
    else:
        print("   ⚠️ 데이터 없음")
except Exception as e:
    print(f"   ❌ 오류: {e}")

# ============================================================================
# 2. BUS_STN_STTS (버스정류장상황)
# ============================================================================
print("\n🚌 2. 버스정류장상황 (BUS_STN_STTS) 처리 중...")

try:
    bus_json = df.select('BUS_STN_STTS').collect()[0]['BUS_STN_STTS']
    if bus_json and bus_json.strip() != "[]":
        bus_data = json.loads(bus_json)
        if len(bus_data) > 0:
            bus_df = spark.createDataFrame(bus_data)
            
            # 컬럼명 한글화
            bus_df = bus_df.withColumnRenamed('BUS_STN_ID', '정류장ID') \
                           .withColumnRenamed('BUS_ARS_ID', 'ARS번호') \
                           .withColumnRenamed('BUS_STN_NM', '정류장명') \
                           .withColumnRenamed('BUS_STN_X', '경도') \
                           .withColumnRenamed('BUS_STN_Y', '위도') \
                           .withColumnRenamed('BUS_RESULT_MSG', '상태메시지') \
                           .withColumn('지역명', lit(area_name)) \
                           .withColumn('지역코드', lit(area_code)) \
                           .withColumn('POI코드', lit(poi_code))
            
            # BUS_DETAIL 중첩 배열이 있다면 제거 (빈 배열이므로)
            if 'BUS_DETAIL' in bus_df.columns:
                bus_df = bus_df.drop('BUS_DETAIL')
            
            # 저장
            bus_df.coalesce(1).write.mode("overwrite").option("header", "true") \
                .csv("/mnt/citydata/separated/bus_stations")
            print(f"   ✅ 저장 완료: {len(bus_data)}개 정류장")
        else:
            print("   ⚠️ 빈 배열")
    else:
        print("   ⚠️ 데이터 없음")
except Exception as e:
    print(f"   ❌ 오류: {e}")

# ============================================================================
# 3. CHARGER_STTS (충전기상황) 
# ============================================================================
print("\n⚡ 3. 충전기상황 (CHARGER_STTS) 처리 중...")

try:
    charger_json = df.select('CHARGER_STTS').collect()[0]['CHARGER_STTS']
    if charger_json and charger_json.strip() != "[]":
        charger_data = json.loads(charger_json)
        if len(charger_data) > 0:
            charger_df = spark.createDataFrame(charger_data)
            
            # 컬럼명 한글화
            charger_df = charger_df.withColumnRenamed('STAT_NM', '충전소명') \
                                 .withColumnRenamed('STAT_ID', '충전소ID') \
                                 .withColumnRenamed('STAT_ADDR', '주소') \
                                 .withColumnRenamed('STAT_X', '경도') \
                                 .withColumnRenamed('STAT_Y', '위도') \
                                 .withColumnRenamed('STAT_USETIME', '이용시간') \
                                 .withColumnRenamed('STAT_PARKPAY', '주차요금') \
                                 .withColumnRenamed('STAT_LIMITYN', '이용제한') \
                                 .withColumnRenamed('STAT_LIMITDETAIL', '제한상세') \
                                 .withColumnRenamed('STAT_KINDDETAIL', '시설종류') \
                                 .withColumn('지역명', lit(area_name)) \
                                 .withColumn('지역코드', lit(area_code)) \
                                 .withColumn('POI코드', lit(poi_code))
            
            # CHARGER_DETAILS 중첩 배열 제거 (null 값들이므로)
            if 'CHARGER_DETAILS' in charger_df.columns:
                charger_df = charger_df.drop('CHARGER_DETAILS')
            
            # 저장
            charger_df.coalesce(1).write.mode("overwrite").option("header", "true") \
                .csv("/mnt/citydata/separated/chargers")
            print(f"   ✅ 저장 완료: {len(charger_data)}개 충전소")
        else:
            print("   ⚠️ 빈 배열")
    else:
        print("   ⚠️ 데이터 없음")
except Exception as e:
    print(f"   ❌ 오류: {e}")

# ============================================================================
# 4. EVENT_STTS (이벤트상황)
# ============================================================================
print("\n🎉 4. 이벤트상황 (EVENT_STTS) 처리 중...")

try:
    event_json = df.select('EVENT_STTS').collect()[0]['EVENT_STTS']
    if event_json and event_json.strip() != "[]":
        event_data = json.loads(event_json)
        if len(event_data) > 0:
            event_df = spark.createDataFrame(event_data)
            
            # 컬럼명 한글화
            event_df = event_df.withColumnRenamed('EVENT_NM', '이벤트명') \
                             .withColumnRenamed('EVENT_PERIOD', '진행기간') \
                             .withColumnRenamed('EVENT_PLACE', '장소') \
                             .withColumnRenamed('EVENT_X', '경도') \
                             .withColumnRenamed('EVENT_Y', '위도') \
                             .withColumnRenamed('PAY_YN', '유료여부') \
                             .withColumnRenamed('THUMBNAIL', '썸네일URL') \
                             .withColumnRenamed('URL', '상세URL') \
                             .withColumnRenamed('EVENT_ETC_DETAIL', '기타상세') \
                             .withColumn('지역명', lit(area_name)) \
                             .withColumn('지역코드', lit(area_code)) \
                             .withColumn('POI코드', lit(poi_code))
            
            # 저장
            event_df.coalesce(1).write.mode("overwrite").option("header", "true") \
                .csv("/mnt/citydata/separated/events")
            print(f"   ✅ 저장 완료: {len(event_data)}개 이벤트")
        else:
            print("   ⚠️ 빈 배열")
    else:
        print("   ⚠️ 데이터 없음")
except Exception as e:
    print(f"   ❌ 오류: {e}")

# ============================================================================
# 5. LIVE_CMRCL_STTS.CMRCL_RSB (상권업종별)
# ============================================================================
print("\n🏪 5. 상권업종별 (LIVE_CMRCL_STTS.CMRCL_RSB) 처리 중...")

try:
    cmrcl_json = df.select('LIVE_CMRCL_STTS.CMRCL_RSB').collect()[0]['LIVE_CMRCL_STTS.CMRCL_RSB']
    if cmrcl_json and cmrcl_json.strip() != "[]":
        cmrcl_data = json.loads(cmrcl_json)
        if len(cmrcl_data) > 0:
            cmrcl_df = spark.createDataFrame(cmrcl_data)
            
            # 컬럼명 한글화
            cmrcl_df = cmrcl_df.withColumnRenamed('RSB_LRG_CTGR', '업종대분류') \
                             .withColumnRenamed('RSB_MID_CTGR', '업종중분류') \
                             .withColumnRenamed('RSB_PAYMENT_LVL', '결제수준') \
                             .withColumnRenamed('RSB_SH_PAYMENT_CNT', '결제건수') \
                             .withColumnRenamed('RSB_SH_PAYMENT_AMT_MIN', '최소결제금액') \
                             .withColumnRenamed('RSB_SH_PAYMENT_AMT_MAX', '최대결제금액') \
                             .withColumnRenamed('RSB_MCT_CNT', '점포수') \
                             .withColumnRenamed('RSB_MCT_TIME', '기준시점') \
                             .withColumn('지역명', lit(area_name)) \
                             .withColumn('지역코드', lit(area_code)) \
                             .withColumn('POI코드', lit(poi_code))
            
            # 저장
            cmrcl_df.coalesce(1).write.mode("overwrite").option("header", "true") \
                .csv("/mnt/citydata/separated/commercial_business")
            print(f"   ✅ 저장 완료: {len(cmrcl_data)}개 업종")
        else:
            print("   ⚠️ 빈 배열")
    else:
        print("   ⚠️ 데이터 없음")
except Exception as e:
    print(f"   ❌ 오류: {e}")

# ============================================================================
# 6. LIVE_PPLTN_STTS (실시간인구상황)
# ============================================================================
print("\n👥 6. 실시간인구상황 (LIVE_PPLTN_STTS) 처리 중...")

try:
    ppltn_json = df.select('LIVE_PPLTN_STTS').collect()[0]['LIVE_PPLTN_STTS']
    if ppltn_json and ppltn_json.strip() != "[]":
        ppltn_data = json.loads(ppltn_json)
        if len(ppltn_data) > 0:
            ppltn_df = spark.createDataFrame(ppltn_data)
            
            # 컬럼명 한글화 (주요 컬럼들만)
            ppltn_df = ppltn_df.withColumnRenamed('AREA_CONGEST_LVL', '혼잡도수준') \
                             .withColumnRenamed('AREA_CONGEST_MSG', '혼잡도메시지') \
                             .withColumnRenamed('AREA_PPLTN_MIN', '최소인구수') \
                             .withColumnRenamed('AREA_PPLTN_MAX', '최대인구수') \
                             .withColumnRenamed('MALE_PPLTN_RATE', '남성비율') \
                             .withColumnRenamed('FEMALE_PPLTN_RATE', '여성비율') \
                             .withColumnRenamed('RESNT_PPLTN_RATE', '거주민비율') \
                             .withColumnRenamed('NON_RESNT_PPLTN_RATE', '비거주민비율') \
                             .withColumnRenamed('PPLTN_TIME', '인구집계시간')
            
            # 연령대별 비율 컬럼들 유지
            age_columns = ['PPLTN_RATE_0', 'PPLTN_RATE_10', 'PPLTN_RATE_20', 
                          'PPLTN_RATE_30', 'PPLTN_RATE_40', 'PPLTN_RATE_50', 
                          'PPLTN_RATE_60', 'PPLTN_RATE_70']
            
            # FCST_PPLTN 중첩 배열 제거 (빈 배열)
            if 'FCST_PPLTN' in ppltn_df.columns:
                ppltn_df = ppltn_df.drop('FCST_PPLTN')
            
            ppltn_df = ppltn_df.withColumn('POI코드', lit(poi_code))
            
            # 저장
            ppltn_df.coalesce(1).write.mode("overwrite").option("header", "true") \
                .csv("/mnt/citydata/separated/population")
            print(f"   ✅ 저장 완료: {len(ppltn_data)}개 레코드")
        else:
            print("   ⚠️ 빈 배열")
    else:
        print("   ⚠️ 데이터 없음")
except Exception as e:
    print(f"   ❌ 오류: {e}")

# ============================================================================
# 7. PRK_STTS (주차상황)
# ============================================================================
print("\n🅿️ 7. 주차상황 (PRK_STTS) 처리 중...")

try:
    parking_json = df.select('PRK_STTS').collect()[0]['PRK_STTS']
    if parking_json and parking_json.strip() != "[]":
        parking_data = json.loads(parking_json)
        if len(parking_data) > 0:
            parking_df = spark.createDataFrame(parking_data)
            
            # 컬럼명 한글화
            parking_df = parking_df.withColumnRenamed('PRK_NM', '주차장명') \
                                 .withColumnRenamed('PRK_CD', '주차장코드') \
                                 .withColumnRenamed('PRK_TYPE', '주차장유형') \
                                 .withColumnRenamed('CPCTY', '총주차면수') \
                                 .withColumnRenamed('CUR_PRK_CNT', '현재주차대수') \
                                 .withColumnRenamed('CUR_PRK_TIME', '현재주차시간') \
                                 .withColumnRenamed('CUR_PRK_YN', '실시간여부') \
                                 .withColumnRenamed('PAY_YN', '유료여부') \
                                 .withColumnRenamed('RATES', '기본요금') \
                                 .withColumnRenamed('TIME_RATES', '기본시간') \
                                 .withColumnRenamed('ADD_RATES', '추가요금') \
                                 .withColumnRenamed('ADD_TIME_RATES', '추가시간') \
                                 .withColumnRenamed('ADDRESS', '주소') \
                                 .withColumnRenamed('ROAD_ADDR', '도로명주소') \
                                 .withColumnRenamed('LNG', '경도') \
                                 .withColumnRenamed('LAT', '위도') \
                                 .withColumn('지역명', lit(area_name)) \
                                 .withColumn('지역코드', lit(area_code)) \
                                 .withColumn('POI코드', lit(poi_code))
            
            # 저장
            parking_df.coalesce(1).write.mode("overwrite").option("header", "true") \
                .csv("/mnt/citydata/separated/parking")
            print(f"   ✅ 저장 완료: {len(parking_data)}개 주차장")
        else:
            print("   ⚠️ 빈 배열")
    else:
        print("   ⚠️ 데이터 없음")
except Exception as e:
    print(f"   ❌ 오류: {e}")

# ============================================================================
# 8. ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS (상세도로교통)
# ============================================================================
print("\n🚗 8. 상세도로교통 (ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS) 처리 중...")

try:
    traffic_json = df.select('ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS').collect()[0]['ROAD_TRAFFIC_STTS.ROAD_TRAFFIC_STTS']
    if traffic_json and traffic_json.strip() != "[]":
        traffic_data = json.loads(traffic_json)
        if len(traffic_data) > 0:
            traffic_df = spark.createDataFrame(traffic_data)
            
            # 컬럼명 한글화
            traffic_df = traffic_df.withColumnRenamed('LINK_ID', '링크ID') \
                                 .withColumnRenamed('ROAD_NM', '도로명') \
                                 .withColumnRenamed('START_ND_CD', '시작노드코드') \
                                 .withColumnRenamed('START_ND_NM', '시작노드명') \
                                 .withColumnRenamed('END_ND_CD', '끝노드코드') \
                                 .withColumnRenamed('END_ND_NM', '끝노드명') \
                                 .withColumnRenamed('DIST', '거리') \
                                 .withColumnRenamed('SPD', '속도') \
                                 .withColumnRenamed('IDX', '교통상황') \
                                 .withColumn('지역명', lit(area_name)) \
                                 .withColumn('지역코드', lit(area_code)) \
                                 .withColumn('POI코드', lit(poi_code))
            
            # XYLIST, START_ND_XY, END_ND_XY 등 좌표 데이터는 유지
            
            # 저장
            traffic_df.coalesce(1).write.mode("overwrite").option("header", "true") \
                .csv("/mnt/citydata/separated/road_traffic")
            print(f"   ✅ 저장 완료: {len(traffic_data)}개 도로구간")
        else:
            print("   ⚠️ 빈 배열")
    else:
        print("   ⚠️ 데이터 없음")
except Exception as e:
    print(f"   ❌ 오류: {e}")

# ============================================================================
# 9. SBIKE_STTS (따릉이상황)
# ============================================================================
print("\n🚲 9. 따릉이상황 (SBIKE_STTS) 처리 중...")

try:
    sbike_json = df.select('SBIKE_STTS').collect()[0]['SBIKE_STTS']
    if sbike_json and sbike_json.strip() != "[]":
        sbike_data = json.loads(sbike_json)
        if len(sbike_data) > 0:
            sbike_df = spark.createDataFrame(sbike_data)
            
            # 컬럼명 한글화
            sbike_df = sbike_df.withColumnRenamed('SBIKE_SPOT_NM', '정거장명') \
                             .withColumnRenamed('SBIKE_SPOT_ID', '정거장ID') \
                             .withColumnRenamed('SBIKE_SHARED', '대여가능대수') \
                             .withColumnRenamed('SBIKE_PARKING_CNT', '주차대수') \
                             .withColumnRenamed('SBIKE_RACK_CNT', '거치대수') \
                             .withColumnRenamed('SBIKE_X', '경도') \
                             .withColumnRenamed('SBIKE_Y', '위도') \
                             .withColumn('지역명', lit(area_name)) \
                             .withColumn('지역코드', lit(area_code)) \
                             .withColumn('POI코드', lit(poi_code))
            
            # 저장
            sbike_df.coalesce(1).write.mode("overwrite").option("header", "true") \
                .csv("/mnt/citydata/separated/shared_bikes")
            print(f"   ✅ 저장 완료: {len(sbike_data)}개 정거장")
        else:
            print("   ⚠️ 빈 배열")
    else:
        print("   ⚠️ 데이터 없음")
except Exception as e:
    print(f"   ❌ 오류: {e}")

# ============================================================================
# 10. SUB_STTS (지하철상황) - 복잡한 중첩 구조
# ============================================================================
print("\n🚇 10. 지하철상황 (SUB_STTS) 처리 중...")

try:
    subway_json = df.select('SUB_STTS').collect()[0]['SUB_STTS']
    if subway_json and subway_json.strip() != "[]":
        subway_data = json.loads(subway_json)
        if len(subway_data) > 0:
            subway_df = spark.createDataFrame(subway_data)
            
            # 기본 지하철역 정보 (중첩 배열 제외)
            subway_basic = subway_df.withColumnRenamed('SUB_STN_NM', '지하철역명') \
                                   .withColumnRenamed('SUB_STN_LINE', '호선') \
                                   .withColumnRenamed('SUB_STN_RADDR', '도로명주소') \
                                   .withColumnRenamed('SUB_STN_JIBUN', '지번주소') \
                                   .withColumnRenamed('SUB_STN_X', '경도') \
                                   .withColumnRenamed('SUB_STN_Y', '위도') \
                                   .withColumn('지역명', lit(area_name)) \
                                   .withColumn('지역코드', lit(area_code)) \
                                   .withColumn('POI코드', lit(poi_code))
            
            # 중첩 배열 컬럼들 제거
            if 'SUB_FACIINFO' in subway_basic.columns:
                subway_basic = subway_basic.drop('SUB_FACIINFO')
            if 'SUB_DETAIL' in subway_basic.columns:
                subway_basic = subway_basic.drop('SUB_DETAIL')
            
            # 기본 지하철역 정보 저장
            subway_basic.coalesce(1).write.mode("overwrite").option("header", "true") \
                .csv("/mnt/citydata/separated/subway_stations")
            print(f"   ✅ 기본정보 저장 완료: {len(subway_data)}개 역")
            
            # SUB_FACIINFO (지하철 시설정보) 별도 처리
            if 'SUB_FACIINFO' in subway_df.columns:
                print("   🔧 지하철 시설정보 처리 중...")
                
                facilities_data = []
                for row in subway_data:
                    station_name = row['SUB_STN_NM']
                    if 'SUB_FACIINFO' in row and row['SUB_FACIINFO']:
                        for facility in row['SUB_FACIINFO']:
                            facility_row = facility.copy()
                            facility_row['지하철역명'] = station_name
                            facility_row['지역명'] = area_name
                            facility_row['POI코드'] = poi_code
                            facilities_data.append(facility_row)
                
                if facilities_data:
                    facilities_df = spark.createDataFrame(facilities_data)
                    
                    # 컬럼명 한글화
                    facilities_df = facilities_df.withColumnRenamed('ELVTR_NM', '시설명') \
                                               .withColumnRenamed('OPR_SEC', '운영구간') \
                                               .withColumnRenamed('INSTL_PSTN', '설치위치') \
                                               .withColumnRenamed('USE_YN', '사용여부') \
                                               .withColumnRenamed('ELVTR_SE', '시설유형')
                    
                    facilities_df.coalesce(1).write.mode("overwrite").option("header", "true") \
                        .csv("/mnt/citydata/separated/subway_facilities")
                    print(f"   ✅ 시설정보 저장 완료: {len(facilities_data)}개 시설")
            
            # SUB_DETAIL (지하철 운행정보) 별도 처리
            if 'SUB_DETAIL' in subway_df.columns:
                print("   🚇 지하철 운행정보 처리 중...")
                
                details_data = []
                for row in subway_data:
                    station_name = row['SUB_STN_NM']
                    if 'SUB_DETAIL' in row and row['SUB_DETAIL']:
                        for detail in row['SUB_DETAIL']:
                            detail_row = detail.copy()
                            detail_row['지하철역명'] = station_name
                            detail_row['지역명'] = area_name
                            detail_row['POI코드'] = poi_code
                            details_data.append(detail_row)
                
                if details_data:
                    details_df = spark.createDataFrame(details_data)
                    
                    # 컬럼명 한글화
                    details_df = details_df.withColumnRenamed('SUB_ROUTE_NM', '노선명') \
                                         .withColumnRenamed('SUB_LINE', '호선') \
                                         .withColumnRenamed('SUB_DIR', '방향') \
                                         .withColumnRenamed('SUB_TERMINAL', '종착역') \
                                         .withColumnRenamed('SUB_ARVTIME', '도착예정시간') \
                                         .withColumnRenamed('SUB_ARMG1', '도착정보1') \
                                         .withColumnRenamed('SUB_ARMG2', '도착정보2') \
                                         .withColumnRenamed('SUB_ARVINFO', '운행상태')
                    
                    details_df.coalesce(1).write.mode("overwrite").option("header", "true") \
                        .csv("/mnt/citydata/separated/subway_details")
                    print(f"   ✅ 운행정보 저장 완료: {len(details_data)}개 열차")
        else:
            print("   ⚠️ 빈 배열")
    else:
        print("   ⚠️ 데이터 없음")
except Exception as e:
    print(f"   ❌ 오류: {e}")

# ============================================================================
# 11. WEATHER_STTS (날씨상황) - 복잡한 중첩 구조
# ============================================================================
print("\n🌤️ 11. 날씨상황 (WEATHER_STTS) 처리 중...")

try:
    weather_json = df.select('WEATHER_STTS').collect()[0]['WEATHER_STTS']
    if weather_json and weather_json.strip() != "[]":
        weather_data = json.loads(weather_json)
        if len(weather_data) > 0:
            weather_df = spark.createDataFrame(weather_data)
            
            # 기본 날씨 정보 (중첩 배열 제외)
            weather_basic = weather_df.withColumnRenamed('WEATHER_TIME', '관측시간') \
                                     .withColumnRenamed('TEMP', '온도') \
                                     .withColumnRenamed('SENSIBLE_TEMP', '체감온도') \
                                     .withColumnRenamed('MAX_TEMP', '최고온도') \
                                     .withColumnRenamed('MIN_TEMP', '최저온도') \
                                     .withColumnRenamed('HUMIDITY', '습도') \
                                     .withColumnRenamed('WIND_DIRCT', '풍향') \
                                     .withColumnRenamed('WIND_SPD', '풍속') \
                                     .withColumnRenamed('PRECIPITATION', '강수량') \
                                     .withColumnRenamed('PRECPT_TYPE', '강수형태') \
                                     .withColumnRenamed('PCP_MSG', '강수메시지') \
                                     .withColumnRenamed('UV_INDEX', '자외선지수') \
                                     .withColumnRenamed('UV_INDEX_LVL', '자외선등급') \
                                     .withColumnRenamed('UV_MSG', '자외선메시지') \
                                     .withColumnRenamed('PM25', '초미세먼지') \
                                     .withColumnRenamed('PM25_INDEX', '초미세먼지등급') \
                                     .withColumnRenamed('PM10', '미세먼지') \
                                     .withColumnRenamed('PM10_INDEX', '미세먼지등급') \
                                     .withColumnRenamed('AIR_IDX', '대기질지수') \
                                     .withColumnRenamed('AIR_IDX_MVL', '대기질수치') \
                                     .withColumnRenamed('AIR_IDX_MAIN', '대기질주요인자') \
                                     .withColumnRenamed('AIR_MSG', '대기질메시지') \
                                     .withColumnRenamed('SUNRISE', '일출시간') \
                                     .withColumnRenamed('SUNSET', '일몰시간') \
                                     .withColumn('지역명', lit(area_name)) \
                                     .withColumn('지역코드', lit(area_code)) \
                                     .withColumn('POI코드', lit(poi_code))
            
            # 중첩 배열 컬럼들 제거
            if 'FCST24HOURS' in weather_basic.columns:
                weather_basic = weather_basic.drop('FCST24HOURS')
            if 'NEWS_LIST' in weather_basic.columns:
                weather_basic = weather_basic.drop('NEWS_LIST')
            
            # 기본 날씨 정보 저장
            weather_basic.coalesce(1).write.mode("overwrite").option("header", "true") \
                .csv("/mnt/citydata/separated/weather")
            print(f"   ✅ 기본정보 저장 완료: {len(weather_data)}개 레코드")
            
            # FCST24HOURS (24시간 예보) 별도 처리
            if 'FCST24HOURS' in weather_df.columns:
                print("   📅 24시간 예보 처리 중...")
                
                forecast_data = []
                for row in weather_data:
                    if 'FCST24HOURS' in row and row['FCST24HOURS']:
                        for forecast in row['FCST24HOURS']:
                            forecast_row = forecast.copy()
                            forecast_row['지역명'] = area_name
                            forecast_row['POI코드'] = poi_code
                            forecast_data.append(forecast_row)
                
                if forecast_data:
                    forecast_df = spark.createDataFrame(forecast_data)
                    
                    # 컬럼명 한글화
                    forecast_df = forecast_df.withColumnRenamed('FCST_DT', '예보시간') \
                                           .withColumnRenamed('TEMP', '예상온도') \
                                           .withColumnRenamed('PRECIPITATION', '예상강수량') \
                                           .withColumnRenamed('PRECPT_TYPE', '예상강수형태') \
                                           .withColumnRenamed('RAIN_CHANCE', '강수확률') \
                                           .withColumnRenamed('SKY_STTS', '하늘상태')
                    
                    forecast_df.coalesce(1).write.mode("overwrite").option("header", "true") \
                        .csv("/mnt/citydata/separated/weather_forecast")
                    print(f"   ✅ 예보정보 저장 완료: {len(forecast_data)}개 시간대")
            
            # NEWS_LIST (기상특보) 별도 처리
            if 'NEWS_LIST' in weather_df.columns:
                print("   📢 기상특보 처리 중...")
                
                news_data = []
                for row in weather_data:
                    if 'NEWS_LIST' in row and row['NEWS_LIST']:
                        for news in row['NEWS_LIST']:
                            news_row = news.copy()
                            news_row['지역명'] = area_name
                            news_row['POI코드'] = poi_code
                            news_data.append(news_row)
                
                if news_data:
                    news_df = spark.createDataFrame(news_data)
                    
                    # 컬럼명 한글화
                    news_df = news_df.withColumnRenamed('WARN_VAL', '특보종류') \
                                   .withColumnRenamed('WARN_STRESS', '특보단계') \
                                   .withColumnRenamed('ANNOUNCE_TIME', '발표시간') \
                                   .withColumnRenamed('COMMAND', '발표구분') \
                                   .withColumnRenamed('CANCEL_YN', '해제여부') \
                                   .withColumnRenamed('WARN_MSG', '특보메시지')
                    
                    news_df.coalesce(1).write.mode("overwrite").option("header", "true") \
                        .csv("/mnt/citydata/separated/weather_news")
                    print(f"   ✅ 특보정보 저장 완료: {len(news_data)}개 특보")
        else:
            print("   ⚠️ 빈 배열")
    else:
        print("   ⚠️ 데이터 없음")
except Exception as e:
    print(f"   ❌ 오류: {e}")

# ============================================================================
# 마지막으로 메인 테이블 생성 (단순 컬럼들만)
# ============================================================================
print("\n📋 12. 메인 테이블 생성 중...")

# 다중공선성 제거 후 남은 단순 컬럼들
main_columns = [
    'poi_code', 'inserted_at', 'AREA_NM', 'AREA_CD',
    'LIVE_BUS_PPLTN.BUS_10WTHN_GTOFF_PPLTN_MAX',
    'LIVE_BUS_PPLTN.BUS_10WTHN_GTOFF_PPLTN_MIN',
    'LIVE_BUS_PPLTN.BUS_10WTHN_GTON_PPLTN_MAX',
    'LIVE_BUS_PPLTN.BUS_10WTHN_GTON_PPLTN_MIN',
    'LIVE_BUS_PPLTN.BUS_5WTHN_GTOFF_PPLTN_MAX',
    'LIVE_BUS_PPLTN.BUS_5WTHN_GTOFF_PPLTN_MIN',
    'LIVE_BUS_PPLTN.BUS_5WTHN_GTON_PPLTN_MAX',
    'LIVE_BUS_PPLTN.BUS_5WTHN_GTON_PPLTN_MIN',
    'LIVE_BUS_PPLTN.BUS_ACML_GTON_PPLTN_MAX',
    'LIVE_BUS_PPLTN.BUS_STN_CNT',
    'LIVE_BUS_PPLTN.BUS_STN_TIME',
    # 지하철 인구 데이터 (전체 유지)
    'LIVE_SUB_PPLTN.SUB_10WTHN_GTOFF_PPLTN_MAX',
    'LIVE_SUB_PPLTN.SUB_10WTHN_GTOFF_PPLTN_MIN',
    'LIVE_SUB_PPLTN.SUB_10WTHN_GTON_PPLTN_MAX',
    'LIVE_SUB_PPLTN.SUB_10WTHN_GTON_PPLTN_MIN',
    'LIVE_SUB_PPLTN.SUB_30WTHN_GTOFF_PPLTN_MAX',
    'LIVE_SUB_PPLTN.SUB_30WTHN_GTOFF_PPLTN_MIN',
    'LIVE_SUB_PPLTN.SUB_30WTHN_GTON_PPLTN_MAX',
    'LIVE_SUB_PPLTN.SUB_30WTHN_GTON_PPLTN_MIN',
    'LIVE_SUB_PPLTN.SUB_5WTHN_GTOFF_PPLTN_MAX',
    'LIVE_SUB_PPLTN.SUB_5WTHN_GTOFF_PPLTN_MIN',
    'LIVE_SUB_PPLTN.SUB_5WTHN_GTON_PPLTN_MAX',
    'LIVE_SUB_PPLTN.SUB_5WTHN_GTON_PPLTN_MIN',
    'LIVE_SUB_PPLTN.SUB_ACML_GTOFF_PPLTN_MAX',
    'LIVE_SUB_PPLTN.SUB_ACML_GTOFF_PPLTN_MIN',
    'LIVE_SUB_PPLTN.SUB_ACML_GTON_PPLTN_MAX',
    'LIVE_SUB_PPLTN.SUB_ACML_GTON_PPLTN_MIN',
    'LIVE_SUB_PPLTN.SUB_STN_CNT',
    'LIVE_SUB_PPLTN.SUB_STN_TIME',
    # 상업시설 데이터 (다중공선성 제거 후)
    'LIVE_CMRCL_STTS',
    'LIVE_CMRCL_STTS.AREA_CMRCL_LVL',
    'LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MAX',
    'LIVE_CMRCL_STTS.AREA_SH_PAYMENT_AMT_MIN',
    'LIVE_CMRCL_STTS.AREA_SH_PAYMENT_CNT',
    'LIVE_CMRCL_STTS.CMRCL_10_RATE',
    'LIVE_CMRCL_STTS.CMRCL_20_RATE',
    'LIVE_CMRCL_STTS.CMRCL_30_RATE',
    'LIVE_CMRCL_STTS.CMRCL_40_RATE',
    'LIVE_CMRCL_STTS.CMRCL_50_RATE',
    'LIVE_CMRCL_STTS.CMRCL_60_RATE',
    'LIVE_CMRCL_STTS.CMRCL_MALE_RATE',
    'LIVE_CMRCL_STTS.CMRCL_PERSONAL_RATE',
    'LIVE_CMRCL_STTS.CMRCL_TIME',
    # 도로교통 데이터
    'ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_MSG',
    'ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_IDX',
    'ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_SPD',
    'ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_TIME'
]

try:
    main_df = df.select(*main_columns)
    
    # 컬럼명 한글화
    main_df = main_df.withColumnRenamed('poi_code', 'POI코드') \
                     .withColumnRenamed('inserted_at', '데이터수집시간') \
                     .withColumnRenamed('AREA_NM', '지역명') \
                     .withColumnRenamed('AREA_CD', '지역코드') \
                     .withColumnRenamed('LIVE_CMRCL_STTS.AREA_CMRCL_LVL', '상권활성도') \
                     .withColumnRenamed('ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_SPD', '평균교통속도') \
                     .withColumnRenamed('ROAD_TRAFFIC_STTS.AVG_ROAD_DATA.ROAD_TRAFFIC_IDX', '교통상황')
    
    # 저장
    main_df.coalesce(1).write.mode("overwrite").option("header", "true") \
        .csv("/mnt/citydata/separated/main_citydata")
    print(f"   ✅ 저장 완료: {len(main_columns)}개 컬럼")
except Exception as e:
    print(f"   ❌ 오류: {e}")

# ============================================================================
# 완료 메시지
# ============================================================================
print("\n" + "="*50)
print("🎉 모든 중첩 배열 Flatten 작업 완료!")
print("="*50)
print("\n📁 생성된 CSV 파일들:")
print("   ├── main_citydata.csv           (메인 테이블)")
print("   ├── accident_control.csv        (사고제어)")
print("   ├── bus_stations.csv            (버스정류장)")
print("   ├── chargers.csv                (충전기)")
print("   ├── events.csv                  (이벤트)")
print("   ├── commercial_business.csv     (상권업종)")
print("   ├── population.csv              (인구현황)")
print("   ├── parking.csv                 (주차장)")
print("   ├── road_traffic.csv            (도로교통)")
print("   ├── shared_bikes.csv            (따릉이)")
print("   ├── subway_stations.csv         (지하철역)")
print("   ├── subway_facilities.csv       (지하철시설)")
print("   ├── subway_details.csv          (지하철운행)")
print("   ├── weather.csv                 (날씨)")
print("   ├── weather_forecast.csv        (날씨예보)")
print("   └── weather_news.csv            (기상특보)")
print("\n💡 다음 단계: Power BI용 통합 테이블 생성 및 Data Factory 2차 전처리")